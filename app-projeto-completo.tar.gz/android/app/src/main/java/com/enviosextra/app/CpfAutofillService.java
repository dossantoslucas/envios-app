package com.enviosextra.app;

import android.app.assist.AssistStructure;
import android.os.Build;
import android.os.CancellationSignal;
import android.service.autofill.AutofillService;
import android.service.autofill.Dataset;
import android.service.autofill.FillCallback;
import android.service.autofill.FillContext;
import android.service.autofill.FillRequest;
import android.service.autofill.FillResponse;
import android.service.autofill.SaveCallback;
import android.service.autofill.SaveRequest;
import android.view.View;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillValue;
import android.widget.RemoteViews;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Serviço nativo de Preenchimento Automático (AutofillService) do Android.
 * Ao clicar em um campo em branco ou segurar o dedo e tocar em "Preenchimento automático",
 * exibe uma caixinha flutuante com um CPF válido de 11 dígitos gerado na hora.
 */
@RequiresApi(api = Build.VERSION_CODES.O)
public class CpfAutofillService extends AutofillService {

    @Override
    public void onFillRequest(FillRequest request, CancellationSignal cancellationSignal, FillCallback callback) {
        try {
            List<FillContext> contexts = request.getFillContexts();
            if (contexts == null || contexts.isEmpty()) {
                callback.onSuccess(null);
                return;
            }

            AssistStructure structure = contexts.get(contexts.size() - 1).getStructure();
            if (structure == null) {
                callback.onSuccess(null);
                return;
            }

            // Não exibir dentro do próprio EnviosExtraCalc
            if (structure.getActivityComponent() != null &&
                getPackageName().equals(structure.getActivityComponent().getPackageName())) {
                callback.onSuccess(null);
                return;
            }

            List<AutofillId> focusedIds = new ArrayList<>();
            List<AutofillId> editableIds = new ArrayList<>();

            int nodes = structure.getWindowNodeCount();
            for (int i = 0; i < nodes; i++) {
                AssistStructure.WindowNode windowNode = structure.getWindowNodeAt(i);
                AssistStructure.ViewNode rootNode = windowNode.getRootViewNode();
                traverseNode(rootNode, focusedIds, editableIds);
            }

            List<AutofillId> targetIds = new ArrayList<>();
            targetIds.addAll(focusedIds);
            for (AutofillId id : editableIds) {
                if (!targetIds.contains(id)) {
                    targetIds.add(id);
                }
            }

            if (targetIds.isEmpty()) {
                callback.onSuccess(null);
                return;
            }

            String generatedCpf = generateValidCpf();

            RemoteViews presentation = new RemoteViews(getPackageName(), R.layout.autofill_cpf_item);
            presentation.setTextViewText(R.id.autofill_cpf_text, "📄 CPF: " + generatedCpf);

            Dataset.Builder datasetBuilder = new Dataset.Builder();
            boolean hasAddedField = false;

            for (AutofillId id : targetIds) {
                datasetBuilder.setValue(id, AutofillValue.forText(generatedCpf), presentation);
                hasAddedField = true;
            }

            if (!hasAddedField) {
                callback.onSuccess(null);
                return;
            }

            FillResponse response = new FillResponse.Builder()
                    .addDataset(datasetBuilder.build())
                    .build();

            callback.onSuccess(response);
        } catch (Exception e) {
            callback.onSuccess(null);
        }
    }

    private void traverseNode(AssistStructure.ViewNode node, List<AutofillId> focusedIds, List<AutofillId> editableIds) {
        if (node == null) return;

        AutofillId autofillId = node.getAutofillId();
        if (autofillId != null) {
            boolean isFocused = node.isFocused();
            String className = node.getClassName() != null ? node.getClassName() : "";
            boolean isEditText = className.contains("EditText")
                    || className.contains("AutoComplete")
                    || node.getInputType() != 0
                    || node.getAutofillType() == View.AUTOFILL_TYPE_TEXT
                    || node.getHtmlInfo() != null;

            if (isFocused) {
                focusedIds.add(autofillId);
            } else if (isEditText) {
                editableIds.add(autofillId);
            }
        }

        int childrenCount = node.getChildCount();
        for (int i = 0; i < childrenCount; i++) {
            traverseNode(node.getChildAt(i), focusedIds, editableIds);
        }
    }

    @Override
    public void onSaveRequest(SaveRequest request, SaveCallback callback) {
        callback.onSuccess();
    }

    /**
     * Gera um CPF de 11 dígitos matematicamente válido (cálculo oficial Módulo 11).
     */
    public static String generateValidCpf() {
        Random random = new Random();
        int[] digits = new int[11];

        for (int i = 0; i < 9; i++) {
            digits[i] = random.nextInt(10);
        }
        // Evitar todos os dígitos iguais
        boolean allSame = true;
        for (int i = 1; i < 9; i++) {
            if (digits[i] != digits[0]) {
                allSame = false;
                break;
            }
        }
        if (allSame) {
            digits[8] = (digits[0] + 1) % 10;
        }

        // 1º dígito verificador
        int sum1 = 0;
        for (int i = 0; i < 9; i++) {
            sum1 += digits[i] * (10 - i);
        }
        int rem1 = sum1 % 11;
        digits[9] = (rem1 < 2) ? 0 : (11 - rem1);

        // 2º dígito verificador
        int sum2 = 0;
        for (int i = 0; i < 10; i++) {
            sum2 += digits[i] * (11 - i);
        }
        int rem2 = sum2 % 11;
        digits[10] = (rem2 < 2) ? 0 : (11 - rem2);

        StringBuilder sb = new StringBuilder(11);
        for (int d : digits) {
            sb.append(d);
        }
        return sb.toString();
    }
}
