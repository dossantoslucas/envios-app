package com.enviosextra.app;

import android.app.assist.AssistStructure;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.CancellationSignal;
import android.service.autofill.AutofillService;
import android.service.autofill.Dataset;
import android.service.autofill.FillCallback;
import android.service.autofill.FillContext;
import android.service.autofill.FillRequest;
import android.service.autofill.FillResponse;
import android.service.autofill.SaveCallback;
import android.service.autofill.SaveRequest;
import android.text.InputType;
import android.view.View;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillValue;
import android.widget.RemoteViews;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Serviço nativo de Preenchimento Automático (AutofillService) do Android.
 * - Atua exclusivamente no app de entregas (com.mercadoenvios.crowdsourcing).
 * - Não lê nenhum texto ou rótulo da tela.
 * - Mantém apenas 1 única opção limpa de CPF (11 dígitos) na caixinha flutuante.
 */
@RequiresApi(api = Build.VERSION_CODES.O)
public class CpfAutofillService extends AutofillService {

    private static class InputFieldNode {
        final AutofillId id;
        final boolean isNumeric;
        final boolean isFocused;

        InputFieldNode(AutofillId id, boolean isNumeric, boolean isFocused) {
            this.id = id;
            this.isNumeric = isNumeric;
            this.isFocused = isFocused;
        }
    }

    @Override
    public void onFillRequest(FillRequest request, CancellationSignal cancellationSignal, FillCallback callback) {
        try {
            List<FillContext> contexts = request.getFillContexts();
            if (contexts == null || contexts.isEmpty()) {
                callback.onSuccess(null);
                return;
            }

            AssistStructure structure = contexts.get(contexts.size() - 1).getStructure();
            if (structure == null) {
                callback.onSuccess(null);
                return;
            }

            if (structure.getActivityComponent() != null) {
                String pkg = structure.getActivityComponent().getPackageName();
                // Executa exclusivamente no aplicativo de entregas (nunca no WhatsApp, ChatGPT, VagoApp, etc.)
                if (pkg == null || !pkg.equals("com.mercadoenvios.crowdsourcing")) {
                    callback.onSuccess(null);
                    return;
                }
            }

            List<InputFieldNode> allInputFields = new ArrayList<>();
            int nodes = structure.getWindowNodeCount();
            for (int i = 0; i < nodes; i++) {
                AssistStructure.WindowNode windowNode = structure.getWindowNodeAt(i);
                AssistStructure.ViewNode rootNode = windowNode.getRootViewNode();
                collectInputFields(rootNode, allInputFields);
            }

            if (allInputFields.isEmpty()) {
                callback.onSuccess(null);
                return;
            }

            // Seleção inteligente sem ler textos da tela:
            // 1) Se houver campo(s) estritamente numérico(s), seleciona apenas ele(s).
            // 2) Se for tela virtual/híbrida onde nenhum campo reportou TYPE_CLASS_NUMBER:
            //    - Se houver apenas 1 campo na tela (tela "Recebe..."), seleciona esse único campo.
            //    - Se houver 2+ campos na tela (tela "Complete os dados", onde o 1º é Nome e o 2º é CPF),
            //      ignora o 1º campo (Nome) e seleciona apenas a partir do 2º campo (CPF)!
            List<AutofillId> targetIds = new ArrayList<>();
            for (InputFieldNode field : allInputFields) {
                if (field.isNumeric && !targetIds.contains(field.id)) {
                    targetIds.add(field.id);
                }
            }

            if (targetIds.isEmpty()) {
                if (allInputFields.size() == 1) {
                    targetIds.add(allInputFields.get(0).id);
                } else {
                    for (int i = 1; i < allInputFields.size(); i++) {
                        AutofillId id = allInputFields.get(i).id;
                        if (!targetIds.contains(id)) {
                            targetIds.add(id);
                        }
                    }
                }
            }

            if (targetIds.isEmpty()) {
                callback.onSuccess(null);
                return;
            }

            FillResponse.Builder responseBuilder = new FillResponse.Builder();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                responseBuilder.setFlags(FillResponse.FLAG_DISABLE_ACTIVITY_ONLY);
            }

            Pattern matchAnyFilter = Pattern.compile(".*", Pattern.DOTALL);
            boolean hasAddedDataset = false;

            for (AutofillId id : targetIds) {
                String generatedCpf = generateUniqueValidCpf(this);

                RemoteViews presentation = new RemoteViews(getPackageName(), R.layout.autofill_cpf_item);
                presentation.setTextViewText(R.id.autofill_cpf_text, "📄 CPF: " + generatedCpf);

                Dataset.Builder datasetBuilder = new Dataset.Builder();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    datasetBuilder.setValue(id, AutofillValue.forText(generatedCpf), matchAnyFilter, presentation);
                } else {
                    datasetBuilder.setValue(id, AutofillValue.forText(generatedCpf), presentation);
                }

                responseBuilder.addDataset(datasetBuilder.build());
                hasAddedDataset = true;
            }

            if (!hasAddedDataset) {
                callback.onSuccess(null);
                return;
            }

            callback.onSuccess(responseBuilder.build());
        } catch (Exception e) {
            callback.onSuccess(null);
        }
    }

    /**
     * Coleta todos os campos editáveis da tela sem ler nenhum texto ou rótulo.
     */
    private void collectInputFields(AssistStructure.ViewNode node, List<InputFieldNode> fields) {
        if (node == null) return;

        AutofillId autofillId = node.getAutofillId();
        if (autofillId != null && node.getVisibility() == View.VISIBLE) {
            int inputType = node.getInputType();
            int inputClass = inputType & InputType.TYPE_MASK_CLASS;
            String className = node.getClassName() != null ? node.getClassName() : "";

            boolean isEditableField = className.contains("EditText")
                    || className.contains("AutoComplete")
                    || inputType != 0
                    || node.getAutofillType() == View.AUTOFILL_TYPE_TEXT
                    || node.getHtmlInfo() != null;

            if (isEditableField) {
                boolean isNumeric = (inputClass == InputType.TYPE_CLASS_NUMBER)
                        || (inputClass == InputType.TYPE_CLASS_PHONE);
                fields.add(new InputFieldNode(autofillId, isNumeric, node.isFocused()));
            }
        }

        int childrenCount = node.getChildCount();
        for (int i = 0; i < childrenCount; i++) {
            collectInputFields(node.getChildAt(i), fields);
        }
    }

    @Override
    public void onSaveRequest(SaveRequest request, SaveCallback callback) {
        callback.onSuccess();
    }

    /**
     * Gera um CPF válido de 11 dígitos garantindo que nunca repita um CPF já gerado anteriormente.
     */
    public static String generateUniqueValidCpf(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
        Set<String> usedCpfs = new HashSet<>(prefs.getStringSet("used_cpfs_history", new HashSet<>()));

        String cpf = generateValidCpf();
        int attempts = 0;
        while (usedCpfs.contains(cpf) && attempts < 20) {
            cpf = generateValidCpf();
            attempts++;
        }

        if (usedCpfs.size() > 5000) {
            usedCpfs.clear();
        }
        usedCpfs.add(cpf);
        prefs.edit().putStringSet("used_cpfs_history", usedCpfs).apply();

        return cpf;
    }

    /**
     * Gera um CPF de 11 dígitos matematicamente válido (cálculo oficial Módulo 11).
     */
    public static String generateValidCpf() {
        Random random = new Random();
        int[] digits = new int[11];

        for (int i = 0; i < 9; i++) {
            digits[i] = random.nextInt(10);
        }
        boolean allSame = true;
        for (int i = 1; i < 9; i++) {
            if (digits[i] != digits[0]) {
                allSame = false;
                break;
            }
        }
        if (allSame) {
            digits[8] = (digits[0] + 1) % 10;
        }

        int sum1 = 0;
        for (int i = 0; i < 9; i++) {
            sum1 += digits[i] * (10 - i);
        }
        int rem1 = sum1 % 11;
        digits[9] = (rem1 < 2) ? 0 : (11 - rem1);

        int sum2 = 0;
        for (int i = 0; i < 10; i++) {
            sum2 += digits[i] * (11 - i);
        }
        int rem2 = sum2 % 11;
        digits[10] = (rem2 < 2) ? 0 : (11 - rem2);

        StringBuilder sb = new StringBuilder(11);
        for (int d : digits) {
            sb.append(d);
        }
        return sb.toString();
    }
}
