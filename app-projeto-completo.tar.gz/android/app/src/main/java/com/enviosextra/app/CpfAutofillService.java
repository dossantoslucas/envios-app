package com.enviosextra.app;

import android.app.assist.AssistStructure;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.CancellationSignal;
import android.service.autofill.AutofillService;
import android.service.autofill.Dataset;
import android.service.autofill.FillCallback;
import android.service.autofill.FillContext;
import android.service.autofill.FillRequest;
import android.service.autofill.FillResponse;
import android.service.autofill.SaveCallback;
import android.service.autofill.SaveRequest;
import android.text.InputType;
import android.view.View;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillValue;
import android.widget.RemoteViews;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Serviço nativo de Preenchimento Automático (AutofillService) do Android.
 * - Cria um Dataset INDEPENDENTE para cada campo (assim nunca preenche "Nome e sobrenome" junto com "CPF",
 *   e digitar o nome primeiro nunca bloqueia a caixinha flutuante de aparecer automaticamente no campo CPF).
 * - Garante que cada CPF sorteado nunca se repita.
 */
@RequiresApi(api = Build.VERSION_CODES.O)
public class CpfAutofillService extends AutofillService {

    private static class FieldCandidate {
        final AutofillId id;
        final boolean isFocused;
        final boolean isNumeric;
        final boolean isNameField;

        FieldCandidate(AutofillId id, boolean isFocused, boolean isNumeric, boolean isNameField) {
            this.id = id;
            this.isFocused = isFocused;
            this.isNumeric = isNumeric;
            this.isNameField = isNameField;
        }
    }

    private String lastSeenLabel = "";

    @Override
    public void onFillRequest(FillRequest request, CancellationSignal cancellationSignal, FillCallback callback) {
        try {
            List<FillContext> contexts = request.getFillContexts();
            if (contexts == null || contexts.isEmpty()) {
                callback.onSuccess(null);
                return;
            }

            AssistStructure structure = contexts.get(contexts.size() - 1).getStructure();
            if (structure == null) {
                callback.onSuccess(null);
                return;
            }

            // Não exibir dentro do próprio EnviosExtraCalc
            if (structure.getActivityComponent() != null &&
                getPackageName().equals(structure.getActivityComponent().getPackageName())) {
                callback.onSuccess(null);
                return;
            }

            List<FieldCandidate> candidates = new ArrayList<>();
            lastSeenLabel = "";

            int nodes = structure.getWindowNodeCount();
            for (int i = 0; i < nodes; i++) {
                AssistStructure.WindowNode windowNode = structure.getWindowNodeAt(i);
                AssistStructure.ViewNode rootNode = windowNode.getRootViewNode();
                traverseNode(rootNode, candidates);
            }

            if (candidates.isEmpty()) {
                callback.onSuccess(null);
                return;
            }

            // Verificar se existe pelo menos um campo que NÃO seja de Nome (ex: o campo de CPF)
            boolean hasNonNameField = false;
            for (FieldCandidate c : candidates) {
                if (!c.isNameField) {
                    hasNonNameField = true;
                    break;
                }
            }

            FillResponse.Builder responseBuilder = new FillResponse.Builder();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                responseBuilder.setFlags(FillResponse.FLAG_DISABLE_ACTIVITY_ONLY);
            }

            Pattern matchAnyFilter = Pattern.compile(".*", Pattern.DOTALL);
            boolean hasAddedDataset = false;
            Set<AutofillId> addedIds = new HashSet<>();

            for (FieldCandidate candidate : candidates) {
                if (addedIds.contains(candidate.id)) continue;

                // Se a tela tem "Nome e sobrenome" e também o campo "CPF", ignora o campo de Nome
                // para não atrapalhar a digitação do nome e focar apenas no CPF
                if (hasNonNameField && candidate.isNameField) {
                    continue;
                }

                addedIds.add(candidate.id);

                // Gerar um CPF único para este campo específico
                String generatedCpf = generateUniqueValidCpf(this);

                RemoteViews presentation = new RemoteViews(getPackageName(), R.layout.autofill_cpf_item);
                presentation.setTextViewText(R.id.autofill_cpf_text, "📄 CPF: " + generatedCpf);

                // IMPORTANTE: Cada Dataset contém APENAS UM AutofillId!
                // Isso garante que:
                // 1) Clicar na sugestão preenche SOMENTE o campo clicado (nunca preenche Nome e sobrenome junto)
                // 2) Digitar o Nome primeiro não esconde a caixinha automática quando você clica no campo CPF!
                Dataset.Builder datasetBuilder = new Dataset.Builder();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    datasetBuilder.setValue(candidate.id, AutofillValue.forText(generatedCpf), matchAnyFilter, presentation);
                } else {
                    datasetBuilder.setValue(candidate.id, AutofillValue.forText(generatedCpf), presentation);
                }

                responseBuilder.addDataset(datasetBuilder.build());
                hasAddedDataset = true;
            }

            if (!hasAddedDataset) {
                callback.onSuccess(null);
                return;
            }

            callback.onSuccess(responseBuilder.build());
        } catch (Exception e) {
            callback.onSuccess(null);
        }
    }

    private void traverseNode(AssistStructure.ViewNode node, List<FieldCandidate> candidates) {
        if (node == null) return;

        CharSequence nodeText = node.getText();
        CharSequence nodeHint = node.getHint();
        CharSequence contentDesc = node.getContentDescription();
        String idEntry = node.getIdEntry() != null ? node.getIdEntry() : "";
        String className = node.getClassName() != null ? node.getClassName() : "";

        String combinedMeta = ((nodeHint != null ? nodeHint.toString() : "") + " "
                + (contentDesc != null ? contentDesc.toString() : "") + " "
                + idEntry).toLowerCase(Locale.ROOT);

        AutofillId autofillId = node.getAutofillId();
        int inputType = node.getInputType();
        boolean isEditText = className.contains("EditText")
                || className.contains("AutoComplete")
                || inputType != 0
                || node.getAutofillType() == View.AUTOFILL_TYPE_TEXT
                || node.getHtmlInfo() != null;

        // Se é um TextView comum (rótulo acima do campo, ex: "Nome e sobrenome" ou "CPF"), guarda o último rótulo visto
        if (!isEditText && nodeText != null && nodeText.length() > 0 && nodeText.length() < 40) {
            lastSeenLabel = nodeText.toString().toLowerCase(Locale.ROOT);
        }

        if (autofillId != null && (isEditText || node.isFocused())) {
            boolean isNumeric = (inputType & InputType.TYPE_CLASS_NUMBER) != 0;
            boolean isNameField = !isNumeric && (
                    combinedMeta.contains("nome")
                    || combinedMeta.contains("name")
                    || lastSeenLabel.contains("nome")
                    || lastSeenLabel.contains("name")
            );

            candidates.add(new FieldCandidate(autofillId, node.isFocused(), isNumeric, isNameField));
            // Limpa o rótulo após associá-lo ao campo logo abaixo dele
            lastSeenLabel = "";
        }

        int childrenCount = node.getChildCount();
        for (int i = 0; i < childrenCount; i++) {
            traverseNode(node.getChildAt(i), candidates);
        }
    }

    @Override
    public void onSaveRequest(SaveRequest request, SaveCallback callback) {
        callback.onSuccess();
    }

    /**
     * Gera um CPF válido de 11 dígitos garantindo que nunca repita um CPF já gerado anteriormente.
     */
    public static String generateUniqueValidCpf(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
        Set<String> usedCpfs = new HashSet<>(prefs.getStringSet("used_cpfs_history", new HashSet<>()));

        String cpf = generateValidCpf();
        int attempts = 0;
        while (usedCpfs.contains(cpf) && attempts < 20) {
            cpf = generateValidCpf();
            attempts++;
        }

        // Limitar histórico a 5.000 CPFs para não ocupar memória
        if (usedCpfs.size() > 5000) {
            usedCpfs.clear();
        }
        usedCpfs.add(cpf);
        prefs.edit().putStringSet("used_cpfs_history", usedCpfs).apply();

        return cpf;
    }

    /**
     * Gera um CPF de 11 dígitos matematicamente válido (cálculo oficial Módulo 11).
     */
    public static String generateValidCpf() {
        Random random = new Random();
        int[] digits = new int[11];

        for (int i = 0; i < 9; i++) {
            digits[i] = random.nextInt(10);
        }
        boolean allSame = true;
        for (int i = 1; i < 9; i++) {
            if (digits[i] != digits[0]) {
                allSame = false;
                break;
            }
        }
        if (allSame) {
            digits[8] = (digits[0] + 1) % 10;
        }

        int sum1 = 0;
        for (int i = 0; i < 9; i++) {
            sum1 += digits[i] * (10 - i);
        }
        int rem1 = sum1 % 11;
        digits[9] = (rem1 < 2) ? 0 : (11 - rem1);

        int sum2 = 0;
        for (int i = 0; i < 10; i++) {
            sum2 += digits[i] * (11 - i);
        }
        int rem2 = sum2 % 11;
        digits[10] = (rem2 < 2) ? 0 : (11 - rem2);

        StringBuilder sb = new StringBuilder(11);
        for (int d : digits) {
            sb.append(d);
        }
        return sb.toString();
    }
}
