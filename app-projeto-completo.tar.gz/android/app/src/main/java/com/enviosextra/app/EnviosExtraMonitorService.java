package com.enviosextra.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Robô Autônomo com duas missões:
 * 1. Monitor de Contagem & Aduana do Envios Extra ("X unidades no veículo").
 * 2. Detector de Telefone no Discador -> Dispara Botão Flutuante do WhatsApp Direto (Sem salvar contato).
 */
public class EnviosExtraMonitorService extends AccessibilityService {

    private static final String TAG = "EnviosExtraRobot";

    // Padrões Regex
    private final Pattern unitsPattern = Pattern.compile("(\\d+)\\s+unidades\\s+no\\s+ve[ií]culo", Pattern.CASE_INSENSITIVE);
    // Detecta números como +55 81 98749-0572, 81987490572, (81) 98749-0572
    private final Pattern phonePattern = Pattern.compile("(?:\\+?55\\s?)?(?:\\(?\\d{2}\\)?\\s?)?9?\\d{4}[-\\s]?\\d{4}");

    // Estado da contagem
    private int pendingTypedCount = -1;
    private boolean isInAduanaFlow = false;

    // Janela Flutuante do WhatsApp
    private WindowManager windowManager;
    private View floatingView;
    private String currentDetectedPhone = null;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        CharSequence pkg = event.getPackageName();
        String pkgName = pkg != null ? pkg.toString().toLowerCase() : "";

        // Se estivermos dentro do próprio WhatsApp ou o pacote não for discador/telefone/contatos,
        // garantimos que o botão flutuante seja fechado imediatamente
        if (pkgName.contains("whatsapp") || pkgName.contains("launcher") || pkgName.contains("home")) {
            if (floatingView != null) {
                removeFloatingButton();
            }
        }

        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) return;

        try {
            // 1. Detectar Telefone EXCLUSIVAMENTE quando estiver em apps de discador / telefone / contatos
            boolean isDialerApp = pkgName.contains("dialer") || pkgName.contains("phone") || pkgName.contains("telecom") || pkgName.contains("contact");
            if (isDialerApp) {
                detectPhoneNumberForWhatsApp(rootNode);
            } else if (floatingView != null) {
                removeFloatingButton();
            }

            // 2. Fluxo de Contagem e Aduana do Envios Extra
            if (pkgName.contains("mercadolibre") || pkgName.contains("envios")) {
                inspectScreenContent(rootNode);
            }
        } finally {
            rootNode.recycle();
        }
    }

    /**
     * Procura números de telefone na tela do discador (ex: +55 81 98749-0572)
     */
    private void detectPhoneNumberForWhatsApp(AccessibilityNodeInfo root) {
        String allText = extractAllText(root);
        Matcher matcher = phonePattern.matcher(allText);

        if (matcher.find()) {
            String rawPhone = matcher.group(0);
            // Limpa caracteres especiais, deixando apenas números
            String cleanDigits = rawPhone.replaceAll("\\D", "");

            // Se for um número de celular brasileiro válido (10 ou 11 dígitos, ou 12/13 com DDI 55)
            if (cleanDigits.length() >= 10 && cleanDigits.length() <= 13) {
                // Garante que o DDI 55 esteja presente
                if (!cleanDigits.startsWith("55") && cleanDigits.length() <= 11) {
                    cleanDigits = "55" + cleanDigits;
                }

                if (!cleanDigits.equals(currentDetectedPhone)) {
                    currentDetectedPhone = cleanDigits;
                    showFloatingWhatsAppButton(cleanDigits);
                }
                return;
            }
        }

        // Se não há telefone no discador, remove o botão flutuante
        if (floatingView != null) {
            removeFloatingButton();
        }
    }

    /**
     * Exibe o botão flutuante verde "Chamar no WhatsApp" sobre o discador
     */
    private void showFloatingWhatsAppButton(final String phoneNumber) {
        mainHandler.post(() -> {
            if (floatingView != null) {
                removeFloatingButton();
            }

            // Layout do botão flutuante com botão de fechar (X)
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.HORIZONTAL);
            layout.setPadding(20, 10, 16, 10);
            layout.setBackgroundColor(Color.parseColor("#25D366")); // Verde WhatsApp

            Button btn = new Button(this);
            btn.setText("💬 WhatsApp");
            btn.setTextColor(Color.WHITE);
            btn.setTextSize(14);
            btn.setBackgroundColor(Color.TRANSPARENT);

            btn.setOnClickListener(v -> {
                openWhatsAppDirect(phoneNumber);
                removeFloatingButton();
            });

            Button btnClose = new Button(this);
            btnClose.setText("✕");
            btnClose.setTextColor(Color.WHITE);
            btnClose.setTextSize(14);
            btnClose.setBackgroundColor(Color.TRANSPARENT);
            btnClose.setOnClickListener(v -> removeFloatingButton());

            layout.addView(btn);
            layout.addView(btnClose);
            floatingView = layout;

            int layoutFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    layoutFlag,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
            );

            params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            params.y = 120; // Fica logo abaixo do campo de número do discador

            try {
                windowManager.addView(floatingView, params);
            } catch (Exception e) {
                Log.e(TAG, "Erro ao adicionar botão flutuante: " + e.getMessage());
            }
        });
    }

    private void removeFloatingButton() {
        mainHandler.post(() -> {
            if (floatingView != null) {
                try {
                    windowManager.removeView(floatingView);
                } catch (Exception ignored) {}
                floatingView = null;
                currentDetectedPhone = null;
            }
        });
    }

    /**
     * Dispara o WhatsApp diretamente na conversa com mensagem padrão de entrega
     */
    private void openWhatsAppDirect(String phoneDigits) {
        try {
            String defaultMsg = "Olá! Sou o entregador do Mercado Livre e estou no seu endereço com a sua encomenda.";
            String encodedMsg = URLEncoder.encode(defaultMsg, "UTF-8");
            String url = "https://wa.me/" + phoneDigits + "?text=" + encodedMsg;

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            Toast.makeText(this, "Abrindo WhatsApp com " + phoneDigits, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o WhatsApp", Toast.LENGTH_SHORT).show();
        }
    }

    // =========================================================================
    // PARTE 2: LÓGICA DE CONTAGEM E ADUANA DO ENVIOS EXTRA
    // =========================================================================

    private void inspectScreenContent(AccessibilityNodeInfo node) {
        checkCountingScreen(node);
        checkConfirmationOrError(node);

        if (isInAduanaFlow) {
            handleAduanaMapAndList(node);
        }
    }

    private void checkCountingScreen(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> editTexts = root.findAccessibilityNodeInfosByViewId("android:id/input");
        if (editTexts == null || editTexts.isEmpty()) {
            findEditTextRecursive(root);
        }
    }

    private void findEditTextRecursive(AccessibilityNodeInfo node) {
        if (node == null) return;

        if ("android.widget.EditText".equals(node.getClassName())) {
            CharSequence text = node.getText();
            if (text != null && text.toString().matches("\\d+")) {
                int count = Integer.parseInt(text.toString());
                if (count > 0 && count < 300) {
                    this.pendingTypedCount = count;
                }
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            findEditTextRecursive(node.getChild(i));
        }
    }

    private void checkConfirmationOrError(AccessibilityNodeInfo root) {
        String screenText = extractAllText(root).toLowerCase(Locale.ROOT);

        if (pendingTypedCount > 0 && (screenText.contains("contagem correta") || screenText.contains("tudo certo") || screenText.contains("veículo liberado"))) {
            saveOfficialCount(pendingTypedCount, "Contagem correta no galpão");
            pendingTypedCount = -1;
            isInAduanaFlow = false;
            return;
        }

        if (pendingTypedCount > 0 && (screenText.contains("divergência") || screenText.contains("recontar") || screenText.contains("aduana") || screenText.contains("contagem incorreta"))) {
            pendingTypedCount = -1;
            isInAduanaFlow = true;
        }
    }

    private void handleAduanaMapAndList(AccessibilityNodeInfo root) {
        String screenText = extractAllText(root);

        Matcher matcher = unitsPattern.matcher(screenText);
        if (matcher.find()) {
            int unitsCount = Integer.parseInt(matcher.group(1));
            saveOfficialCount(unitsCount, "Capturado na Lista (Unidades no veículo)");
            isInAduanaFlow = false;
            performGlobalAction(GLOBAL_ACTION_BACK);
            return;
        }

        List<AccessibilityNodeInfo> listButtons = root.findAccessibilityNodeInfosByText("Lista");
        if (listButtons != null && !listButtons.isEmpty()) {
            for (AccessibilityNodeInfo btn : listButtons) {
                if (btn.isClickable()) {
                    btn.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    break;
                }
            }
        }
    }

    private void saveOfficialCount(int packages, String reason) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        SharedPreferences prefs = getSharedPreferences("EnviosExtraCalcData", Context.MODE_PRIVATE);
        prefs.edit()
             .putInt("last_packages_" + today, packages)
             .putString("last_capture_reason", reason)
             .putLong("last_capture_time", System.currentTimeMillis())
             .apply();

        Toast.makeText(this, "📦 " + packages + " pacotes registrados no Envios Extra Calc!", Toast.LENGTH_LONG).show();
    }

    private String extractAllText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder sb = new StringBuilder();
        if (node.getText() != null) {
            sb.append(node.getText()).append(" ");
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            sb.append(extractAllText(node.getChild(i))).append(" ");
        }
        return sb.toString();
    }

    @Override
    public void onInterrupt() {
        removeFloatingButton();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        removeFloatingButton();
    }
}
