package com.enviosextra.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Robô Autônomo com duas missões:
 * 1. Monitor de Contagem & Aduana do Envios Extra ("X unidades no veículo").
 * 2. Detector de Telefone no Discador -> Dispara Botão Flutuante do WhatsApp Direto (Sem salvar contato).
 */
public class EnviosExtraMonitorService extends AccessibilityService {

    private static final String TAG = "EnviosExtraRobot";

    // Padrões Regex
    private final Pattern unitsPattern = Pattern.compile("(\\d+)\\s+unidades\\s+no\\s+ve[ií]culo", Pattern.CASE_INSENSITIVE);
    
    // Regex flexível: reconhece desde "+55 81 98749-0572" até "98749-0572" e números digitados no discador
    private final Pattern phonePattern = Pattern.compile("(?:\\+?55[\\s.-]?)?(?:\\(?([1-9][0-9])\\)?[\\s.-]?)?(9?[0-9]{4}[\\s.-]?[0-9]{4})");

    // Estado da contagem
    private int pendingTypedCount = -1;
    private boolean isInAduanaFlow = false;

    // Janela Flutuante do WhatsApp
    private WindowManager windowManager;
    private View floatingView = null;
    private String currentDetectedPhone = null;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean isButtonDismissedManually = false;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        CharSequence pkg = event.getPackageName();
        String pkgName = pkg != null ? pkg.toString().toLowerCase() : "";

        // Se o usuário entrou no WhatsApp ou foi para a Home, garante que o botão suma
        if (pkgName.contains("whatsapp") || pkgName.contains("launcher") || pkgName.contains("home")) {
            removeFloatingButton();
            isButtonDismissedManually = false;
            return;
        }

        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) return;

        try {
            // Verifica se está em um app de discador / chamadas / contatos ou com botões de chamada ("Ligar", "Teclado")
            String allText = extractAllText(rootNode);
            boolean hasDialerWords = allText.contains("Ligar") || allText.contains("Teclado") || allText.contains("Chamada") || allText.contains("Discador");
            boolean isDialerPackage = pkgName.contains("dialer") || pkgName.contains("phone") || pkgName.contains("telecom") || pkgName.contains("contact");

            if (isDialerPackage || hasDialerWords) {
                detectPhoneNumberForWhatsApp(allText);
            } else if (floatingView != null) {
                removeFloatingButton();
                isButtonDismissedManually = false;
            }

            // 2. Fluxo de Contagem e Aduana do Envios Extra
            if (pkgName.contains("mercadolibre") || pkgName.contains("envios")) {
                inspectScreenContent(rootNode);
            }
        } finally {
            rootNode.recycle();
        }
    }

    /**
     * Procura números de telefone no texto extraído da tela
     */
    private void detectPhoneNumberForWhatsApp(String allText) {
        Matcher matcher = phonePattern.matcher(allText);

        while (matcher.find()) {
            String rawMatch = matcher.group(0);
            String cleanDigits = rawMatch.replaceAll("\\D", "");

            // Se for telefone fixo ou celular com DDD (10 ou 11 dígitos) ou com 55 (12 ou 13 dígitos)
            if (cleanDigits.length() >= 10 && cleanDigits.length() <= 13) {
                if (!cleanDigits.startsWith("55") && (cleanDigits.length() == 10 || cleanDigits.length() == 11)) {
                    cleanDigits = "55" + cleanDigits;
                }

                // Se mudou o número, resetamos o fechamento manual
                if (!cleanDigits.equals(currentDetectedPhone)) {
                    currentDetectedPhone = cleanDigits;
                    isButtonDismissedManually = false;
                }

                if (!isButtonDismissedManually && floatingView == null) {
                    showFloatingWhatsAppButton(cleanDigits);
                }
                return;
            }
        }

        // Se apagou o número do discador e não há mais telefone válido
        if (floatingView != null && !isButtonDismissedManually) {
            removeFloatingButton();
        }
    }

    /**
     * Exibe o botão flutuante estilizado e totalmente clicável sobre o discador
     */
    private void showFloatingWhatsAppButton(final String phoneNumber) {
        mainHandler.post(() -> {
            if (floatingView != null) {
                removeFloatingButton();
            }

            // Container visual moderno com cantos arredondados e sombra
            LinearLayout container = new LinearLayout(this);
            container.setOrientation(LinearLayout.HORIZONTAL);
            container.setGravity(Gravity.CENTER_VERTICAL);
            container.setPadding(35, 20, 25, 20);

            GradientDrawable background = new GradientDrawable();
            background.setColor(Color.parseColor("#25D366")); // Verde WhatsApp
            background.setCornerRadius(60f); // Bordas arredondadas tipo pílula
            background.setStroke(2, Color.parseColor("#1DA851"));
            container.setBackground(background);

            // Texto / Ação de Abrir
            TextView tvAction = new TextView(this);
            tvAction.setText("💬 Abrir WhatsApp");
            tvAction.setTextColor(Color.WHITE);
            tvAction.setTextSize(15);
            tvAction.setTypeface(null, android.graphics.Typeface.BOLD);
            tvAction.setPadding(0, 0, 30, 0);

            // Botão Fechar (X)
            TextView tvClose = new TextView(this);
            tvClose.setText("✕");
            tvClose.setTextColor(Color.WHITE);
            tvClose.setTextSize(18);
            tvClose.setPadding(20, 10, 20, 10);
            tvClose.setTypeface(null, android.graphics.Typeface.BOLD);

            // Clique no botão X: fecha e não reabre para o mesmo número
            tvClose.setOnClickListener(v -> {
                isButtonDismissedManually = true;
                removeFloatingButton();
            });

            // Clique na área verde: dispara o WhatsApp direto
            container.setOnClickListener(v -> {
                openWhatsAppDirect(phoneNumber);
                removeFloatingButton();
            });

            // Adiciona views
            container.addView(tvAction);
            container.addView(tvClose);
            floatingView = container;

            int layoutFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            // Importante: NÃO incluir FLAG_NOT_TOUCHABLE para que o clique funcione de primeira!
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    layoutFlag,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
            );

            params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            params.y = 100; // Altura ideal no topo do discador

            try {
                windowManager.addView(floatingView, params);
            } catch (Exception e) {
                Log.e(TAG, "Erro ao desenhar botão: " + e.getMessage());
            }
        });
    }

    private void removeFloatingButton() {
        mainHandler.post(() -> {
            if (floatingView != null) {
                try {
                    windowManager.removeView(floatingView);
                } catch (Exception ignored) {}
                floatingView = null;
            }
        });
    }

    /**
     * Dispara o WhatsApp diretamente na conversa com mensagem padrão de entrega
     */
    private void openWhatsAppDirect(String phoneDigits) {
        try {
            String defaultMsg = "Olá! Sou o entregador do Mercado Livre e estou no seu endereço com a sua encomenda.";
            String encodedMsg = URLEncoder.encode(defaultMsg, "UTF-8");
            String url = "https://wa.me/" + phoneDigits + "?text=" + encodedMsg;

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            Toast.makeText(this, "Iniciando WhatsApp...", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o WhatsApp", Toast.LENGTH_SHORT).show();
        }
    }

    // =========================================================================
    // PARTE 2: LÓGICA DE CONTAGEM E ADUANA DO ENVIOS EXTRA
    // =========================================================================

    private void inspectScreenContent(AccessibilityNodeInfo node) {
        checkCountingScreen(node);
        checkConfirmationOrError(node);

        if (isInAduanaFlow) {
            handleAduanaMapAndList(node);
        }
    }

    private void checkCountingScreen(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> editTexts = root.findAccessibilityNodeInfosByViewId("android:id/input");
        if (editTexts == null || editTexts.isEmpty()) {
            findEditTextRecursive(root);
        }
    }

    private void findEditTextRecursive(AccessibilityNodeInfo node) {
        if (node == null) return;

        if ("android.widget.EditText".equals(node.getClassName())) {
            CharSequence text = node.getText();
            if (text != null && text.toString().matches("\\d+")) {
                int count = Integer.parseInt(text.toString());
                if (count > 0 && count < 300) {
                    this.pendingTypedCount = count;
                }
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            findEditTextRecursive(node.getChild(i));
        }
    }

    private void checkConfirmationOrError(AccessibilityNodeInfo root) {
        String screenText = extractAllText(root).toLowerCase(Locale.ROOT);

        if (pendingTypedCount > 0 && (screenText.contains("contagem correta") || screenText.contains("tudo certo") || screenText.contains("veículo liberado"))) {
            saveOfficialCount(pendingTypedCount, "Contagem correta no galpão");
            pendingTypedCount = -1;
            isInAduanaFlow = false;
            return;
        }

        if (pendingTypedCount > 0 && (screenText.contains("divergência") || screenText.contains("recontar") || screenText.contains("aduana") || screenText.contains("contagem incorreta"))) {
            pendingTypedCount = -1;
            isInAduanaFlow = true;
        }
    }

    private void handleAduanaMapAndList(AccessibilityNodeInfo root) {
        String screenText = extractAllText(root);

        Matcher matcher = unitsPattern.matcher(screenText);
        if (matcher.find()) {
            int unitsCount = Integer.parseInt(matcher.group(1));
            saveOfficialCount(unitsCount, "Capturado na Lista (Unidades no veículo)");
            isInAduanaFlow = false;
            performGlobalAction(GLOBAL_ACTION_BACK);
            return;
        }

        List<AccessibilityNodeInfo> listButtons = root.findAccessibilityNodeInfosByText("Lista");
        if (listButtons != null && !listButtons.isEmpty()) {
            for (AccessibilityNodeInfo btn : listButtons) {
                if (btn.isClickable()) {
                    btn.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    break;
                }
            }
        }
    }

    private void saveOfficialCount(int packages, String reason) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        SharedPreferences prefs = getSharedPreferences("EnviosExtraCalcData", Context.MODE_PRIVATE);
        prefs.edit()
             .putInt("last_packages_" + today, packages)
             .putString("last_capture_reason", reason)
             .putLong("last_capture_time", System.currentTimeMillis())
             .apply();

        Toast.makeText(this, "📦 " + packages + " pacotes registrados no Envios Extra Calc!", Toast.LENGTH_LONG).show();
    }

    private String extractAllText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder sb = new StringBuilder();
        if (node.getText() != null) {
            sb.append(node.getText()).append(" ");
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            sb.append(extractAllText(node.getChild(i))).append(" ");
        }
        return sb.toString();
    }

    @Override
    public void onInterrupt() {
        removeFloatingButton();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        removeFloatingButton();
    }
}
