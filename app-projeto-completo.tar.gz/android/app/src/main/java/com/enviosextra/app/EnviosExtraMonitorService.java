package com.enviosextra.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Monitor de Contagem & Aduana do Envios Extra.
 * Código limpo focado exclusivamente na leitura de pacotes no galpão e aduana.
 */
public class EnviosExtraMonitorService extends AccessibilityService {

    private static final String TAG = "EnviosExtraRobot";

    private final Pattern unitsPattern = Pattern.compile("(\\d+)\\s+unidades\\s+no\\s+ve[ií]culo", Pattern.CASE_INSENSITIVE);
    private int pendingTypedCount = -1;
    private boolean isInAduanaFlow = false;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        try {
            AccessibilityServiceInfo info = new AccessibilityServiceInfo();
            info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS |
                         AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            info.notificationTimeout = 100;
            setServiceInfo(info);
            Log.d(TAG, "EnviosExtraMonitorService conectado com sucesso.");
        } catch (Exception e) {
            Log.e(TAG, "Erro ao conectar serviço: " + e.getMessage());
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        CharSequence pkg = event.getPackageName();
        String pkgName = pkg != null ? pkg.toString().toLowerCase() : "";

        // Executa apenas quando estiver dentro do app do Mercado Envios Extra / Mercado Livre
        if (!pkgName.contains("mercadolibre") && !pkgName.contains("envios")) {
            return;
        }

        AccessibilityNodeInfo rootNode = null;
        try {
            rootNode = getRootInActiveWindow();
        } catch (Exception ignored) {}

        if (rootNode == null) return;

        try {
            inspectScreenContent(rootNode);
        } catch (Exception e) {
            Log.e(TAG, "Erro na inspeção de tela: " + e.getMessage());
        } finally {
            try {
                rootNode.recycle();
            } catch (Exception ignored) {}
        }
    }

    private void inspectScreenContent(AccessibilityNodeInfo node) {
        checkCountingScreen(node);
        checkConfirmationOrError(node);

        if (isInAduanaFlow) {
            handleAduanaMapAndList(node);
        }
    }

    private void checkCountingScreen(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> editTexts = root.findAccessibilityNodeInfosByViewId("android:id/input");
        if (editTexts == null || editTexts.isEmpty()) {
            findEditTextRecursive(root);
        }
    }

    private void findEditTextRecursive(AccessibilityNodeInfo node) {
        if (node == null) return;

        if ("android.widget.EditText".equals(node.getClassName())) {
            CharSequence text = node.getText();
            if (text != null && text.toString().matches("\\d+")) {
                int count = Integer.parseInt(text.toString());
                if (count > 0 && count < 300) {
                    this.pendingTypedCount = count;
                }
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            findEditTextRecursive(node.getChild(i));
        }
    }

    private void checkConfirmationOrError(AccessibilityNodeInfo root) {
        String screenText = extractAllText(root).toLowerCase(Locale.ROOT);

        if (pendingTypedCount > 0 && (screenText.contains("contagem correta") || screenText.contains("tudo certo") || screenText.contains("veículo liberado"))) {
            saveOfficialCount(pendingTypedCount, "Contagem correta no galpão");
            pendingTypedCount = -1;
            isInAduanaFlow = false;
            return;
        }

        if (pendingTypedCount > 0 && (screenText.contains("divergência") || screenText.contains("recontar") || screenText.contains("aduana") || screenText.contains("contagem incorreta"))) {
            pendingTypedCount = -1;
            isInAduanaFlow = true;
        }
    }

    private void handleAduanaMapAndList(AccessibilityNodeInfo root) {
        String screenText = extractAllText(root);

        Matcher matcher = unitsPattern.matcher(screenText);
        if (matcher.find()) {
            int unitsCount = Integer.parseInt(matcher.group(1));
            saveOfficialCount(unitsCount, "Capturado na Lista (Unidades no veículo)");
            isInAduanaFlow = false;
            performGlobalAction(GLOBAL_ACTION_BACK);
            return;
        }

        List<AccessibilityNodeInfo> listButtons = root.findAccessibilityNodeInfosByText("Lista");
        if (listButtons != null && !listButtons.isEmpty()) {
            for (AccessibilityNodeInfo btn : listButtons) {
                if (btn.isClickable()) {
                    btn.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    break;
                }
            }
        }
    }

    private void saveOfficialCount(int packages, String reason) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        SharedPreferences prefs = getSharedPreferences("EnviosExtraCalcData", Context.MODE_PRIVATE);
        prefs.edit()
             .putInt("last_packages_" + today, packages)
             .putString("last_capture_reason", reason)
             .putLong("last_capture_time", System.currentTimeMillis())
             .apply();

        Toast.makeText(this, "📦 " + packages + " pacotes registrados no Envios Extra Calc!", Toast.LENGTH_LONG).show();
    }

    private String extractAllText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder sb = new StringBuilder();
        if (node.getText() != null) {
            sb.append(node.getText()).append(" ");
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            sb.append(extractAllText(node.getChild(i))).append(" ");
        }
        return sb.toString();
    }

    @Override
    public void onInterrupt() {}
}
