package com.enviosextra.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
