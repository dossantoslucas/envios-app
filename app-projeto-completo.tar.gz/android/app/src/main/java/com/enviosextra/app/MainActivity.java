package com.enviosextra.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.autofill.AutofillManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

import org.json.JSONObject;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            WebView webView = getBridge().getWebView();
            if (webView != null) {
                webView.addJavascriptInterface(new NativeBridge(this), "AndroidNative");
            }
        } catch (Exception ignored) {}
    }

    public static class NativeBridge {
        private final Context context;

        public NativeBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public String consumeQuickEntries() {
            SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
            String json = prefs.getString("pending_quick_entries", "[]");
            if (!"[]".equals(json)) {
                prefs.edit().putString("pending_quick_entries", "[]").apply();
            }
            return json;
        }

        @JavascriptInterface
        public void setWhatsAppMessage(String msg) {
            SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
            prefs.edit().putString("whatsapp_custom_msg", msg).apply();
        }

        @JavascriptInterface
        public String getWhatsAppMessage() {
            SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
            return prefs.getString("whatsapp_custom_msg", "");
        }

        @JavascriptInterface
        public void openQuickAddPopup() {
            Intent intent = new Intent(context, QuickAddPackagesActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }

        @JavascriptInterface
        public boolean isAutofillEnabled() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                AutofillManager afm = context.getSystemService(AutofillManager.class);
                return afm != null && afm.hasEnabledAutofillServices();
            }
            return false;
        }

        @JavascriptInterface
        public void openAutofillSettings() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE);
                    intent.setData(Uri.parse("package:" + context.getPackageName()));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                } catch (Exception e) {
                    Intent fallback = new Intent(Settings.ACTION_SETTINGS);
                    fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(fallback);
                }
            }
        }

        @JavascriptInterface
        public boolean isBatteryUnrestricted() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                return pm != null && pm.isIgnoringBatteryOptimizations(context.getPackageName());
            }
            return true;
        }

        @JavascriptInterface
        public void requestUnrestrictedBattery() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(Uri.parse("package:" + context.getPackageName()));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                } catch (Exception ignored) {}
            }
        }

        // =========================================================================
        // MÉTODOS DO RADAR INTELIGENTE DE LOTES (OPÇÕES 1, 2 E 3 INDEPENDENTES)
        // =========================================================================

        @JavascriptInterface
        public boolean isNotificationListenerEnabled() {
            String pkgName = context.getPackageName();
            final String flat = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
            if (!TextUtils.isEmpty(flat)) {
                final String[] names = flat.split(":");
                for (String name : names) {
                    final ComponentName cn = ComponentName.unflattenFromString(name);
                    if (cn != null && TextUtils.equals(pkgName, cn.getPackageName())) {
                        return true;
                    }
                }
            }
            return false;
        }

        @JavascriptInterface
        public void openNotificationListenerSettings() {
            try {
                Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public boolean isOverlayPermissionGranted() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return Settings.canDrawOverlays(context);
            }
            return true;
        }

        @JavascriptInterface
        public void openOverlayPermissionSettings() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + context.getPackageName()));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                } catch (Exception ignored) {}
            }
        }

        @JavascriptInterface
        public String getRadarConfig() {
            SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
            try {
                JSONObject obj = new JSONObject();
                obj.put("opt1Timer", prefs.getBoolean("radar_opt1_timer", true));
                obj.put("opt2Pacer", prefs.getBoolean("radar_opt2_pacer", true));
                obj.put("opt3Log", prefs.getBoolean("radar_opt3_log", true));
                obj.put("durationMin", prefs.getInt("radar_duration_min", 10));
                obj.put("pacerSec", prefs.getInt("radar_pacer_sec", 45));
                obj.put("pacerBeep", prefs.getBoolean("radar_pacer_beep", true));
                obj.put("isRunning", RadarNotificationService.isTimerCurrentlyRunning());
                return obj.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void saveRadarConfig(boolean opt1Timer, boolean opt2Pacer, boolean opt3Log, int durationMin, int pacerSec, boolean pacerBeep) {
            SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
            prefs.edit()
                    .putBoolean("radar_opt1_timer", opt1Timer)
                    .putBoolean("radar_opt2_pacer", opt2Pacer)
                    .putBoolean("radar_opt3_log", opt3Log)
                    .putInt("radar_duration_min", Math.max(1, durationMin))
                    .putInt("radar_pacer_sec", Math.max(15, pacerSec))
                    .putBoolean("radar_pacer_beep", pacerBeep)
                    .apply();
        }

        @JavascriptInterface
        public String getRadarLogs() {
            SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
            return prefs.getString("radar_batch_logs", "[]");
        }

        @JavascriptInterface
        public void clearRadarLogs() {
            SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
            prefs.edit().putString("radar_batch_logs", "[]").apply();
        }

        @JavascriptInterface
        public void startManualRadarTimer(String label) {
            try {
                RadarNotificationService svc = RadarNotificationService.getInstance();
                if (svc != null) {
                    svc.startFloatingBatchTimer(label != null ? label : "Lote Manual (10 min)");
                } else {
                    Intent intent = new Intent(context, RadarNotificationService.class);
                    intent.setAction(RadarNotificationService.ACTION_START_TEST_TIMER);
                    intent.putExtra("label", label != null ? label : "Lote Manual (10 min)");
                    context.startService(intent);
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void stopManualRadarTimer() {
            try {
                RadarNotificationService svc = RadarNotificationService.getInstance();
                if (svc != null) {
                    svc.stopFloatingBatchTimer();
                } else {
                    Intent intent = new Intent(context, RadarNotificationService.class);
                    intent.setAction(RadarNotificationService.ACTION_STOP_TIMER);
                    context.startService(intent);
                }
            } catch (Exception ignored) {}
        }
    }
}
