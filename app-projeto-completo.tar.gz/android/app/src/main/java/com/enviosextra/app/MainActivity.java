package com.enviosextra.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.autofill.AutofillManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            WebView webView = getBridge().getWebView();
            if (webView != null) {
                webView.addJavascriptInterface(new NativeBridge(this), "AndroidNative");
            }
        } catch (Exception ignored) {}
    }

    public static class NativeBridge {
        private final Context context;

        public NativeBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public String consumeQuickEntries() {
            SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
            String json = prefs.getString("pending_quick_entries", "[]");
            if (!"[]".equals(json)) {
                prefs.edit().putString("pending_quick_entries", "[]").apply();
            }
            return json;
        }

        @JavascriptInterface
        public void setWhatsAppMessage(String msg) {
            SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
            prefs.edit().putString("whatsapp_custom_msg", msg).apply();
        }

        @JavascriptInterface
        public String getWhatsAppMessage() {
            SharedPreferences prefs = context.getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
            return prefs.getString("whatsapp_custom_msg", "");
        }

        @JavascriptInterface
        public void openQuickAddPopup() {
            Intent intent = new Intent(context, QuickAddPackagesActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }

        @JavascriptInterface
        public boolean isAutofillEnabled() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                AutofillManager afm = context.getSystemService(AutofillManager.class);
                return afm != null && afm.hasEnabledAutofillServices();
            }
            return false;
        }

        @JavascriptInterface
        public void openAutofillSettings() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE);
                    intent.setData(Uri.parse("package:" + context.getPackageName()));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                } catch (Exception e) {
                    Intent fallback = new Intent(Settings.ACTION_SETTINGS);
                    fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(fallback);
                }
            }
        }
    }
}
