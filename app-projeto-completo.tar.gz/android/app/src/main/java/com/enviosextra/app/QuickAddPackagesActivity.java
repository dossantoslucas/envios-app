package com.enviosextra.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Sobreposição rápida (Dialog Activity) que abre ao clicar no botão da barra de notificações (Wi-Fi/Lanterna).
 * Permite digitar 50 -> OK -> 55 -> OK como uma calculadora rápida de rotas sem sair do que está fazendo.
 */
public class QuickAddPackagesActivity extends Activity {

    private int sessionCount = 0;
    private int sessionTotalPackages = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        // Fundo escurecido suave ao redor do popup
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#88000000"));
        root.setPadding(48, 48, 48, 48);
        root.setOnClickListener(v -> finish());

        // Card Branco Central
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(56, 52, 56, 48);
        card.setClickable(true); // Impede fechar ao clicar dentro do card

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.WHITE);
        cardBg.setCornerRadius(42f);
        card.setBackground(cardBg);

        // Título
        TextView title = new TextView(this);
        title.setText("📦 + Somar Pacotes");
        title.setTextSize(19);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.parseColor("#1E293B"));
        title.setGravity(Gravity.CENTER);

        // Subtítulo dinâmico que mostra o acumulado
        final TextView subtitle = new TextView(this);
        subtitle.setText("Digite a quantidade e toque em Somar (+).\nVocê pode lançar vários dias seguidos!");
        subtitle.setTextSize(13);
        subtitle.setTextColor(Color.parseColor("#64748B"));
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 14, 0, 32);

        // Campo Numérico
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("Ex: 50");
        input.setTextSize(24);
        input.setTypeface(null, Typeface.BOLD);
        input.setGravity(Gravity.CENTER);
        input.setTextColor(Color.parseColor("#0F172A"));
        input.setPadding(28, 28, 28, 28);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);

        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(Color.parseColor("#F8FAFC"));
        inputBg.setCornerRadius(24f);
        inputBg.setStroke(3, Color.parseColor("#CBD5E1"));
        input.setBackground(inputBg);

        // Botões: Concluir | Somar (+)
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, 36, 0, 0);
        btnRow.setWeightSum(2f);

        Button btnClose = new Button(this);
        btnClose.setText("Concluir");
        btnClose.setTextColor(Color.parseColor("#475569"));
        btnClose.setTextSize(14);
        btnClose.setTypeface(null, Typeface.BOLD);
        GradientDrawable closeBg = new GradientDrawable();
        closeBg.setColor(Color.parseColor("#F1F5F9"));
        closeBg.setCornerRadius(24f);
        btnClose.setBackground(closeBg);
        LinearLayout.LayoutParams lpClose = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.9f);
        lpClose.setMargins(0, 0, 16, 0);
        btnClose.setLayoutParams(lpClose);
        btnClose.setOnClickListener(v -> finish());

        Button btnAdd = new Button(this);
        btnAdd.setText("+ Somar Rota");
        btnAdd.setTextColor(Color.WHITE);
        btnAdd.setTextSize(14);
        btnAdd.setTypeface(null, Typeface.BOLD);
        GradientDrawable addBg = new GradientDrawable();
        addBg.setColor(Color.parseColor("#2563EB"));
        addBg.setCornerRadius(24f);
        btnAdd.setBackground(addBg);
        LinearLayout.LayoutParams lpAdd = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f);
        lpAdd.setMargins(16, 0, 0, 0);
        btnAdd.setLayoutParams(lpAdd);

        Runnable addAction = () -> {
            String valStr = input.getText().toString().trim();
            if (valStr.isEmpty()) {
                finish();
                return;
            }
            try {
                int count = Integer.parseInt(valStr);
                if (count > 0) {
                    saveQuickPackageEntry(count);
                    sessionCount++;
                    sessionTotalPackages += count;
                    input.setText("");
                    subtitle.setText("✅ +" + count + " salvos! (" + sessionCount + " lançamentos = " + sessionTotalPackages + " pac.)\nDigite o próximo valor ou toque em Concluir.");
                    subtitle.setTextColor(Color.parseColor("#16A34A"));
                    subtitle.setTypeface(null, Typeface.BOLD);
                }
            } catch (Exception e) {
                Toast.makeText(this, "Digite um número válido", Toast.LENGTH_SHORT).show();
            }
        };

        btnAdd.setOnClickListener(v -> addAction.run());
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                addAction.run();
                return true;
            }
            return false;
        });

        btnRow.addView(btnClose);
        btnRow.addView(btnAdd);

        card.addView(title);
        card.addView(subtitle);
        card.addView(input);
        card.addView(btnRow);

        root.addView(card, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        setContentView(root);

        if (getWindow() != null) {
            getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        input.requestFocus();
    }

    private void saveQuickPackageEntry(int count) {
        try {
            SharedPreferences prefs = getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
            String existingJson = prefs.getString("pending_quick_entries", "[]");
            JSONArray arr = new JSONArray(existingJson);

            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

            JSONObject obj = new JSONObject();
            obj.put("id", String.valueOf(System.currentTimeMillis() + sessionCount));
            obj.put("date", today);
            obj.put("loaded", count);
            obj.put("delivered", count);
            obj.put("failed", 0);
            obj.put("notes", "Adicionado pelo botão rápido");

            arr.put(obj);
            prefs.edit().putString("pending_quick_entries", arr.toString()).apply();
        } catch (Exception ignored) {}
    }
}
