package com.enviosextra.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import java.net.URLEncoder;

/**
 * Atividade nativa de PROCESS_TEXT.
 * Quando o entregador seleciona o telefone no discador ou em qualquer app,
 * surge no menu: "Chamar no WhatsApp".
 * Lê a mensagem configurada no app (padrão ou personalizada pelo motorista).
 */
public class WhatsAppDirectActivity extends Activity {

    private static final String DEFAULT_MSG = "Olá! Sou o entregador do Mercado Livre e estou no seu endereço com a sua encomenda.";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        CharSequence selectedText = getIntent().getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
        if (selectedText == null) {
            selectedText = getIntent().getStringExtra(Intent.EXTRA_TEXT);
        }

        if (selectedText != null) {
            String raw = selectedText.toString();
            String cleanDigits = raw.replaceAll("\\D", "");

            if (cleanDigits.length() >= 10 && cleanDigits.length() <= 13) {
                if (!cleanDigits.startsWith("55") && (cleanDigits.length() == 10 || cleanDigits.length() == 11)) {
                    cleanDigits = "55" + cleanDigits;
                }

                try {
                    SharedPreferences prefs = getSharedPreferences("EnviosExtraPrefs", Context.MODE_PRIVATE);
                    String msgToUse = prefs.getString("whatsapp_custom_msg", DEFAULT_MSG);
                    if (msgToUse == null || msgToUse.trim().isEmpty()) {
                        msgToUse = DEFAULT_MSG;
                    }

                    String encodedMsg = URLEncoder.encode(msgToUse, "UTF-8");
                    String url = "https://wa.me/" + cleanDigits + "?text=" + encodedMsg;

                    Intent waIntent = new Intent(Intent.ACTION_VIEW);
                    waIntent.setData(Uri.parse(url));
                    waIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(waIntent);

                    Toast.makeText(this, "Abrindo conversa no WhatsApp...", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Não foi possível abrir o WhatsApp", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Selecione um número de telefone com DDD válido", Toast.LENGTH_LONG).show();
            }
        }

        finish();
    }
}
