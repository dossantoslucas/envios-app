package com.radarlotes.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.PowerManager;

/**
 * Recebe o disparo do AlarmManager no horário programado (ou no reinício do celular)
 * e abre imediatamente o Cronômetro Flutuante na tela, acordando a tela se necessário.
 */
public class RadarAlarmReceiver extends BroadcastReceiver {

    public static final String ACTION_TRIGGER_SCHEDULED_RADAR = "com.radarlotes.app.ACTION_TRIGGER_SCHEDULED_RADAR";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        String action = intent.getAction();

        if (Intent.ACTION_BOOT_COMPLETED.equals(action) || "android.intent.action.QUICKBOOT_POWERON".equals(action)) {
            RadarAlarmScheduler.rescheduleAllAlarms(context);
            return;
        }

        if (ACTION_TRIGGER_SCHEDULED_RADAR.equals(action)) {
            SharedPreferences prefs = context.getSharedPreferences("RadarLotesPrefs", Context.MODE_PRIVATE);
            boolean alarmsEnabled = prefs.getBoolean("radar_opt4_alarms", true);
            if (!alarmsEnabled) return;

            String timeStr = intent.getStringExtra("alarm_time");
            String label = intent.getStringExtra("alarm_label");
            String display = "⏰ Alarme " + (timeStr != null ? timeStr : "") + (label != null && !label.isEmpty() ? " • " + label : "");

            // Acordar a tela do celular por alguns segundos para o cronômetro aparecer e manter acesa
            try {
                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    PowerManager.WakeLock wl = pm.newWakeLock(
                            PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                            "radarlotes:AlarmWakeLock"
                    );
                    wl.acquire(10000L);
                }
            } catch (Exception ignored) {}

            // Disparar o cronômetro flutuante
            try {
                RadarNotificationService svc = RadarNotificationService.getInstance();
                if (svc != null) {
                    svc.startFloatingBatchTimer(display);
                } else {
                    Intent svcIntent = new Intent(context, RadarNotificationService.class);
                    svcIntent.setAction(RadarNotificationService.ACTION_START_TEST_TIMER);
                    svcIntent.putExtra("label", display);
                    context.startService(svcIntent);
                }
            } catch (Exception ignored) {}

            // Reagendar automaticamente para o dia seguinte
            RadarAlarmScheduler.rescheduleAllAlarms(context);
        }
    }
}
