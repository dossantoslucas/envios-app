package com.radarlotes.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/**
 * Agenda e gerencia os alarmes diários exatos (AlarmManager) para disparar o Cronômetro Flutuante
 * nos horários escolhidos pelo motorista, além do disparo automático por notificação.
 */
public class RadarAlarmScheduler {

    public static void rescheduleAllAlarms(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("RadarLotesPrefs", Context.MODE_PRIVATE);
        boolean alarmsMasterEnabled = prefs.getBoolean("radar_opt4_alarms", true);
        String rawJson = prefs.getString("radar_scheduled_alarms", "[]");

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        // Primeiro cancela slots antigos (até 50 alarmes)
        for (int i = 0; i < 50; i++) {
            Intent cancelIntent = new Intent(context, RadarAlarmReceiver.class);
            cancelIntent.setAction(RadarAlarmReceiver.ACTION_TRIGGER_SCHEDULED_RADAR);
            PendingIntent pi = PendingIntent.getBroadcast(
                    context,
                    7000 + i,
                    cancelIntent,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
            );
            if (pi != null) {
                am.cancel(pi);
                pi.cancel();
            }
        }

        if (!alarmsMasterEnabled) return;

        try {
            JSONArray arr = new JSONArray(rawJson);
            long now = System.currentTimeMillis();

            for (int i = 0; i < Math.min(arr.length(), 50); i++) {
                JSONObject item = arr.getJSONObject(i);
                boolean enabled = item.optBoolean("enabled", true);
                if (!enabled) continue;

                String timeStr = item.optString("time", ""); // formato "HH:mm"
                String label = item.optString("label", "Alarme de Lote");
                String[] parts = timeStr.split(":");
                if (parts.length != 2) continue;

                int hour = Integer.parseInt(parts[0].trim());
                int minute = Integer.parseInt(parts[1].trim());

                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY, hour);
                cal.set(Calendar.MINUTE, minute);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);

                // Se o horário de hoje já passou, agenda para amanhã no mesmo horário
                if (cal.getTimeInMillis() <= now) {
                    cal.add(Calendar.DAY_OF_YEAR, 1);
                }

                Intent intent = new Intent(context, RadarAlarmReceiver.class);
                intent.setAction(RadarAlarmReceiver.ACTION_TRIGGER_SCHEDULED_RADAR);
                intent.putExtra("alarm_index", i);
                intent.putExtra("alarm_time", timeStr);
                intent.putExtra("alarm_label", label);

                PendingIntent pi = PendingIntent.getBroadcast(
                        context,
                        7000 + i,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );

                scheduleExact(am, cal.getTimeInMillis(), pi);
            }
        } catch (Exception ignored) {}
    }

    private static void scheduleExact(AlarmManager am, long triggerAtMillis, PendingIntent pi) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
            }
        } catch (SecurityException se) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
            }
        }
    }
}
