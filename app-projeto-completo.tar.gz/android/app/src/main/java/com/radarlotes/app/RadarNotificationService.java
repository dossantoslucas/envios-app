package com.radarlotes.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RadarNotificationService extends NotificationListenerService {

    public static final String TARGET_PKG = "com.mercadoenvios.crowdsourcing";
    public static final String ACTION_START_TEST_TIMER = "com.radarlotes.app.ACTION_START_TEST_TIMER";
    public static final String ACTION_STOP_TIMER = "com.radarlotes.app.ACTION_STOP_TIMER";

    private static RadarNotificationService instance;

    private WindowManager windowManager;
    private View floatingView;
    private TextView tvTimerCountdown;
    private TextView tvNextRefreshHint;
    private LinearLayout cardContainer;
    private GradientDrawable cardBgDrawable;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable tickerRunnable;
    private long timerEndTimeMs = 0;
    private int secondsSinceLastAlert = 0;
    private boolean isTimerRunning = false;

    public static RadarNotificationService getInstance() {
        return instance;
    }

    public static boolean isTimerCurrentlyRunning() {
        return instance != null && instance.isTimerRunning;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            if (ACTION_START_TEST_TIMER.equals(action)) {
                String label = intent.getStringExtra("label");
                startFloatingBatchTimer(label != null ? label : "Lote Manual / Teste");
            } else if (ACTION_STOP_TIMER.equals(action)) {
                stopFloatingBatchTimer();
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stopFloatingBatchTimer();
        if (instance == this) {
            instance = null;
        }
        super.onDestroy();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        String pkg = sbn.getPackageName();
        if (!TARGET_PKG.equals(pkg)) return;

        if (sbn.isOngoing()) return;
        String channelId = "";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && sbn.getNotification() != null) {
            channelId = sbn.getNotification().getChannelId() != null ? sbn.getNotification().getChannelId() : "";
        }
        if ("RTT_CHANNEL".equalsIgnoreCase(channelId) || "geofences".equalsIgnoreCase(channelId) || "upload_photo".equalsIgnoreCase(channelId)) {
            return;
        }

        String title = "";
        String text = "";
        if (sbn.getNotification() != null && sbn.getNotification().extras != null) {
            Bundle extras = sbn.getNotification().extras;
            CharSequence t = extras.getCharSequence("android.title");
            CharSequence txt = extras.getCharSequence("android.bigText");
            if (txt == null || txt.length() == 0) {
                txt = extras.getCharSequence("android.text");
            }
            if (t != null) title = t.toString().trim();
            if (txt != null) text = txt.toString().trim();
        }

        if (title.isEmpty() && text.isEmpty()) return;

        SharedPreferences prefs = getSharedPreferences("RadarLotesPrefs", Context.MODE_PRIVATE);
        boolean logEnabled = prefs.getBoolean("radar_opt3_log", true);
        boolean timerEnabled = prefs.getBoolean("radar_opt1_timer", true);

        String nowTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        String nowDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());

        if (logEnabled) {
            saveBatchLog(prefs, nowDate, nowTime, channelId, title, text);
        }

        if (timerEnabled) {
            String summary = !text.isEmpty() ? text : title;
            if (summary.length() > 36) {
                summary = summary.substring(0, 36) + "...";
            }
            final String displayLabel = "Lote " + nowTime.substring(0, 5) + (summary.isEmpty() ? "" : " • " + summary);
            handler.post(() -> startFloatingBatchTimer(displayLabel));
        }
    }

    private void saveBatchLog(SharedPreferences prefs, String date, String time, String channelId, String title, String text) {
        try {
            String raw = prefs.getString("radar_batch_logs", "[]");
            JSONArray arr = new JSONArray(raw);

            if (arr.length() > 0) {
                JSONObject last = arr.getJSONObject(0);
                if (time.equals(last.optString("time")) && date.equals(last.optString("date"))) {
                    return;
                }
            }

            JSONObject entry = new JSONObject();
            entry.put("id", String.valueOf(System.currentTimeMillis()));
            entry.put("date", date);
            entry.put("time", time);
            entry.put("channel", channelId.isEmpty() ? "Geral" : channelId);
            entry.put("title", title.isEmpty() ? "Alerta Envios Extra" : title);
            entry.put("text", text);

            JSONArray nextArr = new JSONArray();
            nextArr.put(entry);
            for (int i = 0; i < Math.min(arr.length(), 99); i++) {
                nextArr.put(arr.get(i));
            }
            prefs.edit().putString("radar_batch_logs", nextArr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public void startFloatingBatchTimer(String labelText) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            return;
        }

        SharedPreferences prefs = getSharedPreferences("RadarLotesPrefs", Context.MODE_PRIVATE);
        int durationMinutes = prefs.getInt("radar_duration_min", 10);
        boolean pacerEnabled = prefs.getBoolean("radar_opt2_pacer", true);

        timerEndTimeMs = System.currentTimeMillis() + (durationMinutes * 60 * 1000L);
        secondsSinceLastAlert = 0;
        isTimerRunning = true;

        if (floatingView == null) {
            createFloatingOverlay(labelText, pacerEnabled);
        } else {
            updateKeepScreenOnFlag(pacerEnabled);
        }

        if (tickerRunnable != null) {
            handler.removeCallbacks(tickerRunnable);
        }

        triggerAlertFeedback(false, true);

        tickerRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isTimerRunning) return;

                long remainingMs = timerEndTimeMs - System.currentTimeMillis();
                if (remainingMs <= 0) {
                    stopFloatingBatchTimer();
                    return;
                }

                long totalSec = remainingMs / 1000L;
                long mins = totalSec / 60L;
                long secs = totalSec % 60L;

                if (tvTimerCountdown != null) {
                    tvTimerCountdown.setText(String.format(Locale.getDefault(), "%02d:%02d", mins, secs));
                }

                SharedPreferences livePrefs = getSharedPreferences("RadarLotesPrefs", Context.MODE_PRIVATE);
                boolean livePacer = livePrefs.getBoolean("radar_opt2_pacer", true);
                int liveInterval = Math.max(15, livePrefs.getInt("radar_pacer_sec", 45));
                boolean liveBeep = livePrefs.getBoolean("radar_pacer_beep", true);

                if (livePacer) {
                    secondsSinceLastAlert++;
                    int nextIn = Math.max(0, liveInterval - secondsSinceLastAlert);
                    if (tvNextRefreshHint != null) {
                        if (nextIn <= 3) {
                            tvNextRefreshHint.setText("🔄 PUXE A LISTA AGORA!");
                            tvNextRefreshHint.setTextColor(Color.parseColor("#FEF08A"));
                            if (cardBgDrawable != null) {
                                cardBgDrawable.setColor(Color.parseColor("#B45309"));
                            }
                        } else {
                            tvNextRefreshHint.setText("🔄 Atualizar em " + nextIn + "s (Tela acesa)");
                            tvNextRefreshHint.setTextColor(Color.parseColor("#BBF7D0"));
                            if (cardBgDrawable != null) {
                                cardBgDrawable.setColor(Color.parseColor("#0F172A"));
                            }
                        }
                    }

                    if (secondsSinceLastAlert >= liveInterval) {
                        secondsSinceLastAlert = 0;
                        triggerAlertFeedback(liveBeep, true);
                    }
                } else {
                    if (tvNextRefreshHint != null) {
                        tvNextRefreshHint.setText("Janela de lote ativa");
                        tvNextRefreshHint.setTextColor(Color.parseColor("#CBD5E1"));
                    }
                }

                handler.postDelayed(this, 1000L);
            }
        };

        handler.post(tickerRunnable);
    }

    private void createFloatingOverlay(String labelText, boolean keepScreenOn) {
        try {
            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);

            cardContainer = new LinearLayout(this);
            cardContainer.setOrientation(LinearLayout.VERTICAL);
            cardContainer.setPadding(30, 20, 30, 20);

            cardBgDrawable = new GradientDrawable();
            cardBgDrawable.setColor(Color.parseColor("#0F172A"));
            cardBgDrawable.setCornerRadius(34f);
            cardBgDrawable.setStroke(3, Color.parseColor("#22C55E"));
            cardContainer.setBackground(cardBgDrawable);

            LinearLayout topRow = new LinearLayout(this);
            topRow.setOrientation(LinearLayout.HORIZONTAL);
            topRow.setGravity(Gravity.CENTER_VERTICAL);

            TextView tvBadge = new TextView(this);
            tvBadge.setText("🟢 LOTE ");
            tvBadge.setTextSize(12);
            tvBadge.setTypeface(null, Typeface.BOLD);
            tvBadge.setTextColor(Color.parseColor("#4ADE80"));

            tvTimerCountdown = new TextView(this);
            tvTimerCountdown.setText("10:00");
            tvTimerCountdown.setTextSize(17);
            tvTimerCountdown.setTypeface(null, Typeface.BOLD);
            tvTimerCountdown.setTextColor(Color.WHITE);
            tvTimerCountdown.setPadding(6, 0, 20, 0);

            TextView btnClose = new TextView(this);
            btnClose.setText("✕ Fechar");
            btnClose.setTextSize(11);
            btnClose.setTypeface(null, Typeface.BOLD);
            btnClose.setTextColor(Color.parseColor("#FCA5A5"));
            btnClose.setPadding(16, 6, 8, 6);
            btnClose.setOnClickListener(v -> stopFloatingBatchTimer());

            topRow.addView(tvBadge);
            topRow.addView(tvTimerCountdown);
            topRow.addView(btnClose);

            TextView tvLabel = new TextView(this);
            tvLabel.setText(labelText);
            tvLabel.setTextSize(11);
            tvLabel.setTextColor(Color.parseColor("#E2E8F0"));
            tvLabel.setPadding(0, 4, 0, 2);

            tvNextRefreshHint = new TextView(this);
            tvNextRefreshHint.setText("🔄 Monitorando janela de 10 min...");
            tvNextRefreshHint.setTextSize(11);
            tvNextRefreshHint.setTypeface(null, Typeface.BOLD);
            tvNextRefreshHint.setTextColor(Color.parseColor("#BBF7D0"));

            cardContainer.addView(topRow);
            cardContainer.addView(tvLabel);
            cardContainer.addView(tvNextRefreshHint);
            root.addView(cardContainer);

            int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED;
            if (keepScreenOn) {
                flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            }

            final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    overlayType,
                    flags,
                    PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            params.y = 110;

            cardContainer.setOnTouchListener(new View.OnTouchListener() {
                private int initialX, initialY;
                private float initialTouchX, initialTouchY;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initialX = params.x;
                            initialY = params.y;
                            initialTouchX = event.getRawX();
                            initialTouchY = event.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            params.x = initialX + (int) (event.getRawX() - initialTouchX);
                            params.y = initialY + (int) (event.getRawY() - initialTouchY);
                            if (windowManager != null && floatingView != null) {
                                windowManager.updateViewLayout(floatingView, params);
                            }
                            return true;
                    }
                    return false;
                }
            });

            floatingView = root;
            windowManager.addView(floatingView, params);
        } catch (Exception ignored) {}
    }

    private void updateKeepScreenOnFlag(boolean keepScreenOn) {
        if (floatingView == null || windowManager == null) return;
        try {
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) floatingView.getLayoutParams();
            if (keepScreenOn) {
                lp.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            } else {
                lp.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            }
            windowManager.updateViewLayout(floatingView, lp);
        } catch (Exception ignored) {}
    }

    public void stopFloatingBatchTimer() {
        isTimerRunning = false;
        if (tickerRunnable != null) {
            handler.removeCallbacks(tickerRunnable);
            tickerRunnable = null;
        }
        if (floatingView != null && windowManager != null) {
            try {
                windowManager.removeView(floatingView);
            } catch (Exception ignored) {}
            floatingView = null;
        }
    }

    private void triggerAlertFeedback(boolean playBeep, boolean vibrate) {
        if (vibrate) {
            try {
                Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (vib != null && vib.hasVibrator()) {
                    long[] pattern = new long[]{0, 140, 90, 180};
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vib.vibrate(VibrationEffect.createWaveform(pattern, -1));
                    } else {
                        vib.vibrate(pattern, -1);
                    }
                }
            } catch (Exception ignored) {}
        }
        if (playBeep) {
            try {
                ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85);
                tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 220);
                handler.postDelayed(tg::release, 350);
            } catch (Exception ignored) {}
        }
    }
}
