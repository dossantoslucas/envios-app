import React, { useState, useEffect, useCallback } from 'react';
import { 
  Image as ImageIcon, 
  Award, 
  Trash2, 
  RefreshCw,
  MessageSquare,
  Check
} from 'lucide-react';
import { LEVEL_CRITERIA, determineLevel, compareWithLevelTarget } from './utils/calculator';
import { parseEnviosExtraImage } from './utils/ocrService';
import { parseRouteStopImage } from './utils/routeOcrService';

const DEFAULT_WHATSAPP_MSG = "Olá! Sou o entregador do Mercado Livre e estou no seu endereço com a sua encomenda.";

export default function App() {
  const [activeTab, setActiveTab] = useState('level'); // 'analyzer' | 'level' | 'whatsapp'

  // Dados extraídos da tela do print (salvos na memória para comparar sempre)
  const [points, setPoints] = useState(() => Number(localStorage.getItem('envios_points')) || 0);
  const [successRate, setSuccessRate] = useState(() => Number(localStorage.getItem('envios_success_rate')) || 0);
  const [noComplaintRate, setNoComplaintRate] = useState(() => Number(localStorage.getItem('envios_no_complaint_rate')) || 0);
  const [hasReadPrint, setHasReadPrint] = useState(() => localStorage.getItem('envios_has_read_print') === 'true');
  const [targetLevelKey, setTargetLevelKey] = useState('PLATINUM');

  const [imagePreview, setImagePreview] = useState(null);
  const [isProcessingOcr, setIsProcessingOcr] = useState(false);
  const [ocrProgress, setOcrProgress] = useState(0);

  // Rotas de entregas (salvas permanentemente na memória)
  const [entries, setEntries] = useState(() => {
    const saved = localStorage.getItem('envios_extra_entries');
    if (saved) {
      try { return JSON.parse(saved); } catch (_) {}
    }
    return [];
  });

  // Estados de Minimizar / Expandir na aba "Meu Nível" para deixar a tela limpa
  const [isMetricsExpanded, setIsMetricsExpanded] = useState(true);
  const [isCounterExpanded, setIsCounterExpanded] = useState(true);
  const [isHistoryExpanded, setIsHistoryExpanded] = useState(false);

  // Calculadora Rápida de Pacotes
  const [quickInput, setQuickInput] = useState('');
  const [isProcessingRouteBatch, setIsProcessingRouteBatch] = useState(false);
  const [batchProgress, setBatchProgress] = useState('');

  // Configuração da Mensagem do WhatsApp
  const [waMsgMode, setWaMsgMode] = useState(() => localStorage.getItem('envios_wa_mode') || 'default'); // 'default' | 'custom'
  const [customWaMsg, setCustomWaMsg] = useState(() => localStorage.getItem('envios_wa_custom_text') || '');
  const [waSavedFeedback, setWaSavedFeedback] = useState(false);

  // Persistir entradas no localStorage
  useEffect(() => {
    localStorage.setItem('envios_extra_entries', JSON.stringify(entries));
  }, [entries]);

  // Persistir dados do print no localStorage
  useEffect(() => {
    localStorage.setItem('envios_points', String(points));
    localStorage.setItem('envios_success_rate', String(successRate));
    localStorage.setItem('envios_no_complaint_rate', String(noComplaintRate));
    localStorage.setItem('envios_has_read_print', String(hasReadPrint));
  }, [points, successRate, noComplaintRate, hasReadPrint]);

  // Sincronizar mensagem do WhatsApp com o sistema Android nativo
  useEffect(() => {
    localStorage.setItem('envios_wa_mode', waMsgMode);
    localStorage.setItem('envios_wa_custom_text', customWaMsg);

    const activeMessage = (waMsgMode === 'custom' && customWaMsg.trim())
      ? customWaMsg.trim()
      : DEFAULT_WHATSAPP_MSG;

    if (window.AndroidNative && typeof window.AndroidNative.setWhatsAppMessage === 'function') {
      try {
        window.AndroidNative.setWhatsAppMessage(activeMessage);
      } catch (e) {
        console.error('Erro ao salvar msg no Android:', e);
      }
    }
  }, [waMsgMode, customWaMsg]);

  // Sincronizar pacotes adicionados pelo botão rápido da barra de notificações do Android
  const syncNativeQuickEntries = useCallback(() => {
    if (window.AndroidNative && typeof window.AndroidNative.consumeQuickEntries === 'function') {
      try {
        const rawJson = window.AndroidNative.consumeQuickEntries();
        if (rawJson && rawJson !== '[]') {
          const addedList = JSON.parse(rawJson);
          if (Array.isArray(addedList) && addedList.length > 0) {
            setEntries(prev => [...addedList.reverse(), ...prev]);
          }
        }
      } catch (e) {
        console.error('Erro ao ler pacotes rápidos do Android:', e);
      }
    }
  }, []);

  useEffect(() => {
    syncNativeQuickEntries();
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        syncNativeQuickEntries();
      }
    };
    window.addEventListener('focus', syncNativeQuickEntries);
    document.addEventListener('visibilitychange', handleVisibility);
    const interval = setInterval(syncNativeQuickEntries, 2000);
    return () => {
      window.removeEventListener('focus', syncNativeQuickEntries);
      document.removeEventListener('visibilitychange', handleVisibility);
      clearInterval(interval);
    };
  }, [syncNativeQuickEntries]);

  // Filtrar rotas pertencentes ao mês vigente
  const currentMonthPrefix = new Date().toISOString().slice(0, 7);
  const currentMonthEntries = entries.filter(item => item.date && item.date.startsWith(currentMonthPrefix));

  // Total de pacotes carregados no mês (salvo na memória e atualizado automaticamente)
  const totalLoadedInMonth = currentMonthEntries.reduce((acc, curr) => acc + (Number(curr.loaded) || 0), 0);

  // Nível atual e comparação automática com o total do mês salvo na memória
  const currentLevel = determineLevel(points, successRate, noComplaintRate);
  const comparison = compareWithLevelTarget(totalLoadedInMonth, points, successRate, noComplaintRate, targetLevelKey);

  // Leitura do Print "Meu Nível"
  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImagePreview(URL.createObjectURL(file));
    setIsProcessingOcr(true);
    setOcrProgress(10);

    try {
      const result = await parseEnviosExtraImage(file, (p) => setOcrProgress(p));
      if (result && result.success) {
        if (result.points !== undefined) setPoints(result.points);
        if (result.successRate !== undefined) setSuccessRate(result.successRate);
        if (result.noComplaintRate !== undefined) setNoComplaintRate(result.noComplaintRate);
        setHasReadPrint(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessingOcr(false);
      setOcrProgress(0);
    }
  };

  // Adicionar pacotes estilo Calculadora Rápida (50 -> OK -> 55 -> OK)
  const handleQuickAddSubmit = (e) => {
    e.preventDefault();
    const loaded = Number(quickInput) || 0;
    if (loaded <= 0) return;

    const today = new Date().toISOString().slice(0, 10);
    const newEntry = {
      id: Date.now().toString(),
      date: today,
      loaded,
      delivered: loaded,
      failed: 0,
      notes: `Rota #${currentMonthEntries.length + 1}`
    };

    setEntries(prev => [newEntry, ...prev]);
    setQuickInput('');
    if (window.navigator?.vibrate) window.navigator.vibrate(30);
  };

  // Processar múltiplos prints de rotas
  const handleBatchRouteUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setIsProcessingRouteBatch(true);
    const newAddedEntries = [];
    const today = new Date().toISOString().slice(0, 10);

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setBatchProgress(`Lendo print ${i + 1} de ${files.length}...`);
      try {
        const result = await parseRouteStopImage(file);
        if (result && result.success) {
          const loaded = result.totalStops;
          const delivered = result.visitedStops;
          const failed = Math.max(0, loaded - delivered);
          const entryDate = result.isoDate || today;

          newAddedEntries.push({
            id: (Date.now() + i).toString(),
            date: entryDate,
            loaded,
            delivered,
            failed,
            earnings: result.earnings || '',
            notes: `Print (${result.visitedStops}/${result.totalStops})`
          });
        }
      } catch (err) {
        console.error('Erro ao ler print:', err);
      }
    }

    if (newAddedEntries.length > 0) {
      setEntries(prev => [...newAddedEntries, ...prev]);
    }
    setIsProcessingRouteBatch(false);
    setBatchProgress('');
    e.target.value = '';
  };

  const handleDeleteEntry = (id) => {
    setEntries(entries.filter(item => item.id !== id));
  };

  return (
    <div className="app-container">
      {/* Barra Superior */}
      <header className="top-bar">
        <div className="top-bar-title">
          <span>📦</span> Envios Extra Calc
        </div>
        <div className={`badge ${currentLevel.badgeClass}`}>
          <Award size={14} />
          {currentLevel.name}
        </div>
      </header>

      {/* Abas de Navegação */}
      <nav className="nav-tabs">
        <button 
          className={`nav-tab-btn ${activeTab === 'analyzer' ? 'active' : ''}`}
          onClick={() => setActiveTab('analyzer')}
        >
          <ImageIcon size={16} /> Leitor Print
        </button>
        <button 
          className={`nav-tab-btn ${activeTab === 'level' ? 'active' : ''}`}
          onClick={() => setActiveTab('level')}
        >
          <Award size={16} /> Meu Nível
        </button>
        <button 
          className={`nav-tab-btn ${activeTab === 'whatsapp' ? 'active' : ''}`}
          onClick={() => setActiveTab('whatsapp')}
        >
          <MessageSquare size={16} /> WhatsApp
        </button>
      </nav>

      {/* Conteúdo Principal */}
      <main className="content-body">
        {/* ================================================================= */}
        {/* ABA 1: LEITOR PRINT (EXCLUSIVA PARA CARREGAR E LER O PRINT)       */}
        {/* ================================================================= */}
        {activeTab === 'analyzer' && (
          <div>
            <div className="card" style={{ textAlign: 'center', padding: '24px 16px', marginBottom: 12 }}>
              <h2 style={{ fontSize: 17, fontWeight: 700, marginBottom: 6, color: '#1E293B' }}>
                Leitor de Print da Reputação
              </h2>
              <p style={{ fontSize: 12, color: '#64748B', maxWidth: 320, margin: '0 auto 16px', lineHeight: 1.4 }}>
                Selecione na sua galeria o print da tela de reputação do Envios Extra para atualizar seus dados na aba <strong>Meu Nível</strong>.
              </p>

              <label className="upload-area" style={{ display: 'block', padding: '28px 16px', cursor: 'pointer' }}>
                <input 
                  type="file" 
                  accept="image/*" 
                  style={{ display: 'none' }} 
                  onChange={handleFileUpload}
                />
                {isProcessingOcr ? (
                  <div>
                    <RefreshCw className="spin" size={32} color="#3483FA" style={{ animation: 'spin 1s linear infinite', margin: '0 auto' }} />
                    <p style={{ marginTop: 10, fontWeight: 700, fontSize: 14, color: '#1E40AF' }}>Lendo print... {ocrProgress}%</p>
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                    <ImageIcon size={36} color="#3483FA" />
                    <div>
                      <p style={{ fontWeight: 700, fontSize: 15, color: '#1E40AF', margin: 0 }}>
                        Toque para escolher print da galeria
                      </p>
                      <span style={{ fontSize: 11, color: '#6B7280' }}>Carregue a captura de tela salva no celular</span>
                    </div>
                  </div>
                )}
              </label>

              {imagePreview && (
                <div style={{ marginTop: 14 }}>
                  <img 
                    src={imagePreview} 
                    alt="Print carregado" 
                    style={{ maxHeight: 160, borderRadius: 8, border: '1px solid #E2E8F0', objectFit: 'contain' }} 
                  />
                </div>
              )}
            </div>

            {hasReadPrint && (
              <div className="card" style={{ padding: '16px', textAlign: 'center', background: '#F0FDF4', border: '1px solid #86EFAC' }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: '#15803D', marginBottom: 10 }}>
                  ✅ Último Print Lido e Salvo na Memória
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 14 }}>
                  <div style={{ background: '#FFF', padding: '8px', borderRadius: 8, border: '1px solid #DCFCE7' }}>
                    <div style={{ fontSize: 10, color: '#64748B' }}>Pontos</div>
                    <div style={{ fontSize: 16, fontWeight: 800, color: '#1E293B' }}>{points}</div>
                  </div>
                  <div style={{ background: '#FFF', padding: '8px', borderRadius: 8, border: '1px solid #DCFCE7' }}>
                    <div style={{ fontSize: 10, color: '#64748B' }}>Sucesso</div>
                    <div style={{ fontSize: 16, fontWeight: 800, color: '#1E293B' }}>{successRate}%</div>
                  </div>
                  <div style={{ background: '#FFF', padding: '8px', borderRadius: 8, border: '1px solid #DCFCE7' }}>
                    <div style={{ fontSize: 10, color: '#64748B' }}>Sem Queixa</div>
                    <div style={{ fontSize: 16, fontWeight: 800, color: '#1E293B' }}>{noComplaintRate}%</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('level')}
                  className="btn-primary"
                  style={{ width: '100%', padding: '11px', fontSize: 14, fontWeight: 800 }}
                >
                  Ver Métricas em Meu Nível →
                </button>
              </div>
            )}
          </div>
        )}

        {/* ================================================================= */}
        {/* ABA 2: MEU NÍVEL (1. MÉTRICAS | 2. CONTAR PACOTES | 3. ROTAS)     */}
        {/* ================================================================= */}
        {activeTab === 'level' && (
          <div>
            {/* ------------------------------------------------------------- */}
            {/* SEÇÃO 1: MÉTRICAS DO ENTREGADOR (MINIMIZÁVEL)                 */}
            {/* ------------------------------------------------------------- */}
            <div className="card" style={{ padding: '12px 14px', marginBottom: 10 }}>
              <button
                type="button"
                onClick={() => setIsMetricsExpanded(!isMetricsExpanded)}
                style={{
                  width: '100%',
                  background: 'none',
                  border: 'none',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: 0,
                  cursor: 'pointer'
                }}
              >
                <span style={{ fontSize: 14, fontWeight: 800, color: '#1E293B', display: 'flex', alignItems: 'center', gap: 6 }}>
                  {isMetricsExpanded ? '▼' : '►'} Métricas do Entregador
                </span>
                <span style={{ fontSize: 11, fontWeight: 700, color: '#2563EB', background: '#EFF6FF', padding: '3px 8px', borderRadius: 8 }}>
                  {LEVEL_CRITERIA[targetLevelKey].name}
                </span>
              </button>

              {isMetricsExpanded && (
                <div style={{ marginTop: 12 }}>
                  {/* Seletor de Nível Alvo */}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6, marginBottom: 10 }}>
                    {['PLATINUM', 'GOLD', 'SILVER', 'BRONZE'].map((lvl) => (
                      <button
                        key={lvl}
                        type="button"
                        onClick={() => setTargetLevelKey(lvl)}
                        style={{
                          padding: '8px 4px',
                          borderRadius: 8,
                          border: targetLevelKey === lvl ? '2px solid #2D3277' : '1px solid #D1D5DB',
                          background: targetLevelKey === lvl ? '#2D3277' : '#FFF',
                          color: targetLevelKey === lvl ? '#FFF' : '#4B5563',
                          fontWeight: 700,
                          fontSize: 12,
                          cursor: 'pointer'
                        }}
                      >
                        {LEVEL_CRITERIA[lvl].name}
                      </button>
                    ))}
                  </div>

                  {(() => {
                    const isNeutral = !hasReadPrint || totalLoadedInMonth === 0;

                    const isSuccessUnder = !isNeutral && !comparison.successAnalysis.reached;
                    const isSuccessAlert = !isNeutral && comparison.successAnalysis.marginPacotes === 0;
                    const successBg = isNeutral ? '#F8FAFC' : isSuccessUnder ? '#FFF1F2' : isSuccessAlert ? '#FFFBEB' : '#F0FDF4';
                    const successBorder = isNeutral ? '#E2E8F0' : isSuccessUnder ? '#FECDD3' : isSuccessAlert ? '#FDE68A' : '#86EFAC';
                    const successColor = isNeutral ? '#64748B' : isSuccessUnder ? '#DC2626' : isSuccessAlert ? '#D97706' : '#16A34A';
                    const successTitleColor = isNeutral ? '#475569' : isSuccessUnder ? '#BE123C' : isSuccessAlert ? '#B45309' : '#15803D';

                    const isComplaintUnder = !isNeutral && comparison.target.key !== 'BRONZE' && !comparison.complaintAnalysis.reached;
                    const isComplaintAlert = !isNeutral && comparison.target.key !== 'BRONZE' && comparison.complaintAnalysis.allowedAdditionalComplaints === 0;
                    const complaintBg = isNeutral ? '#F8FAFC' : isComplaintUnder ? '#FFF1F2' : isComplaintAlert ? '#FFFBEB' : '#F0FDF4';
                    const complaintBorder = isNeutral ? '#E2E8F0' : isComplaintUnder ? '#FECDD3' : isComplaintAlert ? '#FDE68A' : '#86EFAC';
                    const complaintColor = isNeutral ? '#64748B' : isComplaintUnder ? '#DC2626' : isComplaintAlert ? '#D97706' : '#16A34A';
                    const complaintTitleColor = isNeutral ? '#475569' : isComplaintUnder ? '#BE123C' : isComplaintAlert ? '#B45309' : '#15803D';

                    return (
                      <div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
                          {/* Card Falhas */}
                          <div style={{ 
                            background: successBg, 
                            border: `2px solid ${successBorder}`, 
                            borderRadius: 12, 
                            padding: '12px 10px',
                            textAlign: 'center'
                          }}>
                            <div style={{ fontSize: 11, fontWeight: 700, color: successTitleColor, textTransform: 'uppercase' }}>
                              Falhas de Entrega
                            </div>
                            <div style={{ fontSize: 28, fontWeight: 900, color: successColor, margin: '4px 0' }}>
                              {isNeutral ? '0' : isSuccessUnder ? '0' : `+${comparison.successAnalysis.marginPacotes}`}
                            </div>
                            <div style={{ fontSize: 11, color: '#64748B', fontWeight: 600 }}>
                              {isNeutral
                                ? (!hasReadPrint ? 'leia o print primeiro' : 'some os pacotes abaixo')
                                : isSuccessUnder 
                                  ? `precisa de +${comparison.successAnalysis.neededConsecutiveSuccess} acertos`
                                  : isSuccessAlert 
                                    ? 'limite! não pode falhar' 
                                    : 'ainda pode ter'}
                            </div>
                            <div style={{ fontSize: 11, color: '#475569', marginTop: 6, borderTop: '1px solid rgba(0,0,0,0.06)', paddingTop: 5, fontWeight: 600 }}>
                              Ocorreram: <strong>{isNeutral ? 0 : comparison.successAnalysis.deliveredFailedCount}</strong> (limite: <strong>{isNeutral ? 0 : comparison.successAnalysis.maxAllowedFailures}</strong>)
                            </div>
                          </div>

                          {/* Card Reclamações */}
                          <div style={{ 
                            background: complaintBg, 
                            border: `2px solid ${complaintBorder}`, 
                            borderRadius: 12, 
                            padding: '12px 10px',
                            textAlign: 'center'
                          }}>
                            <div style={{ fontSize: 11, fontWeight: 700, color: complaintTitleColor, textTransform: 'uppercase' }}>
                              Reclamações
                            </div>
                            <div style={{ fontSize: 28, fontWeight: 900, color: complaintColor, margin: '4px 0' }}>
                              {isNeutral ? '0' : comparison.target.key === 'BRONZE' ? 'Livre' : `+${comparison.complaintAnalysis.allowedAdditionalComplaints}`}
                            </div>
                            <div style={{ fontSize: 11, color: '#64748B', fontWeight: 600 }}>
                              {isNeutral
                                ? (!hasReadPrint ? 'leia o print primeiro' : 'some os pacotes abaixo')
                                : comparison.target.key === 'BRONZE' 
                                  ? 'sem corte no nível' 
                                  : isComplaintAlert 
                                    ? 'limite! se receber cai' 
                                    : 'ainda pode ter (max)'}
                            </div>
                            <div style={{ fontSize: 11, color: '#475569', marginTop: 6, borderTop: '1px solid rgba(0,0,0,0.06)', paddingTop: 5, fontWeight: 600 }}>
                              {comparison.target.key === 'BRONZE' ? (
                                <span>Sem limite no Bronze</span>
                              ) : (
                                <>Ocorreram: <strong>{isNeutral ? 0 : comparison.complaintAnalysis.complaintCount}</strong> (limite: <strong>{isNeutral ? 0 : comparison.complaintAnalysis.maxAllowedComplaints}</strong>)</>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Resumo dos 3 indicadores */}
                        <div style={{ background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 10, padding: '10px 12px', marginBottom: isNeutral ? 0 : 8 }}>
                          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, textAlign: 'center' }}>
                            <div>
                              <div style={{ fontSize: 11, color: '#64748B' }}>Pontos</div>
                              <div style={{ fontSize: 15, fontWeight: 800, color: !hasReadPrint ? '#64748B' : points >= comparison.pointsStatus.target ? '#16A34A' : '#DC2626' }}>
                                {points}
                              </div>
                              <div style={{ fontSize: 10, color: '#94A3B8' }}>Meta: {comparison.pointsStatus.target}</div>
                            </div>
                            <div>
                              <div style={{ fontSize: 11, color: '#64748B' }}>Sucesso</div>
                              <div style={{ fontSize: 15, fontWeight: 800, color: !hasReadPrint ? '#64748B' : successRate >= comparison.successAnalysis.targetRate ? '#16A34A' : '#DC2626' }}>
                                {successRate}%
                              </div>
                              <div style={{ fontSize: 10, color: '#94A3B8' }}>Meta: {comparison.successAnalysis.targetRate}%</div>
                            </div>
                            <div>
                              <div style={{ fontSize: 11, color: '#64748B' }}>Sem Queixa</div>
                              <div style={{ fontSize: 15, fontWeight: 800, color: !hasReadPrint ? '#64748B' : noComplaintRate >= comparison.complaintAnalysis.targetRate ? '#16A34A' : '#DC2626' }}>
                                {noComplaintRate}%
                              </div>
                              <div style={{ fontSize: 10, color: '#94A3B8' }}>Meta: {comparison.complaintAnalysis.targetRate}%</div>
                            </div>
                          </div>
                        </div>

                        {!isNeutral && (
                          <div style={{ 
                            background: '#FFFFFF', 
                            border: '1px solid #E2E8F0', 
                            borderRadius: 10, 
                            padding: '8px 12px',
                            fontSize: 11,
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center'
                          }}>
                            <span style={{ color: '#475569' }}>📦 <strong>+49 pacotes</strong> liberam +1 falha</span>
                            <span style={{ color: '#475569' }}>⚠️ <strong>+334 pacotes</strong> liberam +1 queixa</span>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>

            {/* ------------------------------------------------------------- */}
            {/* SEÇÃO 2: CONTAR PACOTES (MINIMIZÁVEL)                         */}
            {/* ------------------------------------------------------------- */}
            <div className="card" style={{ padding: '12px 14px', marginBottom: 10 }}>
              <button
                type="button"
                onClick={() => setIsCounterExpanded(!isCounterExpanded)}
                style={{
                  width: '100%',
                  background: 'none',
                  border: 'none',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: 0,
                  cursor: 'pointer'
                }}
              >
                <span style={{ fontSize: 14, fontWeight: 800, color: '#1E293B', display: 'flex', alignItems: 'center', gap: 6 }}>
                  {isCounterExpanded ? '▼' : '►'} Contar Pacotes
                </span>
                <span style={{ fontSize: 12, fontWeight: 800, color: '#1D4ED8', background: '#DBEAFE', padding: '3px 10px', borderRadius: 8 }}>
                  {totalLoadedInMonth} no mês
                </span>
              </button>

              {isCounterExpanded && (
                <div style={{ marginTop: 12 }}>
                  {/* Calculadora Rápida: Digite 50 -> OK, Digite 55 -> OK */}
                  <form onSubmit={handleQuickAddSubmit} style={{ background: '#F8FAFC', padding: '12px', borderRadius: 12, border: '1px solid #CBD5E1', marginBottom: 10 }}>
                    <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#1E293B', marginBottom: 6 }}>
                      ➕ Somar Contagem do Dia (Calculadora Rápida)
                    </label>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <input
                        type="number"
                        className="input-field"
                        placeholder="Ex: 50"
                        value={quickInput}
                        onChange={e => setQuickInput(e.target.value)}
                        style={{
                          flex: 1,
                          padding: '10px 14px',
                          fontSize: 18,
                          fontWeight: 800,
                          textAlign: 'center',
                          background: '#FFF'
                        }}
                      />
                      <button
                        type="submit"
                        className="btn-primary"
                        style={{
                          width: 'auto',
                          padding: '10px 20px',
                          fontSize: 14,
                          fontWeight: 800,
                          borderRadius: 10,
                          background: '#16A34A'
                        }}
                      >
                        + Somar
                      </button>
                    </div>
                    <div style={{ fontSize: 11, color: '#64748B', marginTop: 6 }}>
                      💡 Digite <strong>50</strong> e toque em Somar, depois <strong>55</strong> e Somar — cada valor entra como uma rota separada!
                    </div>
                  </form>

                  {/* Botão de Importar Prints da Galeria */}
                  <label 
                    className="btn-secondary" 
                    style={{ 
                      cursor: 'pointer', 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center', 
                      gap: 8,
                      padding: '10px 14px',
                      borderRadius: 10,
                      fontSize: 12,
                      fontWeight: 700
                    }}
                  >
                    <input 
                      type="file" 
                      accept="image/*" 
                      multiple 
                      style={{ display: 'none' }} 
                      onChange={handleBatchRouteUpload}
                      disabled={isProcessingRouteBatch}
                    />
                    {isProcessingRouteBatch ? (
                      <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <RefreshCw className="spin" size={16} /> {batchProgress}
                      </span>
                    ) : (
                      <>
                        <ImageIcon size={16} />
                        <span>Importar Prints de Rotas da Galeria</span>
                      </>
                    )}
                  </label>
                </div>
              )}
            </div>

            {/* ------------------------------------------------------------- */}
            {/* SEÇÃO 3: ROTAS SOMADAS (MINIMIZÁVEL)                          */}
            {/* ------------------------------------------------------------- */}
            <div className="card" style={{ padding: '12px 14px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <button 
                  type="button"
                  onClick={() => setIsHistoryExpanded(!isHistoryExpanded)}
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: 6, 
                    fontSize: 14, 
                    fontWeight: 800, 
                    color: '#1E293B',
                    cursor: 'pointer',
                    padding: 0
                  }}
                >
                  <span>{isHistoryExpanded ? '▼' : '►'} Rotas Somadas ({currentMonthEntries.length})</span>
                </button>

                {entries.length > 0 && (
                  <button 
                    onClick={() => {
                      if (window.confirm('Deseja zerar todas as rotas salvas?')) {
                        setEntries([]);
                      }
                    }}
                    style={{ background: 'none', border: 'none', color: '#DC2626', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}
                  >
                    Zerar Tudo
                  </button>
                )}
              </div>

              {isHistoryExpanded && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}>
                  {currentMonthEntries.length === 0 ? (
                    <p style={{ fontSize: 12, color: '#9CA3AF', textAlign: 'center', padding: '10px 0' }}>
                      Nenhuma rota somada ainda.
                    </p>
                  ) : (
                    currentMonthEntries.map((item, idx) => (
                      <div 
                        key={item.id} 
                        style={{ 
                          border: '1px solid #E2E8F0', 
                          borderRadius: 8, 
                          padding: '8px 12px', 
                          background: '#F8FAFC',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center'
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span style={{ 
                            background: '#DBEAFE', 
                            color: '#1E40AF', 
                            fontSize: 11, 
                            fontWeight: 800, 
                            padding: '2px 6px', 
                            borderRadius: 6 
                          }}>
                            #{currentMonthEntries.length - idx}
                          </span>
                          <span style={{ fontSize: 12, fontWeight: 600, color: '#475569' }}>
                            {new Date(item.date + 'T00:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
                          </span>
                          <span style={{ fontSize: 14, fontWeight: 800, color: '#1D4ED8' }}>
                            +{item.loaded} pacotes
                          </span>
                        </div>

                        <button 
                          onClick={() => handleDeleteEntry(item.id)}
                          style={{ background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer', padding: 4 }}
                          title="Excluir"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================================================================= */}
        {/* ABA 3: MENSAGEM DO WHATSAPP (PADRÃO OU PERSONALIZADA)             */}
        {/* ================================================================= */}
        {activeTab === 'whatsapp' && (
          <div>
            <div className="card" style={{ padding: '16px' }}>
              <h2 style={{ fontSize: 16, fontWeight: 800, color: '#1E293B', marginBottom: 6 }}>
                💬 Mensagem Rápida do WhatsApp
              </h2>
              <p style={{ fontSize: 12, color: '#64748B', marginBottom: 16, lineHeight: 1.4 }}>
                Escolha qual mensagem será preenchida automaticamente quando você selecionar um número e clicar em <strong>"Chamar no WhatsApp"</strong>.
              </p>

              {/* Opção 1: Mensagem Padrão */}
              <div 
                onClick={() => {
                  setWaMsgMode('default');
                  setWaSavedFeedback(true);
                  setTimeout(() => setWaSavedFeedback(false), 2000);
                }}
                style={{
                  border: waMsgMode === 'default' ? '2px solid #16A34A' : '1px solid #CBD5E1',
                  background: waMsgMode === 'default' ? '#F0FDF4' : '#F8FAFC',
                  borderRadius: 12,
                  padding: '14px',
                  marginBottom: 12,
                  cursor: 'pointer'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                  <span style={{ fontSize: 13, fontWeight: 800, color: waMsgMode === 'default' ? '#15803D' : '#334155' }}>
                    Opção 1: Mensagem Padrão
                  </span>
                  {waMsgMode === 'default' && (
                    <span style={{ background: '#16A34A', color: '#FFF', fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 10 }}>
                      Ativa
                    </span>
                  )}
                </div>
                <p style={{ fontSize: 12, color: '#475569', margin: 0, fontStyle: 'italic' }}>
                  "{DEFAULT_WHATSAPP_MSG}"
                </p>
              </div>

              {/* Opção 2: Mensagem Personalizada */}
              <div 
                onClick={() => setWaMsgMode('custom')}
                style={{
                  border: waMsgMode === 'custom' ? '2px solid #2563EB' : '1px solid #CBD5E1',
                  background: waMsgMode === 'custom' ? '#EFF6FF' : '#F8FAFC',
                  borderRadius: 12,
                  padding: '14px',
                  marginBottom: 12,
                  cursor: 'pointer'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                  <span style={{ fontSize: 13, fontWeight: 800, color: waMsgMode === 'custom' ? '#1D4ED8' : '#334155' }}>
                    Opção 2: Escrever Mensagem Personalizada
                  </span>
                  {waMsgMode === 'custom' && (
                    <span style={{ background: '#2563EB', color: '#FFF', fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 10 }}>
                      Ativa
                    </span>
                  )}
                </div>

                <textarea
                  rows={3}
                  className="input-field"
                  placeholder="Digite aqui a sua mensagem personalizada para o cliente..."
                  value={customWaMsg}
                  onChange={e => {
                    setCustomWaMsg(e.target.value);
                    if (waMsgMode !== 'custom') setWaMsgMode('custom');
                  }}
                  style={{
                    width: '100%',
                    padding: '10px',
                    fontSize: 13,
                    borderRadius: 8,
                    border: '1px solid #93C5FD',
                    background: '#FFF',
                    resize: 'vertical'
                  }}
                />
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setWaMsgMode('custom');
                    setWaSavedFeedback(true);
                    setTimeout(() => setWaSavedFeedback(false), 2000);
                  }}
                  className="btn-primary"
                  style={{ marginTop: 8, padding: '8px 14px', fontSize: 12, width: '100%' }}
                >
                  Salvar Mensagem Personalizada
                </button>
              </div>

              {waSavedFeedback && (
                <div style={{ 
                  background: '#DCFCE7', 
                  color: '#166534', 
                  padding: '10px', 
                  borderRadius: 8, 
                  fontSize: 12, 
                  fontWeight: 700, 
                  textAlign: 'center',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6
                }}>
                  <Check size={16} /> Mensagem do WhatsApp atualizada!
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
