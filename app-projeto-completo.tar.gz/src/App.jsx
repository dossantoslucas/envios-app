import React, { useState, useEffect, useCallback } from 'react';
import { 
  Image as ImageIcon, 
  Award, 
  Trash2, 
  RefreshCw,
  MessageSquare,
  Check,
  Bell,
  Clock,
  Play,
  Square
} from 'lucide-react';
import { LEVEL_CRITERIA, determineLevel, compareWithLevelTarget } from './utils/calculator';
import { parseEnviosExtraImage } from './utils/ocrService';

const DEFAULT_WHATSAPP_MSG = "Olá! Sou o entregador do Mercado Livre e estou no seu endereço com a sua encomenda.";

export default function App() {
  const [activeTab, setActiveTab] = useState('level'); // 'analyzer' | 'level' | 'whatsapp'

  // Dados extraídos da tela do print e contagens inteiras de falhas/queixas
  const [points, setPoints] = useState(() => Number(localStorage.getItem('envios_points')) || 0);
  const [printSuccessRate, setPrintSuccessRate] = useState(() => {
    const val = localStorage.getItem('envios_success_rate');
    return val !== null ? Number(val) : 100;
  });
  const [printNoComplaintRate, setPrintNoComplaintRate] = useState(() => {
    const val = localStorage.getItem('envios_no_complaint_rate');
    return val !== null ? Number(val) : 100;
  });
  const [failedCount, setFailedCount] = useState(() => Number(localStorage.getItem('envios_failed_count')) || 0);
  const [complaintCount, setComplaintCount] = useState(() => Number(localStorage.getItem('envios_complaint_count')) || 0);
  const [hasReadPrint, setHasReadPrint] = useState(() => localStorage.getItem('envios_has_read_print') === 'true');
  const [targetLevelKey, setTargetLevelKey] = useState('PLATINUM');

  const [imagePreview, setImagePreview] = useState(null);
  const [isProcessingOcr, setIsProcessingOcr] = useState(false);
  const [ocrProgress, setOcrProgress] = useState(0);

  // Rotas de entregas (salvas permanentemente na memória)
  const [entries, setEntries] = useState(() => {
    const saved = localStorage.getItem('envios_extra_entries');
    if (saved) {
      try { return JSON.parse(saved); } catch (_) {}
    }
    return [];
  });

  // Estados de Minimizar / Expandir na aba "Meu Nível"
  const [isMetricsExpanded, setIsMetricsExpanded] = useState(true);
  const [isCounterExpanded, setIsCounterExpanded] = useState(true);
  const [isHistoryExpanded, setIsHistoryExpanded] = useState(false);

  // Contar Pacotes
  const [quickInput, setQuickInput] = useState('');

  // Configuração da Mensagem do WhatsApp
  const [waMsgMode, setWaMsgMode] = useState(() => localStorage.getItem('envios_wa_mode') || 'default'); // 'default' | 'custom'
  const [customWaMsg, setCustomWaMsg] = useState(() => localStorage.getItem('envios_wa_custom_text') || '');
  const [waSavedFeedback, setWaSavedFeedback] = useState(false);
  const [isAutofillActive, setIsAutofillActive] = useState(false);
  const [isBatteryFree, setIsBatteryFree] = useState(true);

  // =========================================================================
  // ESTADOS DO RADAR DE LOTES (FUNÇÕES 1, 2 E 3 COM CHAVES INDEPENDENTES)
  // =========================================================================
  const [radarOpt1Timer, setRadarOpt1Timer] = useState(() => localStorage.getItem('radar_opt1_timer') !== 'false');
  const [radarOpt2Pacer, setRadarOpt2Pacer] = useState(() => localStorage.getItem('radar_opt2_pacer') !== 'false');
  const [radarOpt3Log, setRadarOpt3Log] = useState(() => localStorage.getItem('radar_opt3_log') !== 'false');
  const [radarDurationMin, setRadarDurationMin] = useState(() => Number(localStorage.getItem('radar_duration_min')) || 10);
  const [radarPacerSec, setRadarPacerSec] = useState(() => Number(localStorage.getItem('radar_pacer_sec')) || 45);
  const [radarPacerBeep, setRadarPacerBeep] = useState(() => localStorage.getItem('radar_pacer_beep') !== 'false');
  const [isNotifListenerEnabled, setIsNotifListenerEnabled] = useState(false);
  const [isOverlayGranted, setIsOverlayGranted] = useState(false);
  const [isRadarTimerRunning, setIsRadarTimerRunning] = useState(false);
  const [radarLogs, setRadarLogs] = useState(() => {
    try {
      const saved = localStorage.getItem('radar_batch_logs_cache');
      return saved ? JSON.parse(saved) : [];
    } catch (_) {
      return [];
    }
  });

  // Persistir entradas no localStorage
  useEffect(() => {
    localStorage.setItem('envios_extra_entries', JSON.stringify(entries));
  }, [entries]);

  // Persistir dados na memória
  useEffect(() => {
    localStorage.setItem('envios_points', String(points));
    localStorage.setItem('envios_success_rate', String(printSuccessRate));
    localStorage.setItem('envios_no_complaint_rate', String(printNoComplaintRate));
    localStorage.setItem('envios_failed_count', String(failedCount));
    localStorage.setItem('envios_complaint_count', String(complaintCount));
    localStorage.setItem('envios_has_read_print', String(hasReadPrint));
  }, [points, printSuccessRate, printNoComplaintRate, failedCount, complaintCount, hasReadPrint]);

  // Sincronizar mensagem do WhatsApp com o sistema Android nativo
  useEffect(() => {
    localStorage.setItem('envios_wa_mode', waMsgMode);
    localStorage.setItem('envios_wa_custom_text', customWaMsg);

    const activeMessage = (waMsgMode === 'custom' && customWaMsg.trim())
      ? customWaMsg.trim()
      : DEFAULT_WHATSAPP_MSG;

    if (window.AndroidNative && typeof window.AndroidNative.setWhatsAppMessage === 'function') {
      try {
        window.AndroidNative.setWhatsAppMessage(activeMessage);
      } catch (e) {
        console.error('Erro ao salvar msg no Android:', e);
      }
    }
  }, [waMsgMode, customWaMsg]);

  // Sincronizar pacotes adicionados pelo botão rápido da barra de notificações do Android
  const syncNativeQuickEntries = useCallback(() => {
    if (window.AndroidNative) {
      if (typeof window.AndroidNative.consumeQuickEntries === 'function') {
        try {
          const rawJson = window.AndroidNative.consumeQuickEntries();
          if (rawJson && rawJson !== '[]') {
            const addedList = JSON.parse(rawJson);
            if (Array.isArray(addedList) && addedList.length > 0) {
              setEntries(prev => [...addedList.reverse(), ...prev]);
            }
          }
        } catch (e) {
          console.error('Erro ao ler pacotes rápidos do Android:', e);
        }
      }
      if (typeof window.AndroidNative.isAutofillEnabled === 'function') {
        try {
          setIsAutofillActive(Boolean(window.AndroidNative.isAutofillEnabled()));
        } catch (_) {}
      }
      if (typeof window.AndroidNative.isBatteryUnrestricted === 'function') {
        try {
          setIsBatteryFree(Boolean(window.AndroidNative.isBatteryUnrestricted()));
        } catch (_) {}
      }
      if (typeof window.AndroidNative.isNotificationListenerEnabled === 'function') {
        try {
          setIsNotifListenerEnabled(Boolean(window.AndroidNative.isNotificationListenerEnabled()));
        } catch (_) {}
      }
      if (typeof window.AndroidNative.isOverlayPermissionGranted === 'function') {
        try {
          setIsOverlayGranted(Boolean(window.AndroidNative.isOverlayPermissionGranted()));
        } catch (_) {}
      }
      if (typeof window.AndroidNative.getRadarConfig === 'function') {
        try {
          const cfgRaw = window.AndroidNative.getRadarConfig();
          if (cfgRaw) {
            const cfg = JSON.parse(cfgRaw);
            setIsRadarTimerRunning(Boolean(cfg.isRunning));
          }
        } catch (_) {}
      }
      if (typeof window.AndroidNative.getRadarLogs === 'function') {
        try {
          const logsRaw = window.AndroidNative.getRadarLogs();
          if (logsRaw) {
            const parsedLogs = JSON.parse(logsRaw);
            if (Array.isArray(parsedLogs)) {
              setRadarLogs(parsedLogs);
              localStorage.setItem('radar_batch_logs_cache', JSON.stringify(parsedLogs));
            }
          }
        } catch (_) {}
      }
    }
  }, []);

  // Sincronizar configurações das Opções 1, 2 e 3 com o serviço nativo do Android
  useEffect(() => {
    localStorage.setItem('radar_opt1_timer', String(radarOpt1Timer));
    localStorage.setItem('radar_opt2_pacer', String(radarOpt2Pacer));
    localStorage.setItem('radar_opt3_log', String(radarOpt3Log));
    localStorage.setItem('radar_duration_min', String(radarDurationMin));
    localStorage.setItem('radar_pacer_sec', String(radarPacerSec));
    localStorage.setItem('radar_pacer_beep', String(radarPacerBeep));

    if (window.AndroidNative && typeof window.AndroidNative.saveRadarConfig === 'function') {
      try {
        window.AndroidNative.saveRadarConfig(
          Boolean(radarOpt1Timer),
          Boolean(radarOpt2Pacer),
          Boolean(radarOpt3Log),
          Number(radarDurationMin) || 10,
          Number(radarPacerSec) || 45,
          Boolean(radarPacerBeep)
        );
      } catch (e) {
        console.error('Erro ao salvar config do radar:', e);
      }
    }
  }, [radarOpt1Timer, radarOpt2Pacer, radarOpt3Log, radarDurationMin, radarPacerSec, radarPacerBeep]);

  useEffect(() => {
    syncNativeQuickEntries();
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        syncNativeQuickEntries();
      }
    };
    window.addEventListener('focus', syncNativeQuickEntries);
    document.addEventListener('visibilitychange', handleVisibility);
    const interval = setInterval(syncNativeQuickEntries, 2000);
    return () => {
      window.removeEventListener('focus', syncNativeQuickEntries);
      document.removeEventListener('visibilitychange', handleVisibility);
      clearInterval(interval);
    };
  }, [syncNativeQuickEntries]);

  // Filtrar rotas pertencentes ao mês vigente
  const todayIso = new Date().toISOString().slice(0, 10);
  const currentMonthPrefix = todayIso.slice(0, 7);
  const currentMonthEntries = entries.filter(item => item.date && item.date.startsWith(currentMonthPrefix));

  // Total de pacotes carregados no mês
  const totalLoadedInMonth = currentMonthEntries.reduce((acc, curr) => acc + (Number(curr.loaded) || 0), 0);

  // Recalcular falhas e queixas inteiras a partir de um print lido
  const applyPrintRatesToCounts = useCallback((sRate, cRate) => {
    if (totalLoadedInMonth > 0) {
      const calcFailures = Math.max(0, Math.round(totalLoadedInMonth * ((100 - sRate) / 100)));
      const calcComplaints = Math.max(0, Math.round(totalLoadedInMonth * ((100 - cRate) / 100)));
      setFailedCount(calcFailures);
      setComplaintCount(calcComplaints);
    } else {
      setFailedCount(0);
      setComplaintCount(0);
    }
  }, [totalLoadedInMonth]);

  // Comparação em tempo real: ao adicionar pacotes, atualiza tudo sozinho sem precisar de print!
  const comparison = compareWithLevelTarget(
    totalLoadedInMonth,
    points,
    failedCount,
    complaintCount,
    targetLevelKey,
    printSuccessRate,
    printNoComplaintRate
  );

  const currentLevel = determineLevel(
    points,
    comparison.successAnalysis.currentRate,
    comparison.complaintAnalysis.currentRate
  );

  // Leitura do Print
  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImagePreview(URL.createObjectURL(file));
    setIsProcessingOcr(true);
    setOcrProgress(10);

    try {
      const result = await parseEnviosExtraImage(file, (p) => setOcrProgress(p));
      if (result && result.success) {
        const newPts = result.points !== undefined ? result.points : points;
        const newSRate = result.successRate !== undefined ? result.successRate : 100;
        const newCRate = result.noComplaintRate !== undefined ? result.noComplaintRate : 100;

        setPoints(newPts);
        setPrintSuccessRate(newSRate);
        setPrintNoComplaintRate(newCRate);
        setHasReadPrint(true);
        applyPrintRatesToCounts(newSRate, newCRate);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessingOcr(false);
      setOcrProgress(0);
    }
  };

  // Adicionar pacotes (atualiza as métricas na hora sem precisar de print)
  const handleQuickAddSubmit = (e) => {
    e.preventDefault();
    const loaded = Number(quickInput) || 0;
    if (loaded <= 0) return;

    const newEntry = {
      id: Date.now().toString(),
      date: todayIso,
      loaded,
      delivered: loaded,
      failed: 0,
      notes: `Rota #${currentMonthEntries.length + 1}`
    };

    const nextTotal = totalLoadedInMonth + loaded;
    // Se o usuário leu o print antes de ter qualquer pacote lançado no mês, sincroniza as falhas na 1ª adição
    if (totalLoadedInMonth === 0 && hasReadPrint) {
      setFailedCount(Math.max(0, Math.round(nextTotal * ((100 - printSuccessRate) / 100))));
      setComplaintCount(Math.max(0, Math.round(nextTotal * ((100 - printNoComplaintRate) / 100))));
    }

    setEntries(prev => [newEntry, ...prev]);
    setQuickInput('');
    if (window.navigator?.vibrate) window.navigator.vibrate(30);
  };

  const handleDeleteEntry = (id) => {
    setEntries(entries.filter(item => item.id !== id));
  };

  return (
    <div className="app-container">
      {/* Barra Superior */}
      <header className="top-bar">
        <div className="top-bar-title">
          Auxiliar de Rota
        </div>
        <div className={`badge ${currentLevel.badgeClass}`}>
          <Award size={13} />
          {currentLevel.name}
        </div>
      </header>

      {/* Abas de Navegação */}
      <nav className="nav-tabs">
        <button 
          className={`nav-tab-btn ${activeTab === 'analyzer' ? 'active' : ''}`}
          onClick={() => setActiveTab('analyzer')}
        >
          <ImageIcon size={15} /> Print
        </button>
        <button 
          className={`nav-tab-btn ${activeTab === 'level' ? 'active' : ''}`}
          onClick={() => setActiveTab('level')}
        >
          <Award size={15} /> Meu Nível
        </button>
        <button 
          className={`nav-tab-btn ${activeTab === 'radar' ? 'active' : ''}`}
          onClick={() => setActiveTab('radar')}
        >
          <Clock size={15} /> Radar Lotes
        </button>
        <button 
          className={`nav-tab-btn ${activeTab === 'whatsapp' ? 'active' : ''}`}
          onClick={() => setActiveTab('whatsapp')}
        >
          <MessageSquare size={15} /> Config
        </button>
      </nav>

      {/* Conteúdo Principal */}
      <main className="content-body">
        {/* ================================================================= */}
        {/* ABA 1: LEITOR PRINT (COM PROTEÇÃO OPÇÃO A CONTRA COLISÃO DO DIA)  */}
        {/* ================================================================= */}
        {activeTab === 'analyzer' && (
          <div>
            <div className="card" style={{ textAlign: 'center', padding: '18px 16px', marginBottom: 10 }}>
              <label className="upload-area" style={{ display: 'block', padding: '24px 16px', cursor: 'pointer' }}>
                <input 
                  type="file" 
                  accept="image/*" 
                  style={{ display: 'none' }} 
                  onChange={handleFileUpload}
                />
                {isProcessingOcr ? (
                  <div>
                    <RefreshCw className="spin" size={28} color="#3483FA" style={{ animation: 'spin 1s linear infinite', margin: '0 auto' }} />
                    <p style={{ marginTop: 8, fontWeight: 700, fontSize: 14, color: '#1E40AF' }}>Lendo print... {ocrProgress}%</p>
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                    <ImageIcon size={32} color="#3483FA" />
                    <p style={{ fontWeight: 700, fontSize: 14, color: '#1E40AF', margin: 0 }}>
                      Selecionar print da galeria
                    </p>
                    <span style={{ fontSize: 11, color: '#64748B', maxWidth: 260, lineHeight: 1.3 }}>
                      Certifique-se de que o print e os pacotes adicionados sejam referentes ao mesmo dia.
                    </span>
                  </div>
                )}
              </label>

              {imagePreview && (
                <div style={{ marginTop: 12 }}>
                  <img 
                    src={imagePreview} 
                    alt="Print carregado" 
                    style={{ maxHeight: 140, borderRadius: 8, border: '1px solid #E2E8F0', objectFit: 'contain' }} 
                  />
                </div>
              )}
            </div>

            {hasReadPrint && (
              <div className="card" style={{ padding: '14px', textAlign: 'center' }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 12 }}>
                  <div style={{ background: '#F8FAFC', padding: '8px', borderRadius: 8, border: '1px solid #E2E8F0' }}>
                    <div style={{ fontSize: 10, color: '#64748B', marginBottom: 2 }}>Pontos</div>
                    <input
                      type="number"
                      value={points}
                      onChange={e => setPoints(Number(e.target.value) || 0)}
                      style={{ width: '100%', border: 'none', textAlign: 'center', fontSize: 16, fontWeight: 800, color: '#1E293B', background: 'transparent', outline: 'none' }}
                    />
                  </div>
                  <div style={{ background: '#F8FAFC', padding: '8px', borderRadius: 8, border: '1px solid #E2E8F0' }}>
                    <div style={{ fontSize: 10, color: '#64748B', marginBottom: 2 }}>Sucesso (%)</div>
                    <input
                      type="number"
                      step="0.01"
                      value={printSuccessRate}
                      onChange={e => {
                        const val = Number(e.target.value) || 0;
                        setPrintSuccessRate(val);
                        applyPrintRatesToCounts(val, printNoComplaintRate);
                      }}
                      style={{ width: '100%', border: 'none', textAlign: 'center', fontSize: 16, fontWeight: 800, color: '#1E293B', background: 'transparent', outline: 'none' }}
                    />
                  </div>
                  <div style={{ background: '#F8FAFC', padding: '8px', borderRadius: 8, border: '1px solid #E2E8F0' }}>
                    <div style={{ fontSize: 10, color: '#64748B', marginBottom: 2 }}>Sem Queixa (%)</div>
                    <input
                      type="number"
                      step="0.01"
                      value={printNoComplaintRate}
                      onChange={e => {
                        const val = Number(e.target.value) || 0;
                        setPrintNoComplaintRate(val);
                        applyPrintRatesToCounts(printSuccessRate, val);
                      }}
                      style={{ width: '100%', border: 'none', textAlign: 'center', fontSize: 16, fontWeight: 800, color: '#1E293B', background: 'transparent', outline: 'none' }}
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTab('level')}
                  className="btn-primary"
                  style={{ width: '100%', padding: '10px', fontSize: 13, fontWeight: 800 }}
                >
                  Ver em Meu Nível
                </button>
              </div>
            )}
          </div>
        )}

        {/* ================================================================= */}
        {/* ABA 2: MEU NÍVEL (ATUALIZA SOZINHO AO ADICIONAR PACOTES)          */}
        {/* ================================================================= */}
        {activeTab === 'level' && (
          <div>
            {/* ------------------------------------------------------------- */}
            {/* SEÇÃO 1: MÉTRICAS DO ENTREGADOR (MINIMIZÁVEL)                 */}
            {/* ------------------------------------------------------------- */}
            <div className="card" style={{ padding: '12px 14px', marginBottom: 10 }}>
              <button
                type="button"
                onClick={() => setIsMetricsExpanded(!isMetricsExpanded)}
                style={{
                  width: '100%',
                  background: 'none',
                  border: 'none',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: 0,
                  cursor: 'pointer'
                }}
              >
                <span style={{ fontSize: 14, fontWeight: 800, color: '#1E293B', display: 'flex', alignItems: 'center', gap: 6 }}>
                  {isMetricsExpanded ? '▼' : '►'} Métricas do Entregador
                </span>
                {!isMetricsExpanded && (
                  <span style={{ fontSize: 11, fontWeight: 700, color: '#2563EB', background: '#EFF6FF', padding: '3px 8px', borderRadius: 8 }}>
                    {LEVEL_CRITERIA[targetLevelKey].name}
                  </span>
                )}
              </button>

              {isMetricsExpanded && (
                <div style={{ marginTop: 12 }}>
                  {/* Seletor de Nível Alvo */}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6, marginBottom: 10 }}>
                    {['PLATINUM', 'GOLD', 'SILVER', 'BRONZE'].map((lvl) => (
                      <button
                        key={lvl}
                        type="button"
                        onClick={() => setTargetLevelKey(lvl)}
                        style={{
                          padding: '7px 4px',
                          borderRadius: 8,
                          border: targetLevelKey === lvl ? '2px solid #2D3277' : '1px solid #D1D5DB',
                          background: targetLevelKey === lvl ? '#2D3277' : '#FFF',
                          color: targetLevelKey === lvl ? '#FFF' : '#4B5563',
                          fontWeight: 700,
                          fontSize: 12,
                          cursor: 'pointer'
                        }}
                      >
                        {LEVEL_CRITERIA[lvl].name}
                      </button>
                    ))}
                  </div>

                  {(() => {
                    // Agora basta ter pacotes adicionados no mês para calcular as métricas na hora (sem precisar de print!)
                    const isNeutral = totalLoadedInMonth === 0;

                    const isSuccessUnder = !isNeutral && !comparison.successAnalysis.reached;
                    const isSuccessAlert = !isNeutral && comparison.successAnalysis.marginPacotes === 0;
                    const successBg = isNeutral ? '#F8FAFC' : isSuccessUnder ? '#FFF1F2' : isSuccessAlert ? '#FFFBEB' : '#F0FDF4';
                    const successBorder = isNeutral ? '#E2E8F0' : isSuccessUnder ? '#FECDD3' : isSuccessAlert ? '#FDE68A' : '#86EFAC';
                    const successColor = isNeutral ? '#64748B' : isSuccessUnder ? '#DC2626' : isSuccessAlert ? '#D97706' : '#16A34A';
                    const successTitleColor = isNeutral ? '#475569' : isSuccessUnder ? '#BE123C' : isSuccessAlert ? '#B45309' : '#15803D';

                    const isComplaintUnder = !isNeutral && comparison.target.key !== 'BRONZE' && !comparison.complaintAnalysis.reached;
                    const isComplaintAlert = !isNeutral && comparison.target.key !== 'BRONZE' && comparison.complaintAnalysis.allowedAdditionalComplaints === 0;
                    const complaintBg = isNeutral ? '#F8FAFC' : isComplaintUnder ? '#FFF1F2' : isComplaintAlert ? '#FFFBEB' : '#F0FDF4';
                    const complaintBorder = isNeutral ? '#E2E8F0' : isComplaintUnder ? '#FECDD3' : isComplaintAlert ? '#FDE68A' : '#86EFAC';
                    const complaintColor = isNeutral ? '#64748B' : isComplaintUnder ? '#DC2626' : isComplaintAlert ? '#D97706' : '#16A34A';
                    const complaintTitleColor = isNeutral ? '#475569' : isComplaintUnder ? '#BE123C' : isComplaintAlert ? '#B45309' : '#15803D';

                    return (
                      <div>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
                          {/* Card Falhas */}
                          <div style={{ 
                            background: successBg, 
                            border: `2px solid ${successBorder}`, 
                            borderRadius: 12, 
                            padding: '10px',
                            textAlign: 'center'
                          }}>
                            <div style={{ fontSize: 11, fontWeight: 800, color: successTitleColor, textTransform: 'uppercase' }}>
                              Falhas
                            </div>
                            <div style={{ fontSize: 28, fontWeight: 900, color: successColor, margin: '2px 0' }}>
                              {isNeutral ? '0' : isSuccessUnder ? '0' : `+${comparison.successAnalysis.marginPacotes}`}
                            </div>
                            <div style={{ fontSize: 11, color: '#334155', fontWeight: 600 }}>
                              {isNeutral
                                ? '0 de 0 usadas'
                                : isSuccessUnder
                                  ? `faltam +${comparison.successAnalysis.neededConsecutiveSuccess} acertos`
                                  : `${comparison.successAnalysis.deliveredFailedCount} de ${comparison.successAnalysis.maxAllowedFailures} usadas`}
                            </div>
                            {!isNeutral && comparison.target.key !== 'BRONZE' && (
                              <div style={{ fontSize: 10, color: '#475569', marginTop: 6, borderTop: '1px solid rgba(0,0,0,0.06)', paddingTop: 5, fontWeight: 700 }}>
                                +{comparison.successAnalysis.packagesForOneMoreFailure} pac. p/ +1 margem
                              </div>
                            )}
                          </div>

                          {/* Card Reclamações */}
                          <div style={{ 
                            background: complaintBg, 
                            border: `2px solid ${complaintBorder}`, 
                            borderRadius: 12, 
                            padding: '10px',
                            textAlign: 'center'
                          }}>
                            <div style={{ fontSize: 11, fontWeight: 800, color: complaintTitleColor, textTransform: 'uppercase' }}>
                              Reclamações
                            </div>
                            <div style={{ fontSize: 28, fontWeight: 900, color: complaintColor, margin: '2px 0' }}>
                              {isNeutral ? '0' : comparison.target.key === 'BRONZE' ? 'Livre' : `+${comparison.complaintAnalysis.allowedAdditionalComplaints}`}
                            </div>
                            <div style={{ fontSize: 11, color: '#334155', fontWeight: 600 }}>
                              {isNeutral
                                ? '0 de 0 usadas'
                                : comparison.target.key === 'BRONZE'
                                  ? 'Sem limite'
                                  : `${comparison.complaintAnalysis.complaintCount} de ${comparison.complaintAnalysis.maxAllowedComplaints} usadas`}
                            </div>
                            {!isNeutral && comparison.target.key !== 'BRONZE' && (
                              <div style={{ fontSize: 10, color: '#475569', marginTop: 6, borderTop: '1px solid rgba(0,0,0,0.06)', paddingTop: 5, fontWeight: 700 }}>
                                +{comparison.complaintAnalysis.packagesForOneMoreComplaint} pac. p/ +1 margem
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Resumo dos 3 indicadores (Recalculados automaticamente com os pacotes adicionados) */}
                        <div style={{ background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 10, padding: '8px 10px' }}>
                          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, textAlign: 'center' }}>
                            <div>
                              <div style={{ fontSize: 10, color: '#64748B' }}>Pontos</div>
                              <div style={{ fontSize: 15, fontWeight: 800, color: !hasReadPrint ? '#64748B' : points >= comparison.pointsStatus.target ? '#16A34A' : '#DC2626' }}>
                                {points}
                              </div>
                              <div style={{ fontSize: 10, color: '#94A3B8' }}>Meta: {comparison.pointsStatus.target}</div>
                            </div>
                            <div>
                              <div style={{ fontSize: 10, color: '#64748B' }}>Sucesso</div>
                              <div style={{ fontSize: 15, fontWeight: 800, color: isNeutral ? '#64748B' : comparison.successAnalysis.currentRate >= comparison.successAnalysis.targetRate ? '#16A34A' : '#DC2626' }}>
                                {isNeutral ? '0%' : `${comparison.successAnalysis.currentRate}%`}
                              </div>
                              <div style={{ fontSize: 10, color: '#94A3B8' }}>Meta: {comparison.successAnalysis.targetRate}%</div>
                            </div>
                            <div>
                              <div style={{ fontSize: 10, color: '#64748B' }}>Sem Queixa</div>
                              <div style={{ fontSize: 15, fontWeight: 800, color: isNeutral ? '#64748B' : comparison.complaintAnalysis.currentRate >= comparison.complaintAnalysis.targetRate ? '#16A34A' : '#DC2626' }}>
                                {isNeutral ? '0%' : `${comparison.complaintAnalysis.currentRate}%`}
                              </div>
                              <div style={{ fontSize: 10, color: '#94A3B8' }}>Meta: {comparison.complaintAnalysis.targetRate}%</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>

            {/* ------------------------------------------------------------- */}
            {/* SEÇÃO 2: CONTAR PACOTES (MINIMIZÁVEL)                         */}
            {/* ------------------------------------------------------------- */}
            <div className="card" style={{ padding: '12px 14px', marginBottom: 10 }}>
              <button
                type="button"
                onClick={() => setIsCounterExpanded(!isCounterExpanded)}
                style={{
                  width: '100%',
                  background: 'none',
                  border: 'none',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: 0,
                  cursor: 'pointer'
                }}
              >
                <span style={{ fontSize: 14, fontWeight: 800, color: '#1E293B', display: 'flex', alignItems: 'center', gap: 6 }}>
                  {isCounterExpanded ? '▼' : '►'} Contar Pacotes
                </span>
                <span style={{ fontSize: 12, fontWeight: 800, color: '#1D4ED8', background: '#DBEAFE', padding: '3px 10px', borderRadius: 8 }}>
                  {totalLoadedInMonth} no mês
                </span>
              </button>

              {isCounterExpanded && (
                <form onSubmit={handleQuickAddSubmit} style={{ marginTop: 10 }}>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <input
                      type="number"
                      className="input-field"
                      value={quickInput}
                      onChange={e => setQuickInput(e.target.value)}
                      style={{
                        flex: 1,
                        padding: '10px 14px',
                        fontSize: 18,
                        fontWeight: 800,
                        textAlign: 'center',
                        background: '#F8FAFC'
                      }}
                    />
                    <button
                      type="submit"
                      className="btn-primary"
                      style={{
                        width: 'auto',
                        padding: '10px 20px',
                        fontSize: 14,
                        fontWeight: 800,
                        borderRadius: 10,
                        background: '#16A34A'
                      }}
                    >
                      Adicionar
                    </button>
                  </div>
                  {totalLoadedInMonth === 0 && (
                    <div style={{ fontSize: 11, color: '#64748B', marginTop: 6 }}>
                      Exemplo: digite <strong>50</strong> e toque em <strong>Adicionar</strong>, depois <strong>55</strong> e <strong>Adicionar</strong>.
                    </div>
                  )}
                </form>
              )}
            </div>

            {/* ------------------------------------------------------------- */}
            {/* SEÇÃO 3: HISTÓRICO DE ROTAS (MINIMIZÁVEL)                     */}
            {/* ------------------------------------------------------------- */}
            <div className="card" style={{ padding: '12px 14px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <button 
                  type="button"
                  onClick={() => setIsHistoryExpanded(!isHistoryExpanded)}
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: 6, 
                    fontSize: 14, 
                    fontWeight: 800, 
                    color: '#1E293B',
                    cursor: 'pointer',
                    padding: 0
                  }}
                >
                  <span>{isHistoryExpanded ? '▼' : '►'} Histórico de Rotas ({currentMonthEntries.length})</span>
                </button>

                {entries.length > 0 && (
                  <button 
                    onClick={() => {
                      if (window.confirm('Deseja zerar todas as rotas salvas?')) {
                        setEntries([]);
                      }
                    }}
                    style={{ background: 'none', border: 'none', color: '#DC2626', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}
                  >
                    Zerar Tudo
                  </button>
                )}
              </div>

              {isHistoryExpanded && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 10 }}>
                  {currentMonthEntries.length === 0 ? (
                    <p style={{ fontSize: 12, color: '#9CA3AF', textAlign: 'center', padding: '8px 0', margin: 0 }}>
                      Nenhuma rota registrada.
                    </p>
                  ) : (
                    currentMonthEntries.map((item, idx) => (
                      <div 
                        key={item.id} 
                        style={{ 
                          border: '1px solid #E2E8F0', 
                          borderRadius: 8, 
                          padding: '7px 10px', 
                          background: '#F8FAFC',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center'
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span style={{ 
                            background: '#DBEAFE', 
                            color: '#1E40AF', 
                            fontSize: 11, 
                            fontWeight: 800, 
                            padding: '2px 6px', 
                            borderRadius: 6 
                          }}>
                            #{currentMonthEntries.length - idx}
                          </span>
                          <span style={{ fontSize: 12, fontWeight: 600, color: '#475569' }}>
                            {new Date(item.date + 'T00:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
                          </span>
                          <span style={{ fontSize: 14, fontWeight: 800, color: '#1D4ED8' }}>
                            +{item.loaded}
                          </span>
                        </div>

                        <button 
                          onClick={() => handleDeleteEntry(item.id)}
                          style={{ background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer', padding: 4 }}
                          title="Excluir"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================================================================= */}
        {/* ABA 3: RADAR INTELIGENTE DE LOTES (OPÇÕES 1, 2 E 3 INDEPENDENTES) */}
        {/* ================================================================= */}
        {activeTab === 'radar' && (
          <div>
            {/* Status das Permissões do Radar */}
            {(!isNotifListenerEnabled || !isOverlayGranted) && (
              <div className="card" style={{ padding: '12px 14px', marginBottom: 10, background: '#FFFBEB', border: '1px solid #FDE68A' }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: '#92400E', marginBottom: 6 }}>
                  ⚙️ Permissões necessárias para o Radar funcionar:
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {!isNotifListenerEnabled && (
                    <button
                      type="button"
                      onClick={() => window.AndroidNative?.openNotificationListenerSettings?.()}
                      style={{
                        width: '100%',
                        padding: '9px 12px',
                        borderRadius: 8,
                        border: 'none',
                        background: '#D97706',
                        color: '#FFF',
                        fontWeight: 800,
                        fontSize: 12,
                        cursor: 'pointer'
                      }}
                    >
                      1. Autorizar Leitura de Notificações (Detectar Lote)
                    </button>
                  )}
                  {!isOverlayGranted && (
                    <button
                      type="button"
                      onClick={() => window.AndroidNative?.openOverlayPermissionSettings?.()}
                      style={{
                        width: '100%',
                        padding: '9px 12px',
                        borderRadius: 8,
                        border: 'none',
                        background: '#2563EB',
                        color: '#FFF',
                        fontWeight: 800,
                        fontSize: 12,
                        cursor: 'pointer'
                      }}
                    >
                      2. Autorizar Sobrepor a Outros Apps (Cronômetro Flutuante)
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Botão Rápido: Disparar / Parar Cronômetro Flutuante Manualmente */}
            <div className="card" style={{ padding: '12px 14px', marginBottom: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 800, color: '#1E293B' }}>
                    🟢 Cronômetro de Janela ({radarDurationMin} min)
                  </div>
                  <div style={{ fontSize: 11, color: '#64748B' }}>
                    {isRadarTimerRunning
                      ? 'Rodando na tela agora! Arraste a pílula para onde preferir.'
                      : 'Dispara sozinho ao chegar alerta do Envios Extra ou toque abaixo:'}
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  type="button"
                  onClick={() => {
                    if (window.AndroidNative && typeof window.AndroidNative.startManualRadarTimer === 'function') {
                      if (!isOverlayGranted && typeof window.AndroidNative.openOverlayPermissionSettings === 'function') {
                        window.AndroidNative.openOverlayPermissionSettings();
                        return;
                      }
                      window.AndroidNative.startManualRadarTimer('Janela Manual (' + radarDurationMin + ' min)');
                      setIsRadarTimerRunning(true);
                    }
                  }}
                  className="btn-primary"
                  style={{
                    flex: 1,
                    padding: '10px',
                    fontSize: 13,
                    fontWeight: 800,
                    background: '#16A34A',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 6
                  }}
                >
                  <Play size={15} /> Iniciar Cronômetro Agora
                </button>

                {isRadarTimerRunning && (
                  <button
                    type="button"
                    onClick={() => {
                      window.AndroidNative?.stopManualRadarTimer?.();
                      setIsRadarTimerRunning(false);
                    }}
                    style={{
                      padding: '10px 14px',
                      fontSize: 13,
                      fontWeight: 800,
                      borderRadius: 10,
                      border: 'none',
                      background: '#DC2626',
                      color: '#FFF',
                      display: 'flex',
                      alignItems: 'center',
                      gap: 4,
                      cursor: 'pointer'
                    }}
                  >
                    <Square size={14} /> Parar
                  </button>
                )}
              </div>
            </div>

            {/* Controles Independentes: Quando ativar Opção 1, Opção 2 e Opção 3 */}
            <div className="card" style={{ padding: '14px', marginBottom: 10 }}>
              <div style={{ fontSize: 14, fontWeight: 800, color: '#1E293B', marginBottom: 10 }}>
                🎛️ Escolher Funções Ativas
              </div>

              {/* OPÇÃO 1: Abrir Cronômetro Automaticamente ao chegar Notificação */}
              <div style={{
                background: radarOpt1Timer ? '#F0FDF4' : '#F8FAFC',
                border: `1px solid ${radarOpt1Timer ? '#86EFAC' : '#E2E8F0'}`,
                borderRadius: 10,
                padding: '10px 12px',
                marginBottom: 8
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ paddingRight: 10 }}>
                    <div style={{ fontSize: 13, fontWeight: 800, color: '#0F172A' }}>
                      1. Abrir Cronômetro Automático
                    </div>
                    <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.3, marginTop: 2 }}>
                      Quando o Envios Extra mandar alerta (ex: Área Afastada), abre o cronômetro flutuante de {radarDurationMin} min na hora.
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setRadarOpt1Timer(!radarOpt1Timer)}
                    style={{
                      minWidth: 64,
                      padding: '7px 10px',
                      borderRadius: 20,
                      border: 'none',
                      background: radarOpt1Timer ? '#16A34A' : '#CBD5E1',
                      color: radarOpt1Timer ? '#FFF' : '#475569',
                      fontWeight: 800,
                      fontSize: 12,
                      cursor: 'pointer'
                    }}
                  >
                    {radarOpt1Timer ? 'ATIVO' : 'OFF'}
                  </button>
                </div>

                {radarOpt1Timer && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8, paddingTop: 8, borderTop: '1px solid rgba(0,0,0,0.06)' }}>
                    <span style={{ fontSize: 11, fontWeight: 700, color: '#334155' }}>Tempo da janela:</span>
                    {[5, 10, 12, 15].map(min => (
                      <button
                        key={min}
                        type="button"
                        onClick={() => setRadarDurationMin(min)}
                        style={{
                          padding: '4px 8px',
                          borderRadius: 6,
                          border: radarDurationMin === min ? '2px solid #15803D' : '1px solid #CBD5E1',
                          background: radarDurationMin === min ? '#DCFCE7' : '#FFF',
                          color: radarDurationMin === min ? '#166534' : '#475569',
                          fontWeight: 800,
                          fontSize: 11,
                          cursor: 'pointer'
                        }}
                      >
                        {min} min
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* OPÇÃO 2: Marcapasso de Atualização (Vibrar / Bipe + Manter Tela Acesa) */}
              <div style={{
                background: radarOpt2Pacer ? '#EFF6FF' : '#F8FAFC',
                border: `1px solid ${radarOpt2Pacer ? '#93C5FD' : '#E2E8F0'}`,
                borderRadius: 10,
                padding: '10px 12px',
                marginBottom: 8
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ paddingRight: 10 }}>
                    <div style={{ fontSize: 13, fontWeight: 800, color: '#0F172A' }}>
                      2. Alerta de Puxar Lista + Tela Acesa
                    </div>
                    <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.3, marginTop: 2 }}>
                      Enquanto o cronômetro estiver na tela, não deixa a tela bloquear e vibra/apita a cada {radarPacerSec}s lembrando de atualizar.
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setRadarOpt2Pacer(!radarOpt2Pacer)}
                    style={{
                      minWidth: 64,
                      padding: '7px 10px',
                      borderRadius: 20,
                      border: 'none',
                      background: radarOpt2Pacer ? '#2563EB' : '#CBD5E1',
                      color: radarOpt2Pacer ? '#FFF' : '#475569',
                      fontWeight: 800,
                      fontSize: 12,
                      cursor: 'pointer'
                    }}
                  >
                    {radarOpt2Pacer ? 'ATIVO' : 'OFF'}
                  </button>
                </div>

                {radarOpt2Pacer && (
                  <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid rgba(0,0,0,0.06)', display: 'flex', flexDirection: 'column', gap: 6 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                      <span style={{ fontSize: 11, fontWeight: 700, color: '#334155' }}>Avisar a cada:</span>
                      {[30, 45, 60].map(sec => (
                        <button
                          key={sec}
                          type="button"
                          onClick={() => setRadarPacerSec(sec)}
                          style={{
                            padding: '4px 8px',
                            borderRadius: 6,
                            border: radarPacerSec === sec ? '2px solid #1D4ED8' : '1px solid #CBD5E1',
                            background: radarPacerSec === sec ? '#DBEAFE' : '#FFF',
                            color: radarPacerSec === sec ? '#1E40AF' : '#475569',
                            fontWeight: 800,
                            fontSize: 11,
                            cursor: 'pointer'
                          }}
                        >
                          {sec}s
                        </button>
                      ))}
                      <button
                        type="button"
                        onClick={() => setRadarPacerBeep(!radarPacerBeep)}
                        style={{
                          marginLeft: 'auto',
                          padding: '4px 8px',
                          borderRadius: 6,
                          border: '1px solid #CBD5E1',
                          background: radarPacerBeep ? '#FEF08A' : '#FFF',
                          color: '#0F172A',
                          fontWeight: 700,
                          fontSize: 11,
                          cursor: 'pointer'
                        }}
                      >
                        {radarPacerBeep ? '🔊 Vibração + Bipe' : '📳 Só Vibração'}
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* OPÇÃO 3: Gravador Automático de Horários dos Lotes */}
              <div style={{
                background: radarOpt3Log ? '#FAF5FF' : '#F8FAFC',
                border: `1px solid ${radarOpt3Log ? '#D8B4FE' : '#E2E8F0'}`,
                borderRadius: 10,
                padding: '10px 12px'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ paddingRight: 10 }}>
                    <div style={{ fontSize: 13, fontWeight: 800, color: '#0F172A' }}>
                      3. Gravar Histórico de Horários
                    </div>
                    <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.3, marginTop: 2 }}>
                      Salva automaticamente hora, minuto, segundo e texto de todas as notificações do Envios Extra.
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setRadarOpt3Log(!radarOpt3Log)}
                    style={{
                      minWidth: 64,
                      padding: '7px 10px',
                      borderRadius: 20,
                      border: 'none',
                      background: radarOpt3Log ? '#7C3AED' : '#CBD5E1',
                      color: radarOpt3Log ? '#FFF' : '#475569',
                      fontWeight: 800,
                      fontSize: 12,
                      cursor: 'pointer'
                    }}
                  >
                    {radarOpt3Log ? 'ATIVO' : 'OFF'}
                  </button>
                </div>
              </div>
            </div>

            {/* Lista do Histórico de Horários de Lotes Capturados (Opção 3) */}
            <div className="card" style={{ padding: '12px 14px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <span style={{ fontSize: 14, fontWeight: 800, color: '#1E293B', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Bell size={15} color="#7C3AED" /> Horários Capturados ({radarLogs.length})
                </span>
                {radarLogs.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm('Limpar histórico de horários capturados?')) {
                        window.AndroidNative?.clearRadarLogs?.();
                        setRadarLogs([]);
                        localStorage.removeItem('radar_batch_logs_cache');
                      }
                    }}
                    style={{ background: 'none', border: 'none', color: '#DC2626', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}
                  >
                    Limpar
                  </button>
                )}
              </div>

              <div style={{ fontSize: 11, color: '#64748B', marginBottom: 10, background: '#F8FAFC', padding: '8px 10px', borderRadius: 8, border: '1px solid #E2E8F0' }}>
                💡 <strong>Ondas descobertas no seu log de Passo Fundo:</strong><br />
                <code>05:28</code> • <code>07:40</code> • <code>09:18</code> • <code>09:47</code> • <code>11:38</code> • <code>12:14</code> • <code>16:02</code> • <code>16:43</code>
              </div>

              {radarLogs.length === 0 ? (
                <p style={{ fontSize: 12, color: '#9CA3AF', textAlign: 'center', padding: '10px 0', margin: 0 }}>
                  Nenhum alerta registrado ainda. Assim que o Envios Extra tocar, o horário exato ao segundo aparecerá aqui!
                </p>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {radarLogs.map((item) => (
                    <div
                      key={item.id}
                      style={{
                        border: '1px solid #E2E8F0',
                        borderRadius: 8,
                        padding: '8px 10px',
                        background: '#F8FAFC'
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 }}>
                        <span style={{ fontSize: 13, fontWeight: 900, color: '#1D4ED8', background: '#DBEAFE', padding: '2px 7px', borderRadius: 6 }}>
                          ⏰ {item.time}
                        </span>
                        <span style={{ fontSize: 10, fontWeight: 700, color: '#64748B' }}>
                          {item.date} • Canal {item.channel}
                        </span>
                      </div>
                      <div style={{ fontSize: 12, fontWeight: 800, color: '#1E293B' }}>
                        {item.title}
                      </div>
                      {item.text && (
                        <div style={{ fontSize: 11, color: '#475569', marginTop: 2 }}>
                          {item.text}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================================================================= */}
        {/* ABA 4: MENSAGEM DO WHATSAPP (LIMPA COM CHAVE SELETORA)            */}
        {/* ================================================================= */}
        {activeTab === 'whatsapp' && (
          <div>
            <div className="card" style={{ padding: '14px' }}>
              {/* Chave seletora lado a lado */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 12 }}>
                <button
                  type="button"
                  onClick={() => {
                    setWaMsgMode('default');
                    setWaSavedFeedback(true);
                    setTimeout(() => setWaSavedFeedback(false), 1800);
                  }}
                  style={{
                    padding: '9px',
                    borderRadius: 8,
                    border: waMsgMode === 'default' ? '2px solid #2D3277' : '1px solid #D1D5DB',
                    background: waMsgMode === 'default' ? '#2D3277' : '#FFF',
                    color: waMsgMode === 'default' ? '#FFF' : '#4B5563',
                    fontWeight: 700,
                    fontSize: 13,
                    cursor: 'pointer'
                  }}
                >
                  Padrão
                </button>
                <button
                  type="button"
                  onClick={() => setWaMsgMode('custom')}
                  style={{
                    padding: '9px',
                    borderRadius: 8,
                    border: waMsgMode === 'custom' ? '2px solid #2D3277' : '1px solid #D1D5DB',
                    background: waMsgMode === 'custom' ? '#2D3277' : '#FFF',
                    color: waMsgMode === 'custom' ? '#FFF' : '#4B5563',
                    fontWeight: 700,
                    fontSize: 13,
                    cursor: 'pointer'
                  }}
                >
                  Personalizada
                </button>
              </div>

              {waMsgMode === 'default' ? (
                <div style={{ background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 10, padding: '12px', fontSize: 13, color: '#334155', lineHeight: 1.4 }}>
                  "{DEFAULT_WHATSAPP_MSG}"
                </div>
              ) : (
                <div>
                  <textarea
                    rows={3}
                    className="input-field"
                    placeholder="Escreva sua mensagem..."
                    value={customWaMsg}
                    onChange={e => setCustomWaMsg(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '10px',
                      fontSize: 13,
                      borderRadius: 8,
                      border: '1px solid #CBD5E1',
                      background: '#F8FAFC',
                      resize: 'vertical'
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setWaSavedFeedback(true);
                      setTimeout(() => setWaSavedFeedback(false), 1800);
                    }}
                    className="btn-primary"
                    style={{ marginTop: 8, padding: '9px', fontSize: 13, width: '100%' }}
                  >
                    Salvar
                  </button>
                </div>
              )}

              {waSavedFeedback && (
                <div style={{ 
                  marginTop: 10,
                  background: '#DCFCE7', 
                  color: '#166534', 
                  padding: '8px', 
                  borderRadius: 8, 
                  fontSize: 12, 
                  fontWeight: 700, 
                  textAlign: 'center',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6
                }}>
                  <Check size={15} /> Salvo!
                </div>
              )}
            </div>

            {/* Card de Preenchimento Automático de CPF */}
            <div className="card" style={{ padding: '14px', marginTop: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <span style={{ fontSize: 14, fontWeight: 800, color: '#1E293B' }}>
                  Preenchimento Automático de CPF
                </span>
                <span style={{
                  fontSize: 11,
                  fontWeight: 700,
                  padding: '3px 8px',
                  borderRadius: 8,
                  background: isAutofillActive ? '#DCFCE7' : '#FEF3C7',
                  color: isAutofillActive ? '#15803D' : '#B45309'
                }}>
                  {isAutofillActive ? 'Ativo' : 'Desativado'}
                </span>
              </div>
              <p style={{ fontSize: 11, color: '#64748B', margin: '0 0 10px', lineHeight: 1.4 }}>
                Ao segurar o dedo em qualquer campo em branco e tocar em <strong>Preenchimento automático</strong>, preenche um CPF válido de 11 dígitos na hora.
              </p>
              <button
                type="button"
                onClick={() => {
                  if (window.AndroidNative && typeof window.AndroidNative.openAutofillSettings === 'function') {
                    window.AndroidNative.openAutofillSettings();
                  }
                }}
                className="btn-primary"
                style={{
                  width: '100%',
                  padding: '10px',
                  fontSize: 13,
                  fontWeight: 800,
                  background: isAutofillActive ? '#16A34A' : '#2563EB'
                }}
              >
                {isAutofillActive ? 'Configurado (Toque para alterar)' : 'Ativar Preenchimento Automático'}
              </button>

              {!isBatteryFree && (
                <button
                  type="button"
                  onClick={() => {
                    if (window.AndroidNative && typeof window.AndroidNative.requestUnrestrictedBattery === 'function') {
                      window.AndroidNative.requestUnrestrictedBattery();
                    }
                  }}
                  style={{
                    width: '100%',
                    marginTop: 8,
                    padding: '9px',
                    fontSize: 12,
                    fontWeight: 700,
                    borderRadius: 8,
                    border: '1px solid #F59E0B',
                    background: '#FFFBEB',
                    color: '#B45309',
                    cursor: 'pointer'
                  }}
                >
                  ⚡ Evitar atraso em 2º plano (Liberar Bateria)
                </button>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
