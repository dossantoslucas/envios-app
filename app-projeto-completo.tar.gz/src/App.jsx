import React, { useState, useEffect } from 'react';
import { 
  Image as ImageIcon, 
  Calculator, 
  Calendar as CalendarIcon, 
  Award, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp, 
  Plus, 
  Trash2, 
  Truck, 
  Package, 
  RefreshCw,
  Info
} from 'lucide-react';
import { LEVEL_CRITERIA, determineLevel, compareWithLevelTarget } from './utils/calculator';
import { parseEnviosExtraImage } from './utils/ocrService';
import { parseRouteStopImage } from './utils/routeOcrService';

export default function App() {
  const [activeTab, setActiveTab] = useState('analyzer'); // 'analyzer' | 'calculator' | 'journal'

  // Dados extraídos da tela do print (iniciam zerados para nova instalação)
  const [points, setPoints] = useState(0);
  const [successRate, setSuccessRate] = useState(0);
  const [noComplaintRate, setNoComplaintRate] = useState(0);
  const [imagePreview, setImagePreview] = useState(null);
  const [isProcessingOcr, setIsProcessingOcr] = useState(false);
  const [ocrProgress, setOcrProgress] = useState(0);

  // Dados da simulação (iniciam zerados)
  const [totalMonthDelivered, setTotalMonthDelivered] = useState('0');
  const [targetLevelKey, setTargetLevelKey] = useState('PLATINUM');

  // Diário de entregas (inicia vazio)
  const [entries, setEntries] = useState(() => {
    const saved = localStorage.getItem('envios_extra_entries');
    if (saved) {
      try { return JSON.parse(saved); } catch (_) {}
    }
    return [];
  });

  // Novo registro de dia
  const [newDate, setNewDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [newLoaded, setNewLoaded] = useState('');
  const [isHistoryExpanded, setIsHistoryExpanded] = useState(false);
  const [isManualExpanded, setIsManualExpanded] = useState(false);
  const [isProcessingRouteBatch, setIsProcessingRouteBatch] = useState(false);
  const [batchProgress, setBatchProgress] = useState('');

  // Salvar entradas no localStorage
  useEffect(() => {
    localStorage.setItem('envios_extra_entries', JSON.stringify(entries));
  }, [entries]);

  // Nível atual com base nos dados
  const currentLevel = determineLevel(points, successRate, noComplaintRate);
  const parsedTotalMonth = Number(totalMonthDelivered) || 0;
  const comparison = compareWithLevelTarget(parsedTotalMonth, points, successRate, noComplaintRate, targetLevelKey);

  // Filtrar apenas rotas pertencentes ao mês vigente para não somar meses passados
  const currentMonthPrefix = new Date().toISOString().slice(0, 7); // Ex: "2026-10"
  const currentMonthEntries = entries.filter(item => item.date && item.date.startsWith(currentMonthPrefix));

  // Totais do Mês Vigente
  const totalLoadedInMonth = currentMonthEntries.reduce((acc, curr) => acc + (Number(curr.loaded) || 0), 0);
  const totalLoadedInJournal = totalLoadedInMonth; // Alias para compatibilidade

  // Atualizar total do mês puxando os pacotes carregados do histórico
  const syncWithJournal = () => {
    if (totalLoadedInMonth > 0) {
      setTotalMonthDelivered(String(totalLoadedInMonth));
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImagePreview(URL.createObjectURL(file));
    setIsProcessingOcr(true);
    setOcrProgress(10);

    try {
      const result = await parseEnviosExtraImage(file, (p) => setOcrProgress(p));
      if (result && result.success) {
        if (result.points) setPoints(result.points);
        if (result.successRate) setSuccessRate(result.successRate);
        if (result.noComplaintRate) setNoComplaintRate(result.noComplaintRate);
        
        // Redireciona automaticamente para o Simulador logo após a leitura
        setTimeout(() => {
          setActiveTab('calculator');
        }, 500);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessingOcr(false);
      setOcrProgress(0);
    }
  };

  // Função para processar múltiplos prints de rotas/ganhos de uma vez só
  const handleBatchRouteUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setIsProcessingRouteBatch(true);
    const newAddedEntries = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setBatchProgress(`Lendo print ${i + 1} de ${files.length}...`);
      try {
        const result = await parseRouteStopImage(file);
        if (result && result.success) {
          const loaded = result.totalStops;
          const delivered = result.visitedStops;
          const failed = Math.max(0, loaded - delivered);
          
          // Usa a data extraída do print (ex: 2026-10-05) ou o dia de hoje como fallback
          const entryDate = result.isoDate || newDate;
          const noteText = result.displayDate 
            ? `Rota de ${result.displayDate} (${result.visitedStops}/${result.totalStops} paradas)` 
            : `Visitou ${result.visitedStops}/${result.totalStops} paradas`;

          newAddedEntries.push({
            id: (Date.now() + i).toString(),
            date: entryDate,
            loaded,
            delivered,
            failed,
            earnings: result.earnings || '',
            notes: noteText
          });
        }
      } catch (err) {
        console.error('Erro ao ler print:', err);
      }
    }

    if (newAddedEntries.length > 0) {
      setEntries(prev => [...newAddedEntries, ...prev]);
    }
    setIsProcessingRouteBatch(false);
    setBatchProgress('');
    e.target.value = '';
  };

  const handleAddEntry = (e) => {
    e.preventDefault();
    const loaded = Number(newLoaded) || 0;
    if (loaded <= 0) return;

    const newEntry = {
      id: Date.now().toString(),
      date: newDate,
      loaded,
      delivered: loaded,
      failed: 0,
      notes: 'Adicionado manualmente'
    };

    setEntries([newEntry, ...entries]);
    setNewLoaded('');
    setIsManualExpanded(false);
  };

  const handleDeleteEntry = (id) => {
    setEntries(entries.filter(item => item.id !== id));
  };

  return (
    <div className="app-container">
      {/* Barra Superior */}
      <header className="top-bar">
        <div className="top-bar-title">
          <span>📦</span> Envios Extra Calc
        </div>
        <div className={`badge ${currentLevel.badgeClass}`}>
          <Award size={14} />
          {currentLevel.name}
        </div>
      </header>

      {/* Abas de Navegação */}
      <nav className="nav-tabs">
        <button 
          className={`nav-tab-btn ${activeTab === 'analyzer' ? 'active' : ''}`}
          onClick={() => setActiveTab('analyzer')}
        >
          <ImageIcon size={16} /> Leitor Print
        </button>
        <button 
          className={`nav-tab-btn ${activeTab === 'calculator' ? 'active' : ''}`}
          onClick={() => setActiveTab('calculator')}
        >
          <Calculator size={16} /> Simulador
        </button>
        <button 
          className={`nav-tab-btn ${activeTab === 'journal' ? 'active' : ''}`}
          onClick={() => setActiveTab('journal')}
        >
          <CalendarIcon size={16} /> Diário de Rotas
        </button>
      </nav>

      {/* Conteúdo Principal */}
      <main className="content-body">
        {/* ABA 1: LEITOR DE PRINT E STATUS */}
        {activeTab === 'analyzer' && (
          <div>
            <div className="card" style={{ textAlign: 'center', padding: '24px 16px' }}>
              <div style={{ width: 64, height: 64, borderRadius: '50%', background: '#EFF6FF', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                <ImageIcon size={32} color="#3483FA" />
              </div>

              <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8, color: '#1E293B' }}>
                Selecionar Print do Envios Extra
              </h2>
              <p style={{ fontSize: 13, color: '#64748B', maxWidth: 320, margin: '0 auto 20px', lineHeight: 1.5 }}>
                Escolha a captura de tela "Meu nível" da sua galeria. O app lerá seus pontos e taxas e abrirá o simulador automaticamente.
              </p>

              <label className="upload-area" style={{ display: 'block', padding: '28px 16px', cursor: 'pointer' }}>
                <input 
                  type="file" 
                  accept="image/*" 
                  style={{ display: 'none' }} 
                  onChange={handleFileUpload}
                />
                {isProcessingOcr ? (
                  <div>
                    <RefreshCw className="spin" size={32} color="#3483FA" style={{ animation: 'spin 1s linear infinite', margin: '0 auto' }} />
                    <p style={{ marginTop: 12, fontWeight: 700, fontSize: 15, color: '#1E40AF' }}>Processando print... {ocrProgress}%</p>
                    <span style={{ fontSize: 12, color: '#64748B' }}>Identificando pontos e porcentagens...</span>
                  </div>
                ) : (
                  <div>
                    <ImageIcon size={36} color="#3483FA" style={{ margin: '0 auto 10px' }} />
                    <p style={{ fontWeight: 700, fontSize: 15, color: '#1E40AF' }}>Toque para selecionar da galeria</p>
                    <span style={{ fontSize: 12, color: '#6B7280' }}>Carregue a captura de tela salva no celular</span>
                  </div>
                )}
              </label>

              {imagePreview && (
                <div style={{ marginTop: 16, textAlign: 'center' }}>
                  <span style={{ fontSize: 12, color: '#64748B', display: 'block', marginBottom: 6 }}>Último print enviado:</span>
                  <img 
                    src={imagePreview} 
                    alt="Preview" 
                    style={{ maxHeight: 180, borderRadius: 8, border: '1px solid #E2E8F0' }} 
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {/* ABA 2: SIMULADOR DE METAS COMPACTO E SEM SCROLL */}
        {activeTab === 'calculator' && (
          <div>
            {/* 1. SELEÇÃO DE NÍVEL E ENTRADA DE PACOTES AUTOEXPLICATIVA */}
            <div className="card" style={{ padding: '12px 14px', marginBottom: 10 }}>
              {/* Botões dos 4 níveis */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6, marginBottom: 12 }}>
                {['PLATINUM', 'GOLD', 'SILVER', 'BRONZE'].map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setTargetLevelKey(lvl)}
                    style={{
                      padding: '8px 4px',
                      borderRadius: 8,
                      border: targetLevelKey === lvl ? '2px solid #2D3277' : '1px solid #D1D5DB',
                      background: targetLevelKey === lvl ? '#2D3277' : '#FFF',
                      color: targetLevelKey === lvl ? '#FFF' : '#4B5563',
                      fontWeight: 700,
                      fontSize: 12,
                      cursor: 'pointer'
                    }}
                  >
                    {LEVEL_CRITERIA[lvl].name}
                  </button>
                ))}
              </div>

              {/* Rótulo Limpo e Sem Redundâncias */}
              <div style={{ marginBottom: 6 }}>
                <label style={{ fontSize: 13, fontWeight: 700, color: '#1E293B' }}>
                  📦 Pacotes Carregados no Mês
                </label>
              </div>

              {/* Campo Limpo + Botão Somar Histórico + Botão Recalcular */}
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <div style={{ flex: 1 }}>
                  <input 
                    type="number" 
                    className="input-field"
                    value={totalMonthDelivered}
                    onChange={e => setTotalMonthDelivered(e.target.value)}
                    onFocus={e => e.target.select()}
                    placeholder="Ex: 500"
                    style={{ 
                      padding: '10px 12px', 
                      fontSize: 16, 
                      fontWeight: 800,
                      color: '#0F172A'
                    }}
                  />
                </div>

                {totalLoadedInMonth > 0 && (
                  <button 
                    type="button" 
                    className="btn-secondary" 
                    style={{ 
                      width: 'auto', 
                      padding: '8px 10px', 
                      fontSize: 11, 
                      fontWeight: 700, 
                      display: 'flex', 
                      flexDirection: 'column', 
                      alignItems: 'center', 
                      lineHeight: 1.1,
                      background: '#EFF6FF',
                      borderColor: '#BFDBFE'
                    }}
                    onClick={syncWithJournal}
                    title="Preencher com o total de pacotes somados no histórico deste mês"
                  >
                    <span style={{ color: '#1E40AF' }}>Somar Histórico</span>
                    <strong style={{ color: '#1D4ED8' }}>({totalLoadedInMonth})</strong>
                  </button>
                )}
                <button 
                  type="button" 
                  className="btn-primary" 
                  style={{ width: 'auto', padding: '10px 14px', borderRadius: 8 }}
                  onClick={() => {
                    if (window.navigator?.vibrate) window.navigator.vibrate(30);
                  }}
                  title="Recalcular"
                >
                  <RefreshCw size={16} />
                </button>
              </div>
            </div>

            {/* 2. PLACAR PRINCIPAL COM CORES DINÂMICAS INTELIGENTES */}
            {(() => {
              // Quando o app acabou de ser instalado e não possui dados reais (0 pacotes e 0 pontos)
              const hasNoData = parsedTotalMonth === 0 && points === 0;

              if (hasNoData) {
                return (
                  <div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
                      {/* Card Falhas Neutro */}
                      <div style={{ 
                        background: '#F8FAFC', 
                        border: '2px dashed #CBD5E1', 
                        borderRadius: 12, 
                        padding: '16px 10px',
                        textAlign: 'center'
                      }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: '#64748B', textTransform: 'uppercase' }}>
                          Falhas de Entrega
                        </div>
                        <div style={{ fontSize: 26, fontWeight: 800, color: '#94A3B8', margin: '6px 0' }}>
                          --
                        </div>
                        <div style={{ fontSize: 11, color: '#64748B', fontWeight: 500 }}>
                          Aguardando dados
                        </div>
                      </div>

                      {/* Card Reclamações Neutro */}
                      <div style={{ 
                        background: '#F8FAFC', 
                        border: '2px dashed #CBD5E1', 
                        borderRadius: 12, 
                        padding: '16px 10px',
                        textAlign: 'center'
                      }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: '#64748B', textTransform: 'uppercase' }}>
                          Reclamações
                        </div>
                        <div style={{ fontSize: 26, fontWeight: 800, color: '#94A3B8', margin: '6px 0' }}>
                          --
                        </div>
                        <div style={{ fontSize: 11, color: '#64748B', fontWeight: 500 }}>
                          Aguardando dados
                        </div>
                      </div>
                    </div>

                    {/* Banner amigável orientando o primeiro passo */}
                    <div style={{ 
                      background: '#EFF6FF', 
                      border: '1px solid #BFDBFE', 
                      borderRadius: 10, 
                      padding: '12px 14px', 
                      textAlign: 'center', 
                      marginBottom: 10 
                    }}>
                      <p style={{ fontSize: 13, color: '#1E40AF', fontWeight: 600, margin: 0 }}>
                        📸 Envie um print na aba <strong>Leitor Print</strong> ou digite seus pacotes carregados para calcular suas metas!
                      </p>
                    </div>
                  </div>
                );
              }

              // Lógica de Cores Semafóricas quando houver dados:
              const isSuccessUnder = !comparison.successAnalysis.reached;
              const isSuccessAlert = comparison.successAnalysis.marginPacotes === 0;
              const successBg = isSuccessUnder ? '#FFF1F2' : isSuccessAlert ? '#FFFBEB' : '#F0FDF4';
              const successBorder = isSuccessUnder ? '#FECDD3' : isSuccessAlert ? '#FDE68A' : '#86EFAC';
              const successColor = isSuccessUnder ? '#DC2626' : isSuccessAlert ? '#D97706' : '#16A34A';
              const successTitleColor = isSuccessUnder ? '#BE123C' : isSuccessAlert ? '#B45309' : '#15803D';

              const isComplaintUnder = comparison.target.key !== 'BRONZE' && !comparison.complaintAnalysis.reached;
              const isComplaintAlert = comparison.target.key !== 'BRONZE' && comparison.complaintAnalysis.allowedAdditionalComplaints === 0;
              const complaintBg = isComplaintUnder ? '#FFF1F2' : isComplaintAlert ? '#FFFBEB' : '#F0FDF4';
              const complaintBorder = isComplaintUnder ? '#FECDD3' : isComplaintAlert ? '#FDE68A' : '#86EFAC';
              const complaintColor = isComplaintUnder ? '#DC2626' : isComplaintAlert ? '#D97706' : '#16A34A';
              const complaintTitleColor = isComplaintUnder ? '#BE123C' : isComplaintAlert ? '#B45309' : '#15803D';

              return (
                <div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
                    {/* Card Falhas */}
                    <div style={{ 
                      background: successBg, 
                      border: `2px solid ${successBorder}`, 
                      borderRadius: 12, 
                      padding: '12px 10px',
                      textAlign: 'center'
                    }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: successTitleColor, textTransform: 'uppercase' }}>
                        Falhas de Entrega
                      </div>
                      <div style={{ fontSize: 28, fontWeight: 900, color: successColor, margin: '4px 0' }}>
                        {isSuccessUnder ? '0' : `+${comparison.successAnalysis.marginPacotes}`}
                      </div>
                      <div style={{ fontSize: 11, color: '#475569', fontWeight: 600 }}>
                        {isSuccessUnder 
                          ? `precisa de +${comparison.successAnalysis.neededConsecutiveSuccess} acertos`
                          : isSuccessAlert 
                            ? 'limite! não pode falhar' 
                            : 'ainda pode ter'}
                      </div>
                      <div style={{ fontSize: 11, color: '#334155', marginTop: 6, borderTop: '1px solid rgba(0,0,0,0.06)', paddingTop: 5, fontWeight: 600 }}>
                        Ocorreram: <strong>{comparison.successAnalysis.deliveredFailedCount}</strong> (limite: <strong>{comparison.successAnalysis.maxAllowedFailures}</strong>)
                      </div>
                    </div>

                    {/* Card Reclamações */}
                    <div style={{ 
                      background: complaintBg, 
                      border: `2px solid ${complaintBorder}`, 
                      borderRadius: 12, 
                      padding: '12px 10px',
                      textAlign: 'center'
                    }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: complaintTitleColor, textTransform: 'uppercase' }}>
                        Reclamações
                      </div>
                      <div style={{ fontSize: 28, fontWeight: 900, color: complaintColor, margin: '4px 0' }}>
                        {comparison.target.key === 'BRONZE' ? 'Livre' : `+${comparison.complaintAnalysis.allowedAdditionalComplaints}`}
                      </div>
                      <div style={{ fontSize: 11, color: '#475569', fontWeight: 600 }}>
                        {comparison.target.key === 'BRONZE' 
                          ? 'sem corte no nível' 
                          : isComplaintAlert 
                            ? 'limite! se receber cai' 
                            : 'ainda pode ter (max)'}
                      </div>
                      <div style={{ fontSize: 11, color: '#334155', marginTop: 6, borderTop: '1px solid rgba(0,0,0,0.06)', paddingTop: 5, fontWeight: 600 }}>
                        {comparison.target.key === 'BRONZE' ? (
                          <span>Sem limite no Bronze</span>
                        ) : (
                          <>Ocorreram: <strong>{comparison.complaintAnalysis.complaintCount}</strong> (limite: <strong>{comparison.complaintAnalysis.maxAllowedComplaints}</strong>)</>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* 3. RESUMO ULTRA COMPACTO DOS 3 INDICADORES DO PRINT */}
                  <div className="card" style={{ padding: '10px 14px', marginBottom: 10 }}>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, textAlign: 'center' }}>
                      {/* Pontos */}
                      <div>
                        <div style={{ fontSize: 11, color: '#64748B' }}>Pontos</div>
                        <div style={{ fontSize: 15, fontWeight: 800, color: points >= comparison.pointsStatus.target ? '#16A34A' : '#DC2626' }}>
                          {points}
                        </div>
                        <div style={{ fontSize: 10, color: '#94A3B8' }}>Meta: {comparison.pointsStatus.target}</div>
                      </div>

                      {/* Sucesso % */}
                      <div>
                        <div style={{ fontSize: 11, color: '#64748B' }}>Sucesso</div>
                        <div style={{ fontSize: 15, fontWeight: 800, color: successRate >= comparison.successAnalysis.targetRate ? '#16A34A' : '#DC2626' }}>
                          {successRate}%
                        </div>
                        <div style={{ fontSize: 10, color: '#94A3B8' }}>Meta: {comparison.successAnalysis.targetRate}%</div>
                      </div>

                      {/* Sem Reclamações % */}
                      <div>
                        <div style={{ fontSize: 11, color: '#64748B' }}>Sem Queixa</div>
                        <div style={{ fontSize: 15, fontWeight: 800, color: noComplaintRate >= comparison.complaintAnalysis.targetRate ? '#16A34A' : '#DC2626' }}>
                          {noComplaintRate}%
                        </div>
                        <div style={{ fontSize: 10, color: '#94A3B8' }}>Meta: {comparison.complaintAnalysis.targetRate}%</div>
                      </div>
                    </div>
                  </div>

                  {/* 4. EXPANSÃO DE MARGEM DIRETA (1 LINHA) - APENAS QUANDO HOUVER DADOS REAIS */}
                  <div style={{ 
                    background: '#FFFFFF', 
                    border: '1px solid #E2E8F0', 
                    borderRadius: 10, 
                    padding: '8px 12px',
                    fontSize: 12,
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}>
                    <span style={{ color: '#475569' }}>📦 <strong>+49 pacotes</strong> liberam +1 falha</span>
                    <span style={{ color: '#475569' }}>⚠️ <strong>+334 pacotes</strong> liberam +1 queixa</span>
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {/* ABA 3: HISTÓRICO DE ROTAS ULTRA LIMPO E MINIMALISTA */}
        {activeTab === 'journal' && (
          <div>
            {/* 1. CARD PRINCIPAL UNIFICADO: PACOTES CARREGADOS NO MÊS + IMPORTAR PRINTS */}
            <div className="card" style={{ padding: '16px', textAlign: 'center', marginBottom: 12 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#475569', textTransform: 'uppercase' }}>
                Pacotes Carregados no Mês
              </div>
              <div style={{ fontSize: 36, fontWeight: 900, color: '#1D4ED8', margin: '4px 0' }}>
                {totalLoadedInMonth} <span style={{ fontSize: 16, fontWeight: 600, color: '#64748B' }}>pacotes</span>
              </div>
              <div style={{ fontSize: 12, color: '#94A3B8', marginBottom: 14 }}>
                {currentMonthEntries.length} {currentMonthEntries.length === 1 ? 'rota no mês vigente' : 'rotas no mês vigente'}
              </div>

              {/* Botão de Importar Prints da Galeria */}
              <label 
                className="btn-primary" 
                style={{ 
                  cursor: 'pointer', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  gap: 8,
                  padding: '12px 14px',
                  borderRadius: 10
                }}
              >
                <input 
                  type="file" 
                  accept="image/*" 
                  multiple 
                  style={{ display: 'none' }} 
                  onChange={handleBatchRouteUpload}
                  disabled={isProcessingRouteBatch}
                />
                {isProcessingRouteBatch ? (
                  <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <RefreshCw className="spin" size={16} /> {batchProgress}
                  </span>
                ) : (
                  <>
                    <ImageIcon size={18} />
                    <span>Importar Prints da Galeria</span>
                  </>
                )}
              </label>
            </div>

            {/* 2. HISTÓRICO DE ROTAS RECOLHÍVEL COM OPÇÃO DE ADICIONAR ROTA EXTRA */}
            <div className="card" style={{ padding: '12px 14px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <button 
                  type="button"
                  onClick={() => setIsHistoryExpanded(!isHistoryExpanded)}
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: 6, 
                    fontSize: 14, 
                    fontWeight: 700, 
                    color: '#1E293B',
                    cursor: 'pointer',
                    padding: 0
                  }}
                >
                  <span>{isHistoryExpanded ? '▼' : '►'} Histórico de Rotas ({currentMonthEntries.length})</span>
                </button>

                <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                  <button 
                    type="button"
                    onClick={() => {
                      setIsHistoryExpanded(true);
                      setIsManualExpanded(true);
                    }}
                    style={{ background: 'none', border: 'none', color: '#00A650', fontSize: 12, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 3 }}
                  >
                    <Plus size={14} /> Rota Extra
                  </button>

                  {entries.length > 0 && (
                    <button 
                      onClick={() => {
                        if (window.confirm('Deseja limpar todos os registros do histórico?')) {
                          setEntries([]);
                        }
                      }}
                      style={{ background: 'none', border: 'none', color: '#DC2626', fontSize: 11, fontWeight: 600, cursor: 'pointer' }}
                    >
                      Limpar
                    </button>
                  )}
                </div>
              </div>

              {/* Formulário para Adicionar Rota Extra (se clicado) */}
              {isManualExpanded && (
                <form onSubmit={handleAddEntry} style={{ marginTop: 12, padding: 10, background: '#F8FAFC', borderRadius: 8, border: '1px solid #E2E8F0' }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: '#334155', marginBottom: 6 }}>
                    + Adicionar Rota Manual
                  </div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                    <input 
                      type="date" 
                      className="input-field" 
                      value={newDate} 
                      onChange={e => setNewDate(e.target.value)} 
                      style={{ flex: 1, padding: '8px 10px', fontSize: 13 }}
                      required
                    />
                    <input 
                      type="number" 
                      className="input-field" 
                      placeholder="Qtd pacotes" 
                      value={newLoaded} 
                      onChange={e => setNewLoaded(e.target.value)} 
                      style={{ flex: 1, padding: '8px 10px', fontSize: 13, fontWeight: 700 }}
                      required
                      autoFocus
                    />
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button type="submit" className="btn-yellow" style={{ flex: 1, padding: '8px', fontSize: 13 }}>
                      Salvar Rota
                    </button>
                    <button 
                      type="button" 
                      className="btn-secondary" 
                      onClick={() => setIsManualExpanded(false)}
                      style={{ width: 'auto', padding: '8px 14px', fontSize: 13 }}
                    >
                      Cancelar
                    </button>
                  </div>
                </form>
              )}

              {/* Lista de Rotas Expandida */}
              {isHistoryExpanded && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}>
                  {currentMonthEntries.length === 0 ? (
                    <p style={{ fontSize: 12, color: '#9CA3AF', textAlign: 'center', padding: '10px 0' }}>
                      Nenhuma rota registrada neste mês.
                    </p>
                  ) : (
                    currentMonthEntries.map(item => (
                      <div 
                        key={item.id} 
                        style={{ 
                          border: '1px solid #E2E8F0', 
                          borderRadius: 8, 
                          padding: '8px 12px', 
                          background: '#F8FAFC',
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center'
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <span style={{ fontSize: 13, fontWeight: 700, color: '#334155' }}>
                            {new Date(item.date + 'T00:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
                          </span>
                          <span style={{ fontSize: 13, color: '#64748B' }}>•</span>
                          <span style={{ fontSize: 14, fontWeight: 800, color: '#1D4ED8' }}>
                            {item.loaded} pacotes
                          </span>
                        </div>

                        <button 
                          onClick={() => handleDeleteEntry(item.id)}
                          style={{ background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer', padding: 4 }}
                          title="Excluir"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
