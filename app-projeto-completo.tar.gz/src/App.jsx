import React, { useState, useEffect, useCallback } from 'react';
import { Bell, Clock, Play, Square, ShieldCheck } from 'lucide-react';

export default function App() {
  const [radarOpt1Timer, setRadarOpt1Timer] = useState(() => localStorage.getItem('radar_opt1_timer') !== 'false');
  const [radarOpt2Pacer, setRadarOpt2Pacer] = useState(() => localStorage.getItem('radar_opt2_pacer') !== 'false');
  const [radarOpt3Log, setRadarOpt3Log] = useState(() => localStorage.getItem('radar_opt3_log') !== 'false');
  const [radarDurationMin, setRadarDurationMin] = useState(() => Number(localStorage.getItem('radar_duration_min')) || 10);
  const [radarPacerSec, setRadarPacerSec] = useState(() => Number(localStorage.getItem('radar_pacer_sec')) || 45);
  const [radarPacerBeep, setRadarPacerBeep] = useState(() => localStorage.getItem('radar_pacer_beep') !== 'false');

  const [isNotifListenerEnabled, setIsNotifListenerEnabled] = useState(false);
  const [isOverlayGranted, setIsOverlayGranted] = useState(false);
  const [isBatteryFree, setIsBatteryFree] = useState(true);
  const [isRadarTimerRunning, setIsRadarTimerRunning] = useState(false);
  const [radarLogs, setRadarLogs] = useState(() => {
    try {
      const saved = localStorage.getItem('radar_batch_logs_cache');
      return saved ? JSON.parse(saved) : [];
    } catch (_) {
      return [];
    }
  });

  const syncNativeState = useCallback(() => {
    if (window.AndroidNative) {
      if (typeof window.AndroidNative.isNotificationListenerEnabled === 'function') {
        try { setIsNotifListenerEnabled(Boolean(window.AndroidNative.isNotificationListenerEnabled())); } catch (_) {}
      }
      if (typeof window.AndroidNative.isOverlayPermissionGranted === 'function') {
        try { setIsOverlayGranted(Boolean(window.AndroidNative.isOverlayPermissionGranted())); } catch (_) {}
      }
      if (typeof window.AndroidNative.isBatteryUnrestricted === 'function') {
        try { setIsBatteryFree(Boolean(window.AndroidNative.isBatteryUnrestricted())); } catch (_) {}
      }
      if (typeof window.AndroidNative.getRadarConfig === 'function') {
        try {
          const cfgRaw = window.AndroidNative.getRadarConfig();
          if (cfgRaw) {
            const cfg = JSON.parse(cfgRaw);
            setIsRadarTimerRunning(Boolean(cfg.isRunning));
          }
        } catch (_) {}
      }
      if (typeof window.AndroidNative.getRadarLogs === 'function') {
        try {
          const logsRaw = window.AndroidNative.getRadarLogs();
          if (logsRaw) {
            const parsedLogs = JSON.parse(logsRaw);
            if (Array.isArray(parsedLogs)) {
              setRadarLogs(parsedLogs);
              localStorage.setItem('radar_batch_logs_cache', JSON.stringify(parsedLogs));
            }
          }
        } catch (_) {}
      }
    }
  }, []);

  useEffect(() => {
    syncNativeState();
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') syncNativeState();
    };
    window.addEventListener('focus', syncNativeState);
    document.addEventListener('visibilitychange', handleVisibility);
    const interval = setInterval(syncNativeState, 2000);
    return () => {
      window.removeEventListener('focus', syncNativeState);
      document.removeEventListener('visibilitychange', handleVisibility);
      clearInterval(interval);
    };
  }, [syncNativeState]);

  useEffect(() => {
    localStorage.setItem('radar_opt1_timer', String(radarOpt1Timer));
    localStorage.setItem('radar_opt2_pacer', String(radarOpt2Pacer));
    localStorage.setItem('radar_opt3_log', String(radarOpt3Log));
    localStorage.setItem('radar_duration_min', String(radarDurationMin));
    localStorage.setItem('radar_pacer_sec', String(radarPacerSec));
    localStorage.setItem('radar_pacer_beep', String(radarPacerBeep));

    if (window.AndroidNative && typeof window.AndroidNative.saveRadarConfig === 'function') {
      try {
        window.AndroidNative.saveRadarConfig(
          Boolean(radarOpt1Timer),
          Boolean(radarOpt2Pacer),
          Boolean(radarOpt3Log),
          Number(radarDurationMin) || 10,
          Number(radarPacerSec) || 45,
          Boolean(radarPacerBeep)
        );
      } catch (e) {
        console.error('Erro ao salvar config do radar:', e);
      }
    }
  }, [radarOpt1Timer, radarOpt2Pacer, radarOpt3Log, radarDurationMin, radarPacerSec, radarPacerBeep]);

  return (
    <div className="app-container">
      {/* Barra Superior Exclusiva do App Separado */}
      <header className="top-bar" style={{ background: '#0F172A' }}>
        <div className="top-bar-title" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Clock size={18} color="#4ADE80" />
          <span>Radar de Lotes</span>
        </div>
        <div style={{
          fontSize: 11,
          fontWeight: 800,
          padding: '4px 10px',
          borderRadius: 20,
          background: isNotifListenerEnabled && isOverlayGranted ? '#166534' : '#B45309',
          color: '#FFF',
          display: 'flex',
          alignItems: 'center',
          gap: 4
        }}>
          <ShieldCheck size={13} />
          {isNotifListenerEnabled && isOverlayGranted ? 'Radar Pronto' : 'Configurar'}
        </div>
      </header>

      <main className="content-body" style={{ paddingTop: 12 }}>
        {/* Permissões */}
        {(!isNotifListenerEnabled || !isOverlayGranted || !isBatteryFree) && (
          <div className="card" style={{ padding: '12px 14px', marginBottom: 10, background: '#FFFBEB', border: '1px solid #FDE68A' }}>
            <div style={{ fontSize: 13, fontWeight: 800, color: '#92400E', marginBottom: 8 }}>
              ⚙️ Ative as permissões para o Radar funcionar em 2º plano:
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {!isNotifListenerEnabled && (
                <button
                  type="button"
                  onClick={() => window.AndroidNative?.openNotificationListenerSettings?.()}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    borderRadius: 8,
                    border: 'none',
                    background: '#D97706',
                    color: '#FFF',
                    fontWeight: 800,
                    fontSize: 12,
                    cursor: 'pointer'
                  }}
                >
                  1. Autorizar Leitura de Notificações (Detectar Lote)
                </button>
              )}
              {!isOverlayGranted && (
                <button
                  type="button"
                  onClick={() => window.AndroidNative?.openOverlayPermissionSettings?.()}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    borderRadius: 8,
                    border: 'none',
                    background: '#2563EB',
                    color: '#FFF',
                    fontWeight: 800,
                    fontSize: 12,
                    cursor: 'pointer'
                  }}
                >
                  2. Autorizar Sobrepor a Outros Apps (Cronômetro Flutuante)
                </button>
              )}
              {!isBatteryFree && (
                <button
                  type="button"
                  onClick={() => window.AndroidNative?.requestUnrestrictedBattery?.()}
                  style={{
                    width: '100%',
                    padding: '9px 12px',
                    borderRadius: 8,
                    border: '1px solid #F59E0B',
                    background: '#FEF3C7',
                    color: '#92400E',
                    fontWeight: 800,
                    fontSize: 12,
                    cursor: 'pointer'
                  }}
                >
                  ⚡ 3. Liberar Bateria em 2º Plano (Sem Restrições)
                </button>
              )}
            </div>
          </div>
        )}

        {/* Controle Manual do Cronômetro Flutuante */}
        <div className="card" style={{ padding: '12px 14px', marginBottom: 10 }}>
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 14, fontWeight: 800, color: '#1E293B' }}>
              🟢 Cronômetro Flutuante ({radarDurationMin} min)
            </div>
            <div style={{ fontSize: 11, color: '#64748B', marginTop: 2 }}>
              {isRadarTimerRunning
                ? 'Cronômetro ativo na tela! Você pode arrastar a pílula com o dedo.'
                : 'Abre sozinho quando o Envios Extra toca ou inicie manualmente abaixo:'}
            </div>
          </div>

          <div style={{ display: 'flex', gap: 8 }}>
            <button
              type="button"
              onClick={() => {
                if (window.AndroidNative && typeof window.AndroidNative.startManualRadarTimer === 'function') {
                  if (!isOverlayGranted && typeof window.AndroidNative.openOverlayPermissionSettings === 'function') {
                    window.AndroidNative.openOverlayPermissionSettings();
                    return;
                  }
                  window.AndroidNative.startManualRadarTimer('Janela Manual (' + radarDurationMin + ' min)');
                  setIsRadarTimerRunning(true);
                }
              }}
              className="btn-primary"
              style={{
                flex: 1,
                padding: '11px',
                fontSize: 13,
                fontWeight: 800,
                background: '#16A34A',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6
              }}
            >
              <Play size={15} /> Iniciar Cronômetro Agora
            </button>

            {isRadarTimerRunning && (
              <button
                type="button"
                onClick={() => {
                  window.AndroidNative?.stopManualRadarTimer?.();
                  setIsRadarTimerRunning(false);
                }}
                style={{
                  padding: '11px 16px',
                  fontSize: 13,
                  fontWeight: 800,
                  borderRadius: 10,
                  border: 'none',
                  background: '#DC2626',
                  color: '#FFF',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 4,
                  cursor: 'pointer'
                }}
              >
                <Square size={14} /> Parar
              </button>
            )}
          </div>
        </div>

        {/* Chaves Independentes: Opção 1, Opção 2 e Opção 3 */}
        <div className="card" style={{ padding: '14px', marginBottom: 10 }}>
          <div style={{ fontSize: 14, fontWeight: 800, color: '#1E293B', marginBottom: 10 }}>
            🎛️ Escolher Quando Ativar 1, 2 ou 3
          </div>

          {/* OPÇÃO 1 */}
          <div style={{
            background: radarOpt1Timer ? '#F0FDF4' : '#F8FAFC',
            border: `1px solid ${radarOpt1Timer ? '#86EFAC' : '#E2E8F0'}`,
            borderRadius: 10,
            padding: '10px 12px',
            marginBottom: 8
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ paddingRight: 10 }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: '#0F172A' }}>
                  1. Cronômetro Automático no Alerta
                </div>
                <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.3, marginTop: 2 }}>
                  Ao chegar notificação do Envios Extra (ex: Área Afastada), abre o cronômetro flutuante de {radarDurationMin} min na tela.
                </div>
              </div>
              <button
                type="button"
                onClick={() => setRadarOpt1Timer(!radarOpt1Timer)}
                style={{
                  minWidth: 68,
                  padding: '8px 10px',
                  borderRadius: 20,
                  border: 'none',
                  background: radarOpt1Timer ? '#16A34A' : '#CBD5E1',
                  color: radarOpt1Timer ? '#FFF' : '#475569',
                  fontWeight: 800,
                  fontSize: 12,
                  cursor: 'pointer'
                }}
              >
                {radarOpt1Timer ? 'ATIVO' : 'OFF'}
              </button>
            </div>

            {radarOpt1Timer && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8, paddingTop: 8, borderTop: '1px solid rgba(0,0,0,0.06)' }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: '#334155' }}>Duração:</span>
                {[5, 10, 12, 15].map(min => (
                  <button
                    key={min}
                    type="button"
                    onClick={() => setRadarDurationMin(min)}
                    style={{
                      padding: '4px 8px',
                      borderRadius: 6,
                      border: radarDurationMin === min ? '2px solid #15803D' : '1px solid #CBD5E1',
                      background: radarDurationMin === min ? '#DCFCE7' : '#FFF',
                      color: radarDurationMin === min ? '#166534' : '#475569',
                      fontWeight: 800,
                      fontSize: 11,
                      cursor: 'pointer'
                    }}
                  >
                    {min} min
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* OPÇÃO 2 */}
          <div style={{
            background: radarOpt2Pacer ? '#EFF6FF' : '#F8FAFC',
            border: `1px solid ${radarOpt2Pacer ? '#93C5FD' : '#E2E8F0'}`,
            borderRadius: 10,
            padding: '10px 12px',
            marginBottom: 8
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ paddingRight: 10 }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: '#0F172A' }}>
                  2. Vibrar/Bipe + Manter Tela Acesa
                </div>
                <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.3, marginTop: 2 }}>
                  Enquanto o cronômetro estiver rodando, mantém a tela acesa e avisa a cada {radarPacerSec}s para você puxar a lista manual.
                </div>
              </div>
              <button
                type="button"
                onClick={() => setRadarOpt2Pacer(!radarOpt2Pacer)}
                style={{
                  minWidth: 68,
                  padding: '8px 10px',
                  borderRadius: 20,
                  border: 'none',
                  background: radarOpt2Pacer ? '#2563EB' : '#CBD5E1',
                  color: radarOpt2Pacer ? '#FFF' : '#475569',
                  fontWeight: 800,
                  fontSize: 12,
                  cursor: 'pointer'
                }}
              >
                {radarOpt2Pacer ? 'ATIVO' : 'OFF'}
              </button>
            </div>

            {radarOpt2Pacer && (
              <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid rgba(0,0,0,0.06)', display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: '#334155' }}>Avisar a cada:</span>
                {[30, 45, 60].map(sec => (
                  <button
                    key={sec}
                    type="button"
                    onClick={() => setRadarPacerSec(sec)}
                    style={{
                      padding: '4px 8px',
                      borderRadius: 6,
                      border: radarPacerSec === sec ? '2px solid #1D4ED8' : '1px solid #CBD5E1',
                      background: radarPacerSec === sec ? '#DBEAFE' : '#FFF',
                      color: radarPacerSec === sec ? '#1E40AF' : '#475569',
                      fontWeight: 800,
                      fontSize: 11,
                      cursor: 'pointer'
                    }}
                  >
                    {sec}s
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setRadarPacerBeep(!radarPacerBeep)}
                  style={{
                    marginLeft: 'auto',
                    padding: '4px 8px',
                    borderRadius: 6,
                    border: '1px solid #CBD5E1',
                    background: radarPacerBeep ? '#FEF08A' : '#FFF',
                    color: '#0F172A',
                    fontWeight: 700,
                    fontSize: 11,
                    cursor: 'pointer'
                  }}
                >
                  {radarPacerBeep ? '🔊 Vibração + Bipe' : '📳 Só Vibração'}
                </button>
              </div>
            )}
          </div>

          {/* OPÇÃO 3 */}
          <div style={{
            background: radarOpt3Log ? '#FAF5FF' : '#F8FAFC',
            border: `1px solid ${radarOpt3Log ? '#D8B4FE' : '#E2E8F0'}`,
            borderRadius: 10,
            padding: '10px 12px'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ paddingRight: 10 }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: '#0F172A' }}>
                  3. Salvar Histórico de Horários
                </div>
                <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.3, marginTop: 2 }}>
                  Registra automaticamente hora, minuto, segundo, canal e texto de todas as notificações do Envios Extra.
                </div>
              </div>
              <button
                type="button"
                onClick={() => setRadarOpt3Log(!radarOpt3Log)}
                style={{
                  minWidth: 68,
                  padding: '8px 10px',
                  borderRadius: 20,
                  border: 'none',
                  background: radarOpt3Log ? '#7C3AED' : '#CBD5E1',
                  color: radarOpt3Log ? '#FFF' : '#475569',
                  fontWeight: 800,
                  fontSize: 12,
                  cursor: 'pointer'
                }}
              >
                {radarOpt3Log ? 'ATIVO' : 'OFF'}
              </button>
            </div>
          </div>
        </div>

        {/* Histórico de Horários Capturados (Opção 3) */}
        <div className="card" style={{ padding: '12px 14px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: 14, fontWeight: 800, color: '#1E293B', display: 'flex', alignItems: 'center', gap: 6 }}>
              <Bell size={15} color="#7C3AED" /> Histórico de Alertas ({radarLogs.length})
            </span>
            {radarLogs.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('Limpar histórico de horários capturados?')) {
                    window.AndroidNative?.clearRadarLogs?.();
                    setRadarLogs([]);
                    localStorage.removeItem('radar_batch_logs_cache');
                  }
                }}
                style={{ background: 'none', border: 'none', color: '#DC2626', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}
              >
                Limpar
              </button>
            )}
          </div>

          <div style={{ fontSize: 11, color: '#64748B', marginBottom: 10, background: '#F8FAFC', padding: '8px 10px', borderRadius: 8, border: '1px solid #E2E8F0' }}>
            💡 <strong>Ondas descobertas no seu log de Passo Fundo:</strong><br />
            <code>05:28</code> • <code>07:40</code> • <code>09:18</code> • <code>09:47</code> • <code>11:38</code> • <code>12:14</code> • <code>16:02</code> • <code>16:43</code>
          </div>

          {radarLogs.length === 0 ? (
            <p style={{ fontSize: 12, color: '#9CA3AF', textAlign: 'center', padding: '12px 0', margin: 0 }}>
              Nenhum alerta registrado ainda. Assim que o Envios Extra tocar, o horário exato ao segundo aparecerá aqui!
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {radarLogs.map((item) => (
                <div
                  key={item.id}
                  style={{
                    border: '1px solid #E2E8F0',
                    borderRadius: 8,
                    padding: '8px 10px',
                    background: '#F8FAFC'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 }}>
                    <span style={{ fontSize: 13, fontWeight: 900, color: '#1D4ED8', background: '#DBEAFE', padding: '2px 7px', borderRadius: 6 }}>
                      ⏰ {item.time}
                    </span>
                    <span style={{ fontSize: 10, fontWeight: 700, color: '#64748B' }}>
                      {item.date} • Canal {item.channel}
                    </span>
                  </div>
                  <div style={{ fontSize: 12, fontWeight: 800, color: '#1E293B' }}>
                    {item.title}
                  </div>
                  {item.text && (
                    <div style={{ fontSize: 11, color: '#475569', marginTop: 2 }}>
                      {item.text}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
