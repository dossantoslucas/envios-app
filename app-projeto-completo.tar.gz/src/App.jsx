import React, { useState, useEffect, useCallback } from 'react';
import { Bell, Clock, Play, Square, ShieldCheck, Plus, Trash2, AlarmClock } from 'lucide-react';

const DEFAULT_PASSO_FUNDO_ALARMS = [
  { id: 'pf-1', time: '05:27', label: 'Onda Madrugada (05:28)', enabled: false },
  { id: 'pf-2', time: '07:39', label: 'Onda Manhã 1 (07:40)', enabled: true },
  { id: 'pf-3', time: '09:17', label: 'Onda Manhã 2 (09:18)', enabled: true },
  { id: 'pf-4', time: '09:46', label: 'Onda Manhã 3 (09:47)', enabled: true },
  { id: 'pf-5', time: '11:37', label: 'Onda Almoço 1 (11:38)', enabled: true },
  { id: 'pf-6', time: '12:13', label: 'Onda Almoço 2 (12:14)', enabled: true },
  { id: 'pf-7', time: '16:01', label: 'Onda Tarde 1 (16:02)', enabled: true },
  { id: 'pf-8', time: '16:42', label: 'Onda Tarde 2 (16:43)', enabled: true }
];

export default function App() {
  const [radarOpt1Timer, setRadarOpt1Timer] = useState(() => localStorage.getItem('radar_opt1_timer') !== 'false');
  const [radarOpt2Pacer, setRadarOpt2Pacer] = useState(() => localStorage.getItem('radar_opt2_pacer') !== 'false');
  const [radarOpt3Log, setRadarOpt3Log] = useState(() => localStorage.getItem('radar_opt3_log') !== 'false');
  const [radarOpt4Alarms, setRadarOpt4Alarms] = useState(() => localStorage.getItem('radar_opt4_alarms') !== 'false');
  const [radarDurationMin, setRadarDurationMin] = useState(() => Number(localStorage.getItem('radar_duration_min')) || 10);
  const [radarPacerSec, setRadarPacerSec] = useState(() => Number(localStorage.getItem('radar_pacer_sec')) || 45);
  const [radarPacerBeep, setRadarPacerBeep] = useState(() => localStorage.getItem('radar_pacer_beep') !== 'false');

  // Lista de Alarmes Programados (Horários Fixos)
  const [scheduledAlarms, setScheduledAlarms] = useState(() => {
    try {
      const saved = localStorage.getItem('radar_scheduled_alarms');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (_) {}
    return DEFAULT_PASSO_FUNDO_ALARMS;
  });

  const [newAlarmTime, setNewAlarmTime] = useState('11:35');
  const [newAlarmLabel, setNewAlarmLabel] = useState('');

  const [isNotifListenerEnabled, setIsNotifListenerEnabled] = useState(false);
  const [isOverlayGranted, setIsOverlayGranted] = useState(false);
  const [isBatteryFree, setIsBatteryFree] = useState(true);
  const [isRadarTimerRunning, setIsRadarTimerRunning] = useState(false);
  const [radarLogs, setRadarLogs] = useState(() => {
    try {
      const saved = localStorage.getItem('radar_batch_logs_cache');
      return saved ? JSON.parse(saved) : [];
    } catch (_) {
      return [];
    }
  });

  const syncNativeState = useCallback(() => {
    if (window.AndroidNative) {
      if (typeof window.AndroidNative.isNotificationListenerEnabled === 'function') {
        try { setIsNotifListenerEnabled(Boolean(window.AndroidNative.isNotificationListenerEnabled())); } catch (_) {}
      }
      if (typeof window.AndroidNative.isOverlayPermissionGranted === 'function') {
        try { setIsOverlayGranted(Boolean(window.AndroidNative.isOverlayPermissionGranted())); } catch (_) {}
      }
      if (typeof window.AndroidNative.isBatteryUnrestricted === 'function') {
        try { setIsBatteryFree(Boolean(window.AndroidNative.isBatteryUnrestricted())); } catch (_) {}
      }
      if (typeof window.AndroidNative.getRadarConfig === 'function') {
        try {
          const cfgRaw = window.AndroidNative.getRadarConfig();
          if (cfgRaw) {
            const cfg = JSON.parse(cfgRaw);
            setIsRadarTimerRunning(Boolean(cfg.isRunning));
          }
        } catch (_) {}
      }
      if (typeof window.AndroidNative.getRadarLogs === 'function') {
        try {
          const logsRaw = window.AndroidNative.getRadarLogs();
          if (logsRaw) {
            const parsedLogs = JSON.parse(logsRaw);
            if (Array.isArray(parsedLogs)) {
              setRadarLogs(parsedLogs);
              localStorage.setItem('radar_batch_logs_cache', JSON.stringify(parsedLogs));
            }
          }
        } catch (_) {}
      }
    }
  }, []);

  useEffect(() => {
    syncNativeState();
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') syncNativeState();
    };
    window.addEventListener('focus', syncNativeState);
    document.addEventListener('visibilitychange', handleVisibility);
    const interval = setInterval(syncNativeState, 2000);
    return () => {
      window.removeEventListener('focus', syncNativeState);
      document.removeEventListener('visibilitychange', handleVisibility);
      clearInterval(interval);
    };
  }, [syncNativeState]);

  // Salvar configurações das chaves 1, 2, 3 e 4 no sistema Android
  useEffect(() => {
    localStorage.setItem('radar_opt1_timer', String(radarOpt1Timer));
    localStorage.setItem('radar_opt2_pacer', String(radarOpt2Pacer));
    localStorage.setItem('radar_opt3_log', String(radarOpt3Log));
    localStorage.setItem('radar_opt4_alarms', String(radarOpt4Alarms));
    localStorage.setItem('radar_duration_min', String(radarDurationMin));
    localStorage.setItem('radar_pacer_sec', String(radarPacerSec));
    localStorage.setItem('radar_pacer_beep', String(radarPacerBeep));

    if (window.AndroidNative && typeof window.AndroidNative.saveRadarConfig === 'function') {
      try {
        window.AndroidNative.saveRadarConfig(
          Boolean(radarOpt1Timer),
          Boolean(radarOpt2Pacer),
          Boolean(radarOpt3Log),
          Boolean(radarOpt4Alarms),
          Number(radarDurationMin) || 10,
          Number(radarPacerSec) || 45,
          Boolean(radarPacerBeep)
        );
      } catch (e) {
        console.error('Erro ao salvar config do radar:', e);
      }
    }
  }, [radarOpt1Timer, radarOpt2Pacer, radarOpt3Log, radarOpt4Alarms, radarDurationMin, radarPacerSec, radarPacerBeep]);

  // Salvar e agendar alarmes no AlarmManager do Android sempre que a lista mudar
  useEffect(() => {
    const jsonStr = JSON.stringify(scheduledAlarms);
    localStorage.setItem('radar_scheduled_alarms', jsonStr);
    if (window.AndroidNative && typeof window.AndroidNative.saveScheduledAlarms === 'function') {
      try {
        window.AndroidNative.saveScheduledAlarms(jsonStr);
      } catch (e) {
        console.error('Erro ao agendar alarmes no Android:', e);
      }
    }
  }, [scheduledAlarms]);

  const handleAddAlarm = (e) => {
    e.preventDefault();
    if (!newAlarmTime) return;
    const item = {
      id: 'alm-' + Date.now(),
      time: newAlarmTime,
      label: newAlarmLabel.trim() || `Horário Programado (${newAlarmTime})`,
      enabled: true
    };
    const next = [...scheduledAlarms, item].sort((a, b) => a.time.localeCompare(b.time));
    setScheduledAlarms(next);
    setNewAlarmLabel('');
  };

  const toggleAlarmItem = (id) => {
    setScheduledAlarms(prev =>
      prev.map(item => (item.id === id ? { ...item, enabled: !item.enabled } : item))
    );
  };

  const deleteAlarmItem = (id) => {
    setScheduledAlarms(prev => prev.filter(item => item.id !== id));
  };

  return (
    <div className="app-container">
      {/* Barra Superior */}
      <header className="top-bar" style={{ background: '#0F172A' }}>
        <div className="top-bar-title" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Clock size={18} color="#4ADE80" />
          <span>Radar de Lotes</span>
        </div>
        <div style={{
          fontSize: 11,
          fontWeight: 800,
          padding: '4px 10px',
          borderRadius: 20,
          background: isNotifListenerEnabled && isOverlayGranted ? '#166534' : '#B45309',
          color: '#FFF',
          display: 'flex',
          alignItems: 'center',
          gap: 4
        }}>
          <ShieldCheck size={13} />
          {isNotifListenerEnabled && isOverlayGranted ? 'Radar Pronto' : 'Configurar'}
        </div>
      </header>

      <main className="content-body" style={{ paddingTop: 12 }}>
        {/* Permissões */}
        {(!isNotifListenerEnabled || !isOverlayGranted || !isBatteryFree) && (
          <div className="card" style={{ padding: '12px 14px', marginBottom: 10, background: '#FFFBEB', border: '1px solid #FDE68A' }}>
            <div style={{ fontSize: 13, fontWeight: 800, color: '#92400E', marginBottom: 8 }}>
              ⚙️ Ative as permissões para o Radar funcionar em 2º plano:
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {!isNotifListenerEnabled && (
                <button
                  type="button"
                  onClick={() => window.AndroidNative?.openNotificationListenerSettings?.()}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    borderRadius: 8,
                    border: 'none',
                    background: '#D97706',
                    color: '#FFF',
                    fontWeight: 800,
                    fontSize: 12,
                    cursor: 'pointer'
                  }}
                >
                  1. Autorizar Leitura de Notificações (Detectar Lote)
                </button>
              )}
              {!isOverlayGranted && (
                <button
                  type="button"
                  onClick={() => window.AndroidNative?.openOverlayPermissionSettings?.()}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    borderRadius: 8,
                    border: 'none',
                    background: '#2563EB',
                    color: '#FFF',
                    fontWeight: 800,
                    fontSize: 12,
                    cursor: 'pointer'
                  }}
                >
                  2. Autorizar Sobrepor a Outros Apps (Cronômetro Flutuante)
                </button>
              )}
              {!isBatteryFree && (
                <button
                  type="button"
                  onClick={() => window.AndroidNative?.requestUnrestrictedBattery?.()}
                  style={{
                    width: '100%',
                    padding: '9px 12px',
                    borderRadius: 8,
                    border: '1px solid #F59E0B',
                    background: '#FEF3C7',
                    color: '#92400E',
                    fontWeight: 800,
                    fontSize: 12,
                    cursor: 'pointer'
                  }}
                >
                  ⚡ 3. Liberar Bateria em 2º Plano (Sem Restrições)
                </button>
              )}
            </div>
          </div>
        )}

        {/* Controle Manual do Cronômetro Flutuante */}
        <div className="card" style={{ padding: '12px 14px', marginBottom: 10 }}>
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 14, fontWeight: 800, color: '#1E293B' }}>
              🟢 Cronômetro Flutuante ({radarDurationMin} min)
            </div>
            <div style={{ fontSize: 11, color: '#64748B', marginTop: 2 }}>
              {isRadarTimerRunning
                ? 'Cronômetro ativo na tela! Você pode arrastar a pílula com o dedo.'
                : 'Abre sozinho por notificação, nos horários agendados ou manualmente abaixo:'}
            </div>
          </div>

          <div style={{ display: 'flex', gap: 8 }}>
            <button
              type="button"
              onClick={() => {
                if (window.AndroidNative && typeof window.AndroidNative.startManualRadarTimer === 'function') {
                  if (!isOverlayGranted && typeof window.AndroidNative.openOverlayPermissionSettings === 'function') {
                    window.AndroidNative.openOverlayPermissionSettings();
                    return;
                  }
                  window.AndroidNative.startManualRadarTimer('Janela Manual (' + radarDurationMin + ' min)');
                  setIsRadarTimerRunning(true);
                }
              }}
              className="btn-primary"
              style={{
                flex: 1,
                padding: '11px',
                fontSize: 13,
                fontWeight: 800,
                background: '#16A34A',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6
              }}
            >
              <Play size={15} /> Iniciar Cronômetro Agora
            </button>

            {isRadarTimerRunning && (
              <button
                type="button"
                onClick={() => {
                  window.AndroidNative?.stopManualRadarTimer?.();
                  setIsRadarTimerRunning(false);
                }}
                style={{
                  padding: '11px 16px',
                  fontSize: 13,
                  fontWeight: 800,
                  borderRadius: 10,
                  border: 'none',
                  background: '#DC2626',
                  color: '#FFF',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 4,
                  cursor: 'pointer'
                }}
              >
                <Square size={14} /> Parar
              </button>
            )}
          </div>
        </div>

        {/* ================================================================= */}
        {/* SEÇÃO NOVA: ALARMES DE HORÁRIO FIXO (DISPARA O CRONÔMETRO SOZINHO) */}
        {/* ================================================================= */}
        <div className="card" style={{ padding: '14px', marginBottom: 10, border: radarOpt4Alarms ? '2px solid #F59E0B' : '1px solid #E2E8F0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <AlarmClock size={18} color="#D97706" />
              <div>
                <div style={{ fontSize: 14, fontWeight: 800, color: '#1E293B' }}>
                  ⏰ Disparar Cronômetro por Horário
                </div>
                <div style={{ fontSize: 11, color: '#64748B' }}>
                  Abre o cronômetro sozinho na tela nos horários abaixo (além das notificações)
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setRadarOpt4Alarms(!radarOpt4Alarms)}
              style={{
                minWidth: 68,
                padding: '8px 10px',
                borderRadius: 20,
                border: 'none',
                background: radarOpt4Alarms ? '#D97706' : '#CBD5E1',
                color: radarOpt4Alarms ? '#FFF' : '#475569',
                fontWeight: 800,
                fontSize: 12,
                cursor: 'pointer'
              }}
            >
              {radarOpt4Alarms ? 'ATIVO' : 'OFF'}
            </button>
          </div>

          {radarOpt4Alarms && (
            <div>
              {/* Formulário para Adicionar Novo Horário */}
              <form onSubmit={handleAddAlarm} style={{ display: 'flex', gap: 6, marginBottom: 10, background: '#FFFBEB', padding: '8px', borderRadius: 10, border: '1px solid #FDE68A' }}>
                <input
                  type="time"
                  value={newAlarmTime}
                  onChange={e => setNewAlarmTime(e.target.value)}
                  required
                  style={{
                    padding: '8px',
                    borderRadius: 8,
                    border: '1px solid #CBD5E1',
                    fontSize: 14,
                    fontWeight: 800,
                    color: '#0F172A',
                    background: '#FFF'
                  }}
                />
                <input
                  type="text"
                  placeholder="Nome (ex: Lote 11:38)"
                  value={newAlarmLabel}
                  onChange={e => setNewAlarmLabel(e.target.value)}
                  style={{
                    flex: 1,
                    minWidth: 0,
                    padding: '8px 10px',
                    borderRadius: 8,
                    border: '1px solid #CBD5E1',
                    fontSize: 12,
                    background: '#FFF'
                  }}
                />
                <button
                  type="submit"
                  style={{
                    padding: '8px 12px',
                    borderRadius: 8,
                    border: 'none',
                    background: '#D97706',
                    color: '#FFF',
                    fontWeight: 800,
                    fontSize: 12,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 4,
                    cursor: 'pointer'
                  }}
                >
                  <Plus size={15} /> Add
                </button>
              </form>

              {/* Lista de Horários Agendados */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {scheduledAlarms.map((alm) => (
                  <div
                    key={alm.id}
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: '8px 10px',
                      borderRadius: 8,
                      background: alm.enabled ? '#FFFBEB' : '#F8FAFC',
                      border: `1px solid ${alm.enabled ? '#FCD34D' : '#E2E8F0'}`
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span style={{
                        fontSize: 16,
                        fontWeight: 900,
                        color: alm.enabled ? '#B45309' : '#94A3B8',
                        fontFamily: 'monospace'
                      }}>
                        {alm.time}
                      </span>
                      <span style={{
                        fontSize: 12,
                        fontWeight: 700,
                        color: alm.enabled ? '#1E293B' : '#94A3B8'
                      }}>
                        {alm.label}
                      </span>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <button
                        type="button"
                        onClick={() => toggleAlarmItem(alm.id)}
                        style={{
                          padding: '5px 10px',
                          borderRadius: 14,
                          border: 'none',
                          background: alm.enabled ? '#16A34A' : '#CBD5E1',
                          color: alm.enabled ? '#FFF' : '#475569',
                          fontWeight: 800,
                          fontSize: 11,
                          cursor: 'pointer'
                        }}
                      >
                        {alm.enabled ? 'ON' : 'OFF'}
                      </button>
                      <button
                        type="button"
                        onClick={() => deleteAlarmItem(alm.id)}
                        style={{
                          background: 'none',
                          border: 'none',
                          color: '#94A3B8',
                          padding: 4,
                          cursor: 'pointer'
                        }}
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Chaves Independentes: Opção 1, Opção 2 e Opção 3 */}
        <div className="card" style={{ padding: '14px', marginBottom: 10 }}>
          <div style={{ fontSize: 14, fontWeight: 800, color: '#1E293B', marginBottom: 10 }}>
            🎛️ Escolher Quando Ativar 1, 2 ou 3
          </div>

          {/* OPÇÃO 1 */}
          <div style={{
            background: radarOpt1Timer ? '#F0FDF4' : '#F8FAFC',
            border: `1px solid ${radarOpt1Timer ? '#86EFAC' : '#E2E8F0'}`,
            borderRadius: 10,
            padding: '10px 12px',
            marginBottom: 8
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ paddingRight: 10 }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: '#0F172A' }}>
                  1. Cronômetro Automático na Notificação
                </div>
                <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.3, marginTop: 2 }}>
                  Ao chegar notificação do Envios Extra (ex: Área Afastada), abre o cronômetro flutuante de {radarDurationMin} min na tela.
                </div>
              </div>
              <button
                type="button"
                onClick={() => setRadarOpt1Timer(!radarOpt1Timer)}
                style={{
                  minWidth: 68,
                  padding: '8px 10px',
                  borderRadius: 20,
                  border: 'none',
                  background: radarOpt1Timer ? '#16A34A' : '#CBD5E1',
                  color: radarOpt1Timer ? '#FFF' : '#475569',
                  fontWeight: 800,
                  fontSize: 12,
                  cursor: 'pointer'
                }}
              >
                {radarOpt1Timer ? 'ATIVO' : 'OFF'}
              </button>
            </div>

            {radarOpt1Timer && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8, paddingTop: 8, borderTop: '1px solid rgba(0,0,0,0.06)' }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: '#334155' }}>Duração:</span>
                {[5, 10, 12, 15].map(min => (
                  <button
                    key={min}
                    type="button"
                    onClick={() => setRadarDurationMin(min)}
                    style={{
                      padding: '4px 8px',
                      borderRadius: 6,
                      border: radarDurationMin === min ? '2px solid #15803D' : '1px solid #CBD5E1',
                      background: radarDurationMin === min ? '#DCFCE7' : '#FFF',
                      color: radarDurationMin === min ? '#166534' : '#475569',
                      fontWeight: 800,
                      fontSize: 11,
                      cursor: 'pointer'
                    }}
                  >
                    {min} min
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* OPÇÃO 2 */}
          <div style={{
            background: radarOpt2Pacer ? '#EFF6FF' : '#F8FAFC',
            border: `1px solid ${radarOpt2Pacer ? '#93C5FD' : '#E2E8F0'}`,
            borderRadius: 10,
            padding: '10px 12px',
            marginBottom: 8
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ paddingRight: 10 }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: '#0F172A' }}>
                  2. Vibrar/Bipe + Manter Tela Acesa
                </div>
                <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.3, marginTop: 2 }}>
                  Enquanto o cronômetro estiver rodando, mantém a tela acesa e avisa a cada {radarPacerSec}s para você puxar a lista manual.
                </div>
              </div>
              <button
                type="button"
                onClick={() => setRadarOpt2Pacer(!radarOpt2Pacer)}
                style={{
                  minWidth: 68,
                  padding: '8px 10px',
                  borderRadius: 20,
                  border: 'none',
                  background: radarOpt2Pacer ? '#2563EB' : '#CBD5E1',
                  color: radarOpt2Pacer ? '#FFF' : '#475569',
                  fontWeight: 800,
                  fontSize: 12,
                  cursor: 'pointer'
                }}
              >
                {radarOpt2Pacer ? 'ATIVO' : 'OFF'}
              </button>
            </div>

            {radarOpt2Pacer && (
              <div style={{ marginTop: 8, paddingTop: 8, borderTop: '1px solid rgba(0,0,0,0.06)', display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: '#334155' }}>Avisar a cada:</span>
                {[30, 45, 60].map(sec => (
                  <button
                    key={sec}
                    type="button"
                    onClick={() => setRadarPacerSec(sec)}
                    style={{
                      padding: '4px 8px',
                      borderRadius: 6,
                      border: radarPacerSec === sec ? '2px solid #1D4ED8' : '1px solid #CBD5E1',
                      background: radarPacerSec === sec ? '#DBEAFE' : '#FFF',
                      color: radarPacerSec === sec ? '#1E40AF' : '#475569',
                      fontWeight: 800,
                      fontSize: 11,
                      cursor: 'pointer'
                    }}
                  >
                    {sec}s
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setRadarPacerBeep(!radarPacerBeep)}
                  style={{
                    marginLeft: 'auto',
                    padding: '4px 8px',
                    borderRadius: 6,
                    border: '1px solid #CBD5E1',
                    background: radarPacerBeep ? '#FEF08A' : '#FFF',
                    color: '#0F172A',
                    fontWeight: 700,
                    fontSize: 11,
                    cursor: 'pointer'
                  }}
                >
                  {radarPacerBeep ? '🔊 Vibração + Bipe' : '📳 Só Vibração'}
                </button>
              </div>
            )}
          </div>

          {/* OPÇÃO 3 */}
          <div style={{
            background: radarOpt3Log ? '#FAF5FF' : '#F8FAFC',
            border: `1px solid ${radarOpt3Log ? '#D8B4FE' : '#E2E8F0'}`,
            borderRadius: 10,
            padding: '10px 12px'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ paddingRight: 10 }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: '#0F172A' }}>
                  3. Salvar Histórico de Horários
                </div>
                <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.3, marginTop: 2 }}>
                  Registra automaticamente hora, minuto, segundo, canal e texto de todas as notificações do Envios Extra.
                </div>
              </div>
              <button
                type="button"
                onClick={() => setRadarOpt3Log(!radarOpt3Log)}
                style={{
                  minWidth: 68,
                  padding: '8px 10px',
                  borderRadius: 20,
                  border: 'none',
                  background: radarOpt3Log ? '#7C3AED' : '#CBD5E1',
                  color: radarOpt3Log ? '#FFF' : '#475569',
                  fontWeight: 800,
                  fontSize: 12,
                  cursor: 'pointer'
                }}
              >
                {radarOpt3Log ? 'ATIVO' : 'OFF'}
              </button>
            </div>
          </div>
        </div>

        {/* Histórico de Horários Capturados (Opção 3) */}
        <div className="card" style={{ padding: '12px 14px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: 14, fontWeight: 800, color: '#1E293B', display: 'flex', alignItems: 'center', gap: 6 }}>
              <Bell size={15} color="#7C3AED" /> Histórico de Alertas ({radarLogs.length})
            </span>
            {radarLogs.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  if (window.confirm('Limpar histórico de horários capturados?')) {
                    window.AndroidNative?.clearRadarLogs?.();
                    setRadarLogs([]);
                    localStorage.removeItem('radar_batch_logs_cache');
                  }
                }}
                style={{ background: 'none', border: 'none', color: '#DC2626', fontSize: 11, fontWeight: 700, cursor: 'pointer' }}
              >
                Limpar
              </button>
            )}
          </div>

          {radarLogs.length === 0 ? (
            <p style={{ fontSize: 12, color: '#9CA3AF', textAlign: 'center', padding: '12px 0', margin: 0 }}>
              Nenhum alerta registrado ainda. Assim que o Envios Extra tocar, o horário exato ao segundo aparecerá aqui!
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {radarLogs.map((item) => (
                <div
                  key={item.id}
                  style={{
                    border: '1px solid #E2E8F0',
                    borderRadius: 8,
                    padding: '8px 10px',
                    background: '#F8FAFC'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 }}>
                    <span style={{ fontSize: 13, fontWeight: 900, color: '#1D4ED8', background: '#DBEAFE', padding: '2px 7px', borderRadius: 6 }}>
                      ⏰ {item.time}
                    </span>
                    <span style={{ fontSize: 10, fontWeight: 700, color: '#64748B' }}>
                      {item.date} • Canal {item.channel}
                    </span>
                  </div>
                  <div style={{ fontSize: 12, fontWeight: 800, color: '#1E293B' }}>
                    {item.title}
                  </div>
                  {item.text && (
                    <div style={{ fontSize: 11, color: '#475569', marginTop: 2 }}>
                      {item.text}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
