// Regras oficiais do Mercado Envios Extra
export const LEVEL_CRITERIA = {
  PLATINUM: {
    key: 'PLATINUM',
    name: 'Platinum',
    minPoints: 1700,
    minSuccessRate: 98.0,
    minNoComplaintRate: 99.70,
    badgeClass: 'badge-platinum',
    color: '#2D3748'
  },
  GOLD: {
    key: 'GOLD',
    name: 'Ouro',
    minPoints: 900,
    minSuccessRate: 97.0,
    minNoComplaintRate: 99.60,
    badgeClass: 'badge-gold',
    color: '#D4AF37'
  },
  SILVER: {
    key: 'SILVER',
    name: 'Prata',
    minPoints: 300,
    minSuccessRate: 96.0,
    minNoComplaintRate: 99.50,
    badgeClass: 'badge-silver',
    color: '#8A9BA8'
  },
  BRONZE: {
    key: 'BRONZE',
    name: 'Bronze',
    minPoints: 0,
    minSuccessRate: 0.0,
    minNoComplaintRate: 0.0,
    badgeClass: 'badge-bronze',
    color: '#CD7F32'
  }
};

export function determineLevel(points, successRate, noComplaintRate) {
  const p = Number(points) || 0;
  const s = Number(successRate) || 0;
  const c = Number(noComplaintRate) || 0;

  if (p >= LEVEL_CRITERIA.PLATINUM.minPoints &&
      s >= LEVEL_CRITERIA.PLATINUM.minSuccessRate &&
      c >= LEVEL_CRITERIA.PLATINUM.minNoComplaintRate) {
    return LEVEL_CRITERIA.PLATINUM;
  }
  if (p >= LEVEL_CRITERIA.GOLD.minPoints &&
      s >= LEVEL_CRITERIA.GOLD.minSuccessRate &&
      c >= LEVEL_CRITERIA.GOLD.minNoComplaintRate) {
    return LEVEL_CRITERIA.GOLD;
  }
  if (p >= LEVEL_CRITERIA.SILVER.minPoints &&
      s >= LEVEL_CRITERIA.SILVER.minSuccessRate &&
      c >= LEVEL_CRITERIA.SILVER.minNoComplaintRate) {
    return LEVEL_CRITERIA.SILVER;
  }
  return LEVEL_CRITERIA.BRONZE;
}

/**
 * Comparação exata e conservadora:
 * O entregador precisa de um número cravado, seguro e direto.
 */
export function compareWithLevelTarget(totalPackages, userPoints, userSuccessRate, userNoComplaintRate, targetKey = 'PLATINUM') {
  const total = Math.max(0, Number(totalPackages) || 0);
  const points = Math.max(0, Number(userPoints) || 0);
  const successRate = Math.min(100, Math.max(0, Number(userSuccessRate) || 0));
  const noComplaintRate = Math.min(100, Math.max(0, Number(userNoComplaintRate) || 0));

  const target = LEVEL_CRITERIA[targetKey] || LEVEL_CRITERIA.PLATINUM;

  // 1. PONTOS
  const pointsDiff = points - target.minPoints;
  const pointsStatus = {
    current: points,
    target: target.minPoints,
    reached: pointsDiff >= 0,
    diff: Math.abs(pointsDiff),
    message: pointsDiff >= 0 
      ? `Meta atingida (+${pointsDiff} pts acima do mínimo)`
      : `Faltam ${Math.abs(pointsDiff)} pontos para atingir ${target.name}`
  };

  // 2. FALHAS DE ENTREGA
  const deliveredSuccessCount = total > 0 ? Math.round(total * (successRate / 100)) : 0;
  const deliveredFailedCount = Math.max(0, total - deliveredSuccessCount);
  const targetSuccessPct = target.minSuccessRate;
  const successReached = successRate >= targetSuccessPct;

  let canFailMargin = 0;
  let neededConsecutiveSuccess = 0;
  let maxAllowedFailures = 0;

  if (targetSuccessPct > 0) {
    // Teto máximo de falhas que o total de pacotes suporta para manter >= targetSuccessPct:
    // Ex: a 98% (Platinum) em 1.930 pacotes -> maxAllowed = floor(1930 * 0.02) = 38 falhas no total
    maxAllowedFailures = Math.floor(total * ((100 - targetSuccessPct) / 100) + 0.00001);

    if (successReached) {
      // (deliveredSuccessCount) / (total + X) >= targetSuccessPct / 100
      const maxAllowedTotal = deliveredSuccessCount / (targetSuccessPct / 100);
      canFailMargin = Math.max(0, Math.floor(maxAllowedTotal - total));
    } else {
      const targetFrac = targetSuccessPct / 100;
      neededConsecutiveSuccess = Math.max(1, Math.ceil(((targetFrac * total) - deliveredSuccessCount) / (1 - targetFrac)));
    }
  } else {
    maxAllowedFailures = total;
    canFailMargin = total;
  }

  // 3. RECLAMAÇÕES (ARREDONDAMENTO CONSERVADOR E CRAVADO)
  // Taxa de queixa = 100% - % sem queixa
  // Ex: 100% - 99.81% = 0.19%
  const complaintCount = total > 0 ? Math.round(total * ((100 - noComplaintRate) / 100)) : 0;
  const targetComplaintPct = target.minNoComplaintRate;
  const complaintReached = noComplaintRate >= targetComplaintPct;

  // Teto máximo de reclamações que mantém a taxa >= targetComplaintPct
  // Ex: 1.930 pacotes a 99.70% -> max = floor(1930 * 0.003) = 5 reclamações
  const maxAllowedComplaints = targetComplaintPct > 0 
    ? Math.floor(total * ((100 - targetComplaintPct) / 100) + 0.00001)
    : 9999;

  // Margem restante cravada e segura (ex: se teve 4 e o max é 5, resta exatamente 1)
  const allowedAdditionalComplaints = Math.max(0, maxAllowedComplaints - complaintCount);

  // 4. CÁLCULO DE EXPANSÃO: Quantos pacotes perfeitos precisa entregar para "desbloquear" +1 margem?
  // Para +1 falha a 98% (Platinum): precisa de 49 entregas com sucesso consecutivas (50 no total).
  // Formula geral: ceil(1 / (1 - (targetSuccessPct / 100))) - 1
  let packagesForOneMoreFailure = 0;
  if (targetSuccessPct > 0 && targetSuccessPct < 100) {
    const fraction = targetSuccessPct / 100;
    packagesForOneMoreFailure = Math.ceil(fraction / (1 - fraction));
  }

  // Para +1 reclamação a 99.70% (Platinum):
  // Formula: ceil(1 / (1 - (targetComplaintPct / 100)))
  let packagesForOneMoreComplaint = 0;
  if (targetComplaintPct > 0 && targetComplaintPct < 100) {
    const complaintFraction = (100 - targetComplaintPct) / 100;
    // Quantos pacotes precisa para o floor aumentar em +1 a partir do total atual
    const nextMilestone = (maxAllowedComplaints + 1) / complaintFraction;
    packagesForOneMoreComplaint = Math.max(1, Math.ceil(nextMilestone - total));
  }

  const allReached = pointsStatus.reached && successReached && (targetComplaintPct === 0 || complaintReached);

  return {
    target,
    allReached,
    total,
    pointsStatus,
    successAnalysis: {
      currentRate: successRate,
      targetRate: targetSuccessPct,
      reached: successReached,
      deliveredSuccessCount,
      deliveredFailedCount,
      maxAllowedFailures,
      marginPacotes: canFailMargin,
      neededConsecutiveSuccess,
      packagesForOneMoreFailure
    },
    complaintAnalysis: {
      currentRate: noComplaintRate,
      targetRate: targetComplaintPct,
      reached: complaintReached,
      complaintCount,
      maxAllowedComplaints,
      allowedAdditionalComplaints,
      packagesForOneMoreComplaint
    }
  };
}
