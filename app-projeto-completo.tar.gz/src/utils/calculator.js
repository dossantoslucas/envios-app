// Regras oficiais do Mercado Envios Extra
export const LEVEL_CRITERIA = {
  PLATINUM: {
    key: 'PLATINUM',
    name: 'Platinum',
    minPoints: 1700,
    minSuccessRate: 98.0,
    minNoComplaintRate: 99.70,
    badgeClass: 'badge-platinum',
    color: '#2D3748'
  },
  GOLD: {
    key: 'GOLD',
    name: 'Ouro',
    minPoints: 900,
    minSuccessRate: 97.0,
    minNoComplaintRate: 99.60,
    badgeClass: 'badge-gold',
    color: '#D4AF37'
  },
  SILVER: {
    key: 'SILVER',
    name: 'Prata',
    minPoints: 300,
    minSuccessRate: 96.0,
    minNoComplaintRate: 99.50,
    badgeClass: 'badge-silver',
    color: '#8A9BA8'
  },
  BRONZE: {
    key: 'BRONZE',
    name: 'Bronze',
    minPoints: 0,
    minSuccessRate: 0.0,
    minNoComplaintRate: 0.0,
    badgeClass: 'badge-bronze',
    color: '#CD7F32'
  }
};

export function determineLevel(points, successRate, noComplaintRate) {
  const p = Number(points) || 0;
  const s = Number(successRate) || 0;
  const c = Number(noComplaintRate) || 0;

  if (p >= LEVEL_CRITERIA.PLATINUM.minPoints &&
      s >= LEVEL_CRITERIA.PLATINUM.minSuccessRate &&
      c >= LEVEL_CRITERIA.PLATINUM.minNoComplaintRate) {
    return LEVEL_CRITERIA.PLATINUM;
  }
  if (p >= LEVEL_CRITERIA.GOLD.minPoints &&
      s >= LEVEL_CRITERIA.GOLD.minSuccessRate &&
      c >= LEVEL_CRITERIA.GOLD.minNoComplaintRate) {
    return LEVEL_CRITERIA.GOLD;
  }
  if (p >= LEVEL_CRITERIA.SILVER.minPoints &&
      s >= LEVEL_CRITERIA.SILVER.minSuccessRate &&
      c >= LEVEL_CRITERIA.SILVER.minNoComplaintRate) {
    return LEVEL_CRITERIA.SILVER;
  }
  return LEVEL_CRITERIA.BRONZE;
}

/**
 * Comparação exata e dinâmica baseada no total de pacotes do mês e nos dados do print.
 */
export function compareWithLevelTarget(totalPackages, userPoints, userSuccessRate, userNoComplaintRate, targetKey = 'PLATINUM') {
  const total = Math.max(0, Number(totalPackages) || 0);
  const points = Math.max(0, Number(userPoints) || 0);
  const successRate = Math.min(100, Math.max(0, Number(userSuccessRate) || 0));
  const noComplaintRate = Math.min(100, Math.max(0, Number(userNoComplaintRate) || 0));

  const target = LEVEL_CRITERIA[targetKey] || LEVEL_CRITERIA.PLATINUM;

  // 1. PONTOS
  const pointsDiff = points - target.minPoints;
  const pointsStatus = {
    current: points,
    target: target.minPoints,
    reached: pointsDiff >= 0,
    diff: Math.abs(pointsDiff),
    message: pointsDiff >= 0 
      ? `Meta atingida (+${pointsDiff} pts acima do mínimo)`
      : `Faltam ${Math.abs(pointsDiff)} pontos para atingir ${target.name}`
  };

  // 2. FALHAS DE ENTREGA
  const deliveredSuccessCount = total > 0 ? Math.round(total * (successRate / 100)) : 0;
  const deliveredFailedCount = Math.max(0, total - deliveredSuccessCount);
  const targetSuccessPct = target.minSuccessRate;
  const successReached = successRate >= targetSuccessPct;

  let canFailMargin = 0;
  let neededConsecutiveSuccess = 0;
  let maxAllowedFailures = 0;
  let packagesForOneMoreFailure = 0;

  if (targetSuccessPct > 0 && targetSuccessPct < 100) {
    const failureFraction = (100 - targetSuccessPct) / 100;
    // Teto máximo de falhas que o total atual de pacotes suporta
    // Ex: 176 pacotes no Platinum (2% máx de falha) -> floor(176 * 0.02) = 3 falhas
    maxAllowedFailures = Math.floor(total * failureFraction + 0.00001);

    if (successReached) {
      canFailMargin = Math.max(0, maxAllowedFailures - deliveredFailedCount);
    } else {
      const targetFrac = targetSuccessPct / 100;
      neededConsecutiveSuccess = Math.max(1, Math.ceil(((targetFrac * total) - deliveredSuccessCount) / (1 - targetFrac)));
    }

    // Quantos pacotes faltam a partir do total atual para o limite de falhas subir em +1
    // Ex: 176 pacotes (limite atual = 3, próximo marco = 200) -> faltam 24 pacotes para liberar +1 falha
    const nextFailureMilestone = Math.ceil((maxAllowedFailures + 1) / failureFraction - 0.00001);
    packagesForOneMoreFailure = Math.max(1, nextFailureMilestone - total);
  } else {
    maxAllowedFailures = total;
    canFailMargin = total;
    packagesForOneMoreFailure = 0;
  }

  // 3. RECLAMAÇÕES
  const complaintCount = total > 0 ? Math.round(total * ((100 - noComplaintRate) / 100)) : 0;
  const targetComplaintPct = target.minNoComplaintRate;
  const complaintReached = noComplaintRate >= targetComplaintPct;

  let maxAllowedComplaints = 9999;
  let allowedAdditionalComplaints = 0;
  let packagesForOneMoreComplaint = 0;

  if (targetComplaintPct > 0 && targetComplaintPct < 100) {
    const complaintFraction = (100 - targetComplaintPct) / 100;
    // Teto máximo de reclamações que mantém a taxa >= targetComplaintPct
    // Ex: 176 pacotes no Platinum (0.3% máx) -> floor(176 * 0.003) = 0 reclamações
    maxAllowedComplaints = Math.floor(total * complaintFraction + 0.00001);
    allowedAdditionalComplaints = Math.max(0, maxAllowedComplaints - complaintCount);

    // Quantos pacotes faltam a partir do total atual para liberar +1 queixa
    // Ex: no Platinum o 1º marco é 334 pacotes. Se já tem 176, faltam 334 - 176 = 158 pacotes
    const nextComplaintMilestone = Math.ceil((maxAllowedComplaints + 1) / complaintFraction - 0.00001);
    packagesForOneMoreComplaint = Math.max(1, nextComplaintMilestone - total);
  }

  const allReached = pointsStatus.reached && successReached && (targetComplaintPct === 0 || complaintReached);

  return {
    target,
    allReached,
    total,
    pointsStatus,
    successAnalysis: {
      currentRate: successRate,
      targetRate: targetSuccessPct,
      reached: successReached,
      deliveredSuccessCount,
      deliveredFailedCount,
      maxAllowedFailures,
      marginPacotes: canFailMargin,
      neededConsecutiveSuccess,
      packagesForOneMoreFailure
    },
    complaintAnalysis: {
      currentRate: noComplaintRate,
      targetRate: targetComplaintPct,
      reached: complaintReached,
      complaintCount,
      maxAllowedComplaints,
      allowedAdditionalComplaints,
      packagesForOneMoreComplaint
    }
  };
}
