// Regras oficiais do Mercado Envios Extra
export const LEVEL_CRITERIA = {
  PLATINUM: {
    key: 'PLATINUM',
    name: 'Platinum',
    minPoints: 1700,
    minSuccessRate: 98.0,
    minNoComplaintRate: 99.70,
    badgeClass: 'badge-platinum',
    color: '#2D3748'
  },
  GOLD: {
    key: 'GOLD',
    name: 'Ouro',
    minPoints: 900,
    minSuccessRate: 97.0,
    minNoComplaintRate: 99.60,
    badgeClass: 'badge-gold',
    color: '#D4AF37'
  },
  SILVER: {
    key: 'SILVER',
    name: 'Prata',
    minPoints: 300,
    minSuccessRate: 96.0,
    minNoComplaintRate: 99.50,
    badgeClass: 'badge-silver',
    color: '#8A9BA8'
  },
  BRONZE: {
    key: 'BRONZE',
    name: 'Bronze',
    minPoints: 0,
    minSuccessRate: 0.0,
    minNoComplaintRate: 0.0,
    badgeClass: 'badge-bronze',
    color: '#CD7F32'
  }
};

export function determineLevel(points, successRate, noComplaintRate) {
  const p = Number(points) || 0;
  const s = Number(successRate) || 0;
  const c = Number(noComplaintRate) || 0;

  if (p >= LEVEL_CRITERIA.PLATINUM.minPoints &&
      s >= LEVEL_CRITERIA.PLATINUM.minSuccessRate &&
      c >= LEVEL_CRITERIA.PLATINUM.minNoComplaintRate) {
    return LEVEL_CRITERIA.PLATINUM;
  }
  if (p >= LEVEL_CRITERIA.GOLD.minPoints &&
      s >= LEVEL_CRITERIA.GOLD.minSuccessRate &&
      c >= LEVEL_CRITERIA.GOLD.minNoComplaintRate) {
    return LEVEL_CRITERIA.GOLD;
  }
  if (p >= LEVEL_CRITERIA.SILVER.minPoints &&
      s >= LEVEL_CRITERIA.SILVER.minSuccessRate &&
      c >= LEVEL_CRITERIA.SILVER.minNoComplaintRate) {
    return LEVEL_CRITERIA.SILVER;
  }
  return LEVEL_CRITERIA.BRONZE;
}

/**
 * Calcula todas as métricas em tempo real usando a quantidade inteira de falhas e queixas,
 * permitindo que ao adicionar novos pacotes no dia a dia tudo se atualize sem precisar de print novo.
 */
export function compareWithLevelTarget(
  totalPackages,
  userPoints,
  failedCountInput,
  complaintCountInput,
  targetKey = 'PLATINUM',
  fallbackSuccessRate = 100,
  fallbackNoComplaintRate = 100
) {
  const total = Math.max(0, Number(totalPackages) || 0);
  const points = Math.max(0, Number(userPoints) || 0);
  const deliveredFailedCount = Math.min(total, Math.max(0, Math.round(Number(failedCountInput) || 0)));
  const complaintCount = Math.min(total, Math.max(0, Math.round(Number(complaintCountInput) || 0)));
  const deliveredSuccessCount = Math.max(0, total - deliveredFailedCount);

  // Taxas recalculadas automaticamente conforme novos pacotes são adicionados
  const successRate = total > 0
    ? Number(((deliveredSuccessCount / total) * 100).toFixed(2))
    : Math.min(100, Math.max(0, Number(fallbackSuccessRate) || 100));

  const noComplaintRate = total > 0
    ? Number((((total - complaintCount) / total) * 100).toFixed(2))
    : Math.min(100, Math.max(0, Number(fallbackNoComplaintRate) || 100));

  const target = LEVEL_CRITERIA[targetKey] || LEVEL_CRITERIA.PLATINUM;

  // 1. PONTOS
  const pointsDiff = points - target.minPoints;
  const pointsStatus = {
    current: points,
    target: target.minPoints,
    reached: pointsDiff >= 0,
    diff: Math.abs(pointsDiff)
  };

  // 2. FALHAS DE ENTREGA
  const targetSuccessPct = target.minSuccessRate;
  const successReached = successRate >= targetSuccessPct;

  let canFailMargin = 0;
  let neededConsecutiveSuccess = 0;
  let maxAllowedFailures = 0;
  let packagesForOneMoreFailure = 0;

  if (targetSuccessPct > 0 && targetSuccessPct < 100) {
    const failureFraction = (100 - targetSuccessPct) / 100;
    maxAllowedFailures = Math.floor(total * failureFraction + 0.00001);

    if (successReached) {
      canFailMargin = Math.max(0, maxAllowedFailures - deliveredFailedCount);
    } else {
      const targetFrac = targetSuccessPct / 100;
      neededConsecutiveSuccess = Math.max(1, Math.ceil(((targetFrac * total) - deliveredSuccessCount) / (1 - targetFrac)));
    }

    const nextFailureMilestone = Math.ceil((maxAllowedFailures + 1) / failureFraction - 0.00001);
    packagesForOneMoreFailure = Math.max(1, nextFailureMilestone - total);
  } else {
    maxAllowedFailures = total;
    canFailMargin = total;
    packagesForOneMoreFailure = 0;
  }

  // 3. RECLAMAÇÕES
  const targetComplaintPct = target.minNoComplaintRate;
  const complaintReached = noComplaintRate >= targetComplaintPct;

  let maxAllowedComplaints = 9999;
  let allowedAdditionalComplaints = 0;
  let packagesForOneMoreComplaint = 0;

  if (targetComplaintPct > 0 && targetComplaintPct < 100) {
    const complaintFraction = (100 - targetComplaintPct) / 100;
    maxAllowedComplaints = Math.floor(total * complaintFraction + 0.00001);
    allowedAdditionalComplaints = Math.max(0, maxAllowedComplaints - complaintCount);

    const nextComplaintMilestone = Math.ceil((maxAllowedComplaints + 1) / complaintFraction - 0.00001);
    packagesForOneMoreComplaint = Math.max(1, nextComplaintMilestone - total);
  }

  const allReached = pointsStatus.reached && successReached && (targetComplaintPct === 0 || complaintReached);

  return {
    target,
    allReached,
    total,
    pointsStatus,
    successAnalysis: {
      currentRate: successRate,
      targetRate: targetSuccessPct,
      reached: successReached,
      deliveredSuccessCount,
      deliveredFailedCount,
      maxAllowedFailures,
      marginPacotes: canFailMargin,
      neededConsecutiveSuccess,
      packagesForOneMoreFailure
    },
    complaintAnalysis: {
      currentRate: noComplaintRate,
      targetRate: targetComplaintPct,
      reached: complaintReached,
      complaintCount,
      maxAllowedComplaints,
      allowedAdditionalComplaints,
      packagesForOneMoreComplaint
    }
  };
}
