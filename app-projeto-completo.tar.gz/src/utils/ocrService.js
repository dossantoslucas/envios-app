import { createWorker } from 'tesseract.js';

/**
 * Processa a imagem enviada pelo entregador e tenta extrair:
 * - pontos
 * - taxa de sucesso (%)
 * - taxa sem reclamações (%)
 */
export async function parseEnviosExtraImage(imageFileOrUrl, onProgress) {
  let worker = null;
  try {
    worker = await createWorker('por', 1, {
      logger: m => {
        if (onProgress && m.status === 'recognizing text') {
          onProgress(Math.round(m.progress * 100));
        }
      }
    });

    const { data: { text } } = await worker.recognize(imageFileOrUrl);
    await worker.terminate();

    return parseExtractedText(text);
  } catch (error) {
    console.error("Erro no OCR:", error);
    if (worker) {
      try { await worker.terminate(); } catch (_) {}
    }
    return {
      success: false,
      error: error.message || "Não foi possível ler a imagem com precisão."
    };
  }
}

export function parseExtractedText(rawText) {
  // Normalizar quebras de linha e possíveis confusões de OCR em "100%" (ex: 1OO%, 10O%)
  const clean = rawText
    .replace(/\r\n/g, '\n')
    .replace(/\b1[oO0]{2}\s*%/g, '100%');

  const lines = clean.split('\n').map(l => l.trim()).filter(Boolean);

  // Função auxiliar para detectar se uma linha é apenas a régua de metas abaixo da barra
  // Ex: "0% 96% 97% 98%" ou "0% 99,50% 99,60% 99,70%"
  const isRulerLine = (line) => {
    const pctMatches = line.match(/\d{1,3}(?:[.,]\d{1,2})?\s*%/g);
    if (pctMatches && pctMatches.length >= 2) return true;
    if (/99[.,]50?%.*99[.,]60?%/i.test(line)) return true;
    if (/96%.*97%.*98%/i.test(line)) return true;
    return false;
  };

  let points = null;
  let successRate = null;
  let noComplaintRate = null;

  // 1. Procurar Pontos (Ex: "2.850 Pontos", "270 Pontos", "0 Pontos")
  const pointsMatch = clean.match(/([\d\.]+)\s*(?:Pontos|Ponto|pts)/i);
  if (pointsMatch) {
    const rawVal = pointsMatch[1].replace(/\./g, '');
    const num = parseInt(rawVal, 10);
    if (!isNaN(num)) points = num;
  }

  // Regex que aceita tanto inteiros (100%, 99%, 0%) quanto decimais (98,86%, 99.5%)
  const pctRegex = /(\d{1,3}(?:[.,]\d{1,2})?)\s*%/;

  // 2. Procurar "Entregas com sucesso" e "Entregas sem reclamações"
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (isRulerLine(line)) continue;

    // Verificar "Entregas com sucesso"
    if (/com\s+sucesso/i.test(line)) {
      const matchSameLine = line.match(pctRegex) || line.match(/^(\d{1,3}(?:[.,]\d{1,2})?)\s+Entregas/i);
      if (matchSameLine) {
        successRate = parseFloat(matchSameLine[1].replace(',', '.'));
      } else if (i > 0 && !isRulerLine(lines[i - 1])) {
        const matchPrev = lines[i - 1].match(pctRegex);
        if (matchPrev) {
          successRate = parseFloat(matchPrev[1].replace(',', '.'));
        }
      }
    }

    // Verificar "Entregas sem reclamações"
    if (/sem\s+recla/i.test(line)) {
      const matchSameLine = line.match(pctRegex) || line.match(/^(\d{1,3}(?:[.,]\d{1,2})?)\s+Entregas/i);
      if (matchSameLine) {
        noComplaintRate = parseFloat(matchSameLine[1].replace(',', '.'));
      } else if (i > 0 && !isRulerLine(lines[i - 1])) {
        const matchPrev = lines[i - 1].match(pctRegex);
        if (matchPrev) {
          noComplaintRate = parseFloat(matchPrev[1].replace(',', '.'));
        }
      }
    }
  }

  // Fallback seguro ignorando linhas de régua da barra de progresso
  if (successRate === null || noComplaintRate === null) {
    const nonRulerText = lines.filter(l => !isRulerLine(l)).join('\n');
    const allPercentages = [...nonRulerText.matchAll(/(\d{1,3}(?:[.,]\d{1,2})?)\s*%/g)]
      .map(m => parseFloat(m[1].replace(',', '.')))
      .filter(val => val >= 50 && val <= 100);

    if (successRate === null && allPercentages.length > 0) {
      successRate = allPercentages[0];
    }
    if (noComplaintRate === null && allPercentages.length > 1) {
      noComplaintRate = allPercentages[1];
    }
  }

  return {
    success: true,
    points: points ?? 0,
    successRate: successRate ?? 100,
    noComplaintRate: noComplaintRate ?? 100,
    rawText
  };
}
