import { createWorker } from 'tesseract.js';

const MONTH_MAP = {
  jan: '01', fev: '02', mar: '03', abr: '04',
  mai: '05', jun: '06', jul: '07', ago: '08',
  set: '09', out: '10', nov: '11', dez: '12'
};

function sanitizeStops(visited, total) {
  let v = Number(visited) || 0;
  let t = Number(total) || 0;

  if (t > 250 && v <= 200) {
    const sVis = String(v);
    const sTot = String(t);

    if (sTot === '1' + sVis) {
      return { visited: v, total: v };
    }
    if (sTot === sVis + '0') {
      return { visited: v, total: v };
    }
    return { visited: v, total: v };
  }

  if (t < v) {
    t = v;
  }

  return { visited: v, total: t };
}

function extractDateFromText(rawText) {
  // Procura padrões como "05/out", "10/out.", "28/set", "05/10"
  const regex = /(\d{1,2})\s*[\/\-]\s*(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)/i;
  const match = rawText.match(regex);

  if (match) {
    const day = match[1].padStart(2, '0');
    const monthStr = match[2].toLowerCase();
    const monthNum = MONTH_MAP[monthStr] || '10';
    const currentYear = new Date().getFullYear();
    return {
      isoDate: `${currentYear}-${monthNum}-${day}`,
      displayDate: `${day}/${monthStr}`
    };
  }

  // Tenta formato numérico ex: 05/10
  const numRegex = /(\d{1,2})\s*[\/\-]\s*(\d{2})/;
  const numMatch = rawText.match(numRegex);
  if (numMatch) {
    const day = numMatch[1].padStart(2, '0');
    const m = numMatch[2];
    if (parseInt(m, 10) >= 1 && parseInt(m, 10) <= 12) {
      const currentYear = new Date().getFullYear();
      return {
        isoDate: `${currentYear}-${m}-${day}`,
        displayDate: `${day}/${m}`
      };
    }
  }

  return null;
}

// Recorta o cabeçalho amarelo onde fica a barra superior e o título da data
async function cropHeaderCanvas(imageFile) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      // Pega os primeiros 14% do topo da imagem (barra de status + título da rota)
      canvas.width = img.width;
      canvas.height = Math.round(img.height * 0.14);
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, img.width, canvas.height, 0, 0, img.width, canvas.height);
      canvas.toBlob((blob) => resolve(blob), 'image/png');
    };
    img.onerror = () => resolve(null);
    img.src = URL.createObjectURL(imageFile);
  });
}

export async function parseRouteStopImage(imageFile, onProgress) {
  let worker = null;
  try {
    worker = await createWorker('por', 1, {
      logger: m => {
        if (onProgress && m.status === 'recognizing text') {
          onProgress(Math.round(m.progress * 100));
        }
      }
    });

    // 1. Reconhece o corpo da imagem completa
    const { data: { text: fullText } } = await worker.recognize(imageFile);

    // 2. Reconhece especificamente o topo (cabeçalho) para capturar a data em amarelo com precisão
    let headerText = '';
    try {
      const headerBlob = await cropHeaderCanvas(imageFile);
      if (headerBlob) {
        const headerRes = await worker.recognize(headerBlob);
        headerText = headerRes?.data?.text || '';
      }
    } catch (e) {
      console.warn('Erro ao ler header isolado:', e);
    }

    await worker.terminate();

    return parseRouteStopText(fullText, headerText);
  } catch (err) {
    console.error('Erro OCR de rota:', err);
    if (worker) {
      try { await worker.terminate(); } catch (_) {}
    }
    return { success: false, error: err.message };
  }
}

export function parseRouteStopText(fullText, headerText = '') {
  const combined = (headerText + '\n' + fullText).replace(/\r\n/g, '\n');

  // 1. Procurar paradas
  let visitedStops = null;
  let totalStops = null;

  const stopsMatch = combined.match(/visitou\s+(\d+)\s*[\/\|\\I!]\s*(\d+)/i) ||
                     combined.match(/(\d+)\s*[\/\|\\I!]\s*(\d+)\s*paradas/i);

  if (stopsMatch) {
    const rawV = parseInt(stopsMatch[1], 10);
    const rawT = parseInt(stopsMatch[2], 10);
    const sanitized = sanitizeStops(rawV, rawT);
    visitedStops = sanitized.visited;
    totalStops = sanitized.total;
  }

  // 2. Extrair data real do topo
  const dateInfo = extractDateFromText(combined);

  // 3. Procurar Ganho em R$
  let earnings = null;
  const earningsMatch = combined.match(/R\$\s*([\d\.\,]+)/i);
  if (earningsMatch) {
    earnings = earningsMatch[1].trim();
  }

  return {
    success: totalStops !== null || visitedStops !== null,
    visitedStops: visitedStops ?? 0,
    totalStops: totalStops ?? visitedStops ?? 0,
    earnings: earnings ? `R$ ${earnings}` : null,
    isoDate: dateInfo?.isoDate || null,
    displayDate: dateInfo?.displayDate || null,
    rawText: combined
  };
}
